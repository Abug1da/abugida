# Handoff: Abugida Design System

## Overview

Abugida is a non-profit building a **free, web-based home for learning Amharic** and preserving Ethiopian heritage for the diaspora. This bundle is the complete design system: tokens, components, the cultural ornament vocabulary, and a working reference app (Landing → Dashboard → Lesson → Archive).

The system's central goal is that it reads as **specifically Ethiopian, not generically African**. Culture is treated as *structure*, not decoration — the ornament is load-bearing furniture. Please read "The three rules" below before writing any UI; they are what make this system what it is, and they are easy to accidentally sand off.

## About the design files

The files in this bundle are **design references created in HTML/JSX** — prototypes showing intended look and behaviour, not production code to drop in. Your task is to **recreate these designs in the target codebase's environment** (React, Vue, SwiftUI, native, etc.) using its established patterns and libraries. If no environment exists yet, choose the most appropriate framework and implement there.

The component `.jsx` files are plain React with no build-time dependencies and no CSS-in-JS library — they inject a `<style>` tag or use inline styles. In a real codebase, port them to whatever styling approach is already in use. The **token layer (`tokens/*.css`) is the part most worth keeping verbatim.**

## Fidelity

**High-fidelity.** Colours, typography, spacing, and ornament geometry are final. Recreate pixel-accurately. Every value below is the real value, not a placeholder.

Two things *are* placeholders and are marked as such:
- **Photography** — image areas are cream panels with fidel texture and an "image placeholder" label. Real, rights-cleared photography replaces them.
- **Icons** — [Lucide](https://lucide.dev) stands in for a not-yet-commissioned brand icon set, and is used **only inside app UI**. Marketing surfaces use no icons at all.

---

## The three rules

These are non-negotiable and are the difference between this system and a generic one.

### 1. Tibeb as structure

**ጥብብ tibeb** is the woven coloured border of the netela and habesha kemis. In this system every divider, card cap, section break and header underline is a `<Tibeb>` band — **never a hairline rule, never a rounded pill**.

It is built on a **discrete cell grid**, because tibeb *is* a grid: warp and weft. A loom cannot make a curve, so neither does the component. Each motif is authored as a **counted draft** — the way a weaver reads a pattern off squared paper. Letters index the palette, `.` is ground:

```
diamond: '....A....'      chevron: 'AA....AA'
         '...AAA...'               '.AA..AA.'
         '..AABAA..'               '..AAAA..'
         '.AABCBAA.'               'BB....BB'
         'AABCDCBAA'               '.BB..BB.'
         '.AABCBAA.'               '..BBBB..'
         '..AABAA..'
         '...AAA...'
         '....A....'
```

Seven motifs: `diamond` (the signature netela lozenge), `chevron` (running zigzag), `terrace` (Aksumite stepped profile), `cross` (flared arms, openwork), `box`, `ladder` (the checkered selvedge), `dash` (the quiet divider).

**Sizing is in cells, not pixels.** `cell={4}` means one thread crossing is 4px; band height is always `rows × cell`. Do not add a `height` prop — that would let it stretch, which a weave cannot do.

Rendering: an SVG `<pattern>` in user-space units, tiled across 100% width. Cells are drawn 0.35px oversized so neighbours butt cleanly with no seam at fractional device pixels. `shapeRendering="crispEdges"`.

> **Critical:** an earlier version of this system drew these bands as sine waves and interlocking circles. That was wrong — smooth interlace reads as generic Celtic knotwork. **Ornament here is rectilinear and counted.** If you find yourself drawing a bezier, stop.

### 2. Fidel as texture

The **Geʼez script (ፊደል fidel)** is one of the few indigenous African writing systems still in daily use, and its rounded, blocky rhythm is recognisable long before it is readable. `<FidelField>` sets it large and faint behind heroes, footers and empty states — the way Japanese design uses kanji: confident and specific.

Three modes: `field` (repeating grid, rows offset by half a cell so it reads as cloth not spreadsheet), `watermark` (one enormous glyph bled off a corner), `column` (a running margin strip).

It is decoration made of language, so it is `aria-hidden`, `pointer-events: none`, and `user-select: none`.

### 3. The netela rule

A netela is a white shawl with **one blazing woven border**, and that contrast is the entire effect. So:

> **The field stays cream. Saturated colour lives only inside the bands.**

Indigo `#1D4A7A` and highland green `#1F6F52` are **thread colours** — legal inside a `<Tibeb>`, or as functional status (info/success), and nowhere else. Never a surface, never a button, never a block of background.

---

## Design tokens

### Colour — the coffee ceremony palette

Deliberately **not** the flag colours. Green/yellow/red is the most over-fished palette in "African-themed" design and reads generic pan-African. The buna (coffee) ceremony gives a rarer, warmer set that also works better for a reading app — less carnival, more invitation.

| Token | Hex | Name | Source |
|---|---|---|---|
| `--vermilion-500` / `--brand` | `#A8412A` | ቡና rust | roasted bean — **the primary** |
| `--saffron-400` / `--accent-gold` | `#C98A2B` | ወርቅ ochre | coffee cherry, turmeric, straw |
| `--clay-800` | `#4A2E1E` | bean | deep roast brown |
| `--clay-900` | `#241A14` | ጀበና jebena | the clay pot, fired near-black |
| `--clay-500` | `#8C7A67` | አመድ ash | wood ash — the warm grey |
| `--clay-100` / `--surface-page` | `#F7EFE1` | ጥጥ cream | unbleached cotton — **the field** |
| `--indigo-500` | `#1D4A7A` | ሰማያዊ | **thread only** |
| `--highland-400` | `#1F6F52` | አረንጓዴ | **thread only** |

**There is no pure white and no pure black anywhere.** `--surface-raised` is `#FFFDF8`; `--black` is `#150F0B`.

Full ramps (50–900) for each hue are in `tokens/colors.css`. Semantic aliases — `--surface-*`, `--text-*`, `--brand-*`, `--border-*`, status — are defined there too; **reference the semantic alias, not the raw ramp step**, in product code.

### Tibeb thread sets

```js
buna:   ['#A8412A', '#C98A2B', '#4A2E1E', '#F7EFE1']  // default
netela: ['#241A14', '#C98A2B', '#B4341F', '#1F6F52']  // classic border
bright: ['#C4321C', '#E8B02A', '#1F6F52', '#1D4A7A']  // one hero band only
scribe: ['#241A14', '#C98A2B', '#A8412A', '#F7EFE1']  // manuscript register
```

### Typography

| Role | Family | Notes |
|---|---|---|
| Display | **Newsreader** | headings, pull quotes; weight 400–500, tight leading |
| Body | **Hanken Grotesk** | UI and paragraphs; 600–700 for emphasis |
| Fidel | **Noto Serif Ethiopic** | all Geʼez — **always real type, never redrawn** |
| Mono | **Space Mono** | romanisation, keys, hex values |

Loaded from the Google Fonts CDN (see Caveats). Full scale in `tokens/typography.css`. Long-form reading is measured at ~66ch with 1.7 line-height.

### Other token files

- `tokens/spacing.css` — 8px grid, semantic spacing, container widths
- `tokens/effects.css` — radii, warm shadows, borders, easing/durations
- `tokens/ornament.css` — the cultural layer: pigments, tibeb cell sizes, Geʼez punctuation, manuscript measure, and the `.rubric` / `.rubric-open` / `.gloss` rules
- `tokens/base.css` — element resets, `.eyebrow`, `.fidel`, `.bg-parchment`

---

## Conventions that are easy to miss

**Counting.** The product counts in **Geʼez figures** via `<GeezNumeral>` — ፩ ፪ ፫. Lesson numbers, chapter numbers, step counts, badge counts. A learning product that renders "Lesson 3" in Latin digits has already conceded the point. The Latin value stays in the accessibility tree via a visually-hidden span, so screen readers and copy-paste still work. `toGeez(n)` handles 1–99,999,999; zero returns `''` (the system is additive and has no zero).

**Dates** use the **Ethiopian calendar** — thirteen months. The dashboard reads `ረቡዕ ፡ ነሐሴ ፮ ቀን ፡ ፳፻፲፰ ዓ.ም`. A streak measured in a calendar the learner doesn't use is a streak measured in someone else's time.

**Rubrication.** In a Geʼez manuscript red ink is not an accent, it is a *semantic*: it marks the thing being **named**. Names, places, months, script terms, section openings, and marginal glosses take rust. Red is deliberately **not** the colour of a call to action — that would turn a sacred convention into a sales device. `.rubric` and `.rubric-open` (a floated first-letter dropcap) implement this.

**Punctuation.** Use the script's own marks, not bullets or em-dashes: `፠` opens a titled section · `፨` separates movements · `።` ends a statement · `፣` series · `፤` introduces a list · `፥` quotation. Nav separators use `፣`.

**The margin gloss.** Geʼez codices set a narrow text column against a wide outer margin carrying the scribe's annotations in red. The landing hero and `<ManuscriptFrame>` both reserve that column — it is where etymology and cultural context belong.

---

## Components

Namespace when loading the compiled bundle: `window.AbugidaDesignSystem_019e1e`.

### Ornament — the cultural vocabulary (`components/ornament/`)

| Component | Purpose |
|---|---|
| `Tibeb` | The woven band. Props: `motif`, `cell`, `palette`, `frame`, `frameColors`, `ground`, `flip` |
| `FidelField` | Geʼez as texture. Props: `mode`, `chars`, `size`, `gap`, `opacity`, `color`, `seed`, `rotate`, `text` |
| `CrossLattice` | The Ethiopian cross as a ground. Props: `cell`, `color`, `opacity`, `gutter` |
| `GeezNumeral` | A number in Geʼez figures. Props: `value`, `showLatin`, `tone`. Also exports `toGeez()` |
| `SectionMark` | A divider built from Geʼez punctuation. Props: `mark`, `rules`, `tone`, `size`, `label` |
| `ManuscriptFrame` | Codex page as a layout primitive — woven crown, rubricated title, margin gloss |

**The Ethiopian cross** is not a Latin or Greek cross: it is latticed and interwoven, and **its arms widen toward their tips**. That flare is the whole tell. The draft is in `CrossLattice.jsx`.

### Primitives

- `core/` — `Button`, `IconButton`, `Badge`, `Avatar`, `Card`, `ProgressBar`
- `forms/` — `Input`
- `navigation/` — `Tabs`
- `learn/` — `FidelTile` (the signature control: a tappable Geʼez character tile), `LessonCard`

Every component ships a `.d.ts` with full prop documentation and a `.prompt.md` with usage guidance. **Read the `.d.ts` for exact prop contracts** — they are the specification.

---

## Screens

The reference app is in `ui_kits/learn-app/`. Open `ui_kits/learn-app/index.html` in a browser to click through it. `data.js` holds all mock content.

### Landing (`Landing.jsx`)
Marketing page, cream field. Structure top to bottom:
1. **Header** — fidel mark + wordmark left, nav right with `፣` separators, primary CTA. Capped by a full-width `Tibeb motif="diamond" cell={4} palette="netela"`.
2. **Hero** — `FidelField` at `size={128} opacity={0.042}` behind. Two-column grid `minmax(0,1fr) 15ch`: left is the section line (`ክፍል ፩ ። መጀመሪያ ቃል`), `ሰላም` at 108px with a rubricated first character, romanisation, a `.rubric-open` paragraph, two CTAs. Right is the scribe's margin — a rubricated Amharic gloss, its English note, and a `፨`.
3. **The fidel table** — the hero object. Chevron band cap, then a grid `10ch repeat(7, 1fr)` with the seven vowel orders named as Ethiopians name them (ግዕዝ ካዕብ ሣልስ ራብዕ ኃምስ ሳድስ ሳብዕ) and numbered ፩–፯, not 1–7.
4. **Three offerings** — where icons would normally go, a large Geʼez chapter numeral and a `dash` band. **The number is the icon.**
5. **First words** — deep-roast `#4A2E1E` band, `terrace` motif capping top and bottom.
6. **Footer** — jebena `#241A14` on a `CrossLattice` ground at `opacity={0.05}`.

### Dashboard (`Dashboard.jsx`)
Learner home inside `AppShell`. Ethiopian date line, greeting, three stat cards (Geʼez figure over a `dash` band — **not** an icon in a rounded square), a continue card, the fidel path list, and a review rail.

### Lesson (`Lesson.jsx`)
Three phases in local state: `teach` → `quiz` → `done`. Teach shows the base form at 120px over a `FidelField` watermark, then the seven orders as `FidelTile`s. Quiz is 4-up tiles with `default | selected | correct | wrong | ghost` states, a check/continue footer bar that tints on result. Done shows `፨` in a success circle.

### Archive (`Archive.jsx`)
Coming-soon surface. Dark hero on a `CrossLattice` ground with a large `አ` watermark; category cards whose image placeholders are cream panels with fidel texture and a Geʼez numeral; an email capture.

### AppShell (`AppShell.jsx`)
244px sidebar — logo, `diamond` tibeb band, nav items with Geʼez badge counts, learner identity pinned to the bottom.

**Logo:** the fidel character `አ` in rust over a woven `dash` band. It is deliberately **not** a glyph inside a rounded square — that lockup is the most generic element on the web and says nothing about where this comes from.

---

## Interactions & behaviour

- **Motion** — soft `ease-out`; hover-lift and press-settle on interactive surfaces. Tokens in `tokens/effects.css`. Honour `prefers-reduced-motion`.
- **Focus** — visible ring using `--ring` (`--saffron-300`). Never remove outlines.
- **Quiz flow** — select a tile → Check enables → result tints the footer and reveals the answer gloss → Continue advances; last question goes to `done`.
- **Navigation** — the reference app is a single-page state machine in `index.html`; wire to real routing in the target codebase.

## State management

The reference app keeps everything in React local state (`useState`) — deliberately, since it is a prototype. Real state needs: current learner (name, streak, mastered count, daily goal/progress), family list with per-family status (`done | active | locked`) and progress, quiz session (index, picked, checked), and review queue size.

## Accessibility

- All decorative ornament is `aria-hidden` and non-selectable.
- `GeezNumeral` keeps the Latin value in the accessibility tree.
- Body text meets AA on cream; **verify any new colour pairing** — ochre `#C98A2B` on cream does **not** pass for body text and is used only for large type and threads.
- Hit targets ≥44px on touch.

## Assets

- **Fonts** — Newsreader, Hanken Grotesk, Noto Serif Ethiopic, Space Mono, all from Google Fonts CDN via `tokens/fonts.css`. Self-host for production.
- **Icons** — Lucide via CDN, `<i data-lucide="name">` + `lucide.createIcons()`. App UI only.
- **Images** — none ship. All image areas are labelled placeholders.

## Files in this bundle

```
styles.css              entry point — @imports every token file
tokens/                 colors, ornament, typography, spacing, effects, fonts, base
components/             ornament/ + core/ forms/ navigation/ learn/ (jsx + d.ts + prompt.md)
ui_kits/learn-app/      the click-through prototype — open index.html
guidelines/             foundation specimen cards (colour, type, spacing, brand)
templates/              two ready-made starting points (brand landing, quote poster)
_ds_bundle.js           all components compiled to one file, namespaced
SKILL.md                condensed brand rules, including an explicit "Never" list
readme.md               the full design guide — voice, content, foundations, file index
CLAUDE_CODE_HANDOFF.md  this file
```

## Never

- Flag colours (green/yellow/red) as a palette — reads generic pan-African.
- Smooth interlace, plaits, knotwork, swirls — reads Celtic. Ornament is rectilinear and counted.
- A glyph inside a rounded square as a logo lockup.
- Tribal-pattern clip art, Africa-shaped continent icons, gradient hero backgrounds.
- Latin digits for lesson or chapter numbers.
- Red as a call-to-action colour.

## Caveats

- Webfonts are CDN-loaded, not self-hosted.
- No real photography ships.
- Lucide stands in for a brand icon set that does not exist yet — it is the last generic layer in the system and worth commissioning.
- Amharic copy in the reference app was written for plausibility. **Have a native speaker review all Amharic strings before shipping.**
