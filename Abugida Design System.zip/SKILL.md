---
name: abugida-design
description: Use this skill to generate well-branded interfaces and assets for Abugida — a non-profit building a free, web-based home for learning Amharic and preserving Ethiopian heritage for the diaspora. Use it for production UI or throwaway prototypes/mocks/decks. Contains essential design guidelines, colors, type, fonts, assets, and UI-kit components for a specifically Ethiopian visual system built on woven tibeb geometry, Geʼez script as texture, and the coffee-ceremony palette.
user-invocable: true
---

# Abugida design

Abugida is a non-profit. Its first product is a **free Amharic learning web app**; a **cultural archive** follows.

The system's job is to read as **specifically Ethiopian, not generically African**. Culture is structure here, not texture: the ornament is load-bearing furniture, not decoration laid on top.

## Start here
1. Read **`readme.md`** — the full design guide: brand, voice, the cultural vocabulary, iconography, file index. It is the source of truth.
2. Skim **`tokens/`** for the exact CSS custom properties (`colors.css`, `ornament.css`, `typography.css`, `spacing.css`, `effects.css`). Link **`styles.css`** to inherit everything.
3. Browse **`components/`** — especially **`ornament/`** (`Tibeb`, `FidelField`, `CrossLattice`, `GeezNumeral`, `SectionMark`, `ManuscriptFrame`). Each has a `.prompt.md` with usage.
4. See **`ui_kits/learn-app/`** for a full click-through of the product to copy patterns from.
5. Foundation specimens live in **`guidelines/`**.

## How to work
- **Visual artifacts** (slides, mocks, throwaway prototypes): copy the assets you need out of this folder and produce **static HTML files** the user can open. Link `styles.css`; load components from the compiled bundle (`_ds_bundle.js`, namespace `window.AbugidaDesignSystem_019e1e`) the way the kit and component cards do.
- **Production code**: copy assets and follow the rules here to design natively in the brand.

## The three rules that make it Ethiopian

1. **Tibeb as structure.** Every divider, card cap, section break and header underline is a `<Tibeb>` woven band — never a hairline rule or a rounded pill. It is built on a discrete **cell grid** from **counted drafts**, because tibeb *is* a grid: warp and weft. A loom cannot make a curve, so neither does the component. Size in **cells** (`cell={4}`), not pixels.
2. **Fidel as texture.** `<FidelField>` sets oversized faint Geʼez behind heroes, footers and empty states — the way Japanese design uses kanji. Recognisable as Ethiopian long before it is readable.
3. **The netela rule.** A netela is a white shawl with one blazing woven border, and that contrast is the whole effect. The field stays cream; saturated colour lives **only** inside the bands.

## Brand guardrails (quick)
- **Type:** Newsreader (display) · Hanken Grotesk (body) · Noto Serif Ethiopic (fidel) · Space Mono (keys). Geʼez is always real type, never redrawn.
- **Color — the coffee ceremony, NOT the flag.** Rust `#A8412A` primary · ochre `#C98A2B` · bean `#4A2E1E` · jebena `#241A14` · ash `#8C7A67` · cream `#F7EFE1`. **No pure black or white.** Indigo `#1D4A7A` and highland `#1F6F52` are **thread colours** — legal inside a `<Tibeb>` or as functional status, never as a surface or a button.
- **Counting:** the product counts in Geʼez figures (`<GeezNumeral>`), and dates use the Ethiopian calendar. Never Latin digits for lesson/chapter numbers.
- **Rubrication:** red marks the thing being **named** (places, months, script terms, section openings), never a call to action.
- **Punctuation:** use the script's own marks — `፠` section, `፨` break, `።` full stop, `፣` series, `፤` list, `፥` quotation — not bullets or em-dashes.
- **Voice:** warm, plain, second-person ("you"), sentence case, no jargon, **no emoji**. Cultural terms glossed once (*buna*, *tibeb*, *fidel*).
- **Icons:** Lucide (stroke), via `<i data-lucide>` + `lucide.createIcons()` — **app UI only**. Marketing surfaces use no icons; Geʼez numerals and woven bands do that work.
- **Motion:** soft `ease-out`, hover-lift / press-settle; honor `prefers-reduced-motion`.

## Never
- Flag colours (green/yellow/red) as a palette — it reads generic pan-African.
- Smooth interlace, plaits, knotwork or swirls — that reads Celtic, not Ethiopian. Ornament is **rectilinear and counted**.
- A glyph inside a rounded square as a logo lockup.
- Tribal-pattern clip art, Africa-shaped continent icons, gradient hero backgrounds.

If invoked with no specific ask, act as an expert Abugida designer: ask what they want to build, ask a few sharp questions, then output HTML artifacts or production code as appropriate.

## Caveats
- Webfonts load from Google Fonts CDN (not self-hosted). No real photography ships — image areas are placeholders. Lucide stands in for a not-yet-existing brand icon set.
