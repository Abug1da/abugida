/* @ds-bundle: {"format":4,"namespace":"AbugidaDesignSystem_019e1e","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"ProgressBar","sourcePath":"components/core/ProgressBar.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"FidelTile","sourcePath":"components/learn/FidelTile.jsx"},{"name":"LessonCard","sourcePath":"components/learn/LessonCard.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"CrossLattice","sourcePath":"components/ornament/CrossLattice.jsx"},{"name":"FidelField","sourcePath":"components/ornament/FidelField.jsx"},{"name":"GeezNumeral","sourcePath":"components/ornament/GeezNumeral.jsx"},{"name":"ManuscriptFrame","sourcePath":"components/ornament/ManuscriptFrame.jsx"},{"name":"SectionMark","sourcePath":"components/ornament/SectionMark.jsx"},{"name":"Tibeb","sourcePath":"components/ornament/Tibeb.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"e3cfea41f34d","components/core/Badge.jsx":"61382cb85149","components/core/Button.jsx":"06b2f9c2f7d7","components/core/Card.jsx":"eb014ed9f1bb","components/core/IconButton.jsx":"e1d4a2465b40","components/core/ProgressBar.jsx":"a332661a0767","components/forms/Input.jsx":"0625b71e0f9c","components/learn/FidelTile.jsx":"ed59c83dba38","components/learn/LessonCard.jsx":"c33fe84160da","components/navigation/Tabs.jsx":"bb73fceddf98","components/ornament/CrossLattice.jsx":"13c9becb8202","components/ornament/FidelField.jsx":"33f442ffd703","components/ornament/GeezNumeral.jsx":"dbe7b473e215","components/ornament/ManuscriptFrame.jsx":"efdb62f2a058","components/ornament/SectionMark.jsx":"a0b9f368e923","components/ornament/Tibeb.jsx":"2936282641df","ui_kits/learn-app/AppShell.jsx":"ae292ef8a361","ui_kits/learn-app/Archive.jsx":"8e9a14183637","ui_kits/learn-app/Dashboard.jsx":"61b3a91106a2","ui_kits/learn-app/Landing.jsx":"1be339bfccab","ui_kits/learn-app/Lesson.jsx":"016322252d17","ui_kits/learn-app/Parts.jsx":"36629e9e0663","ui_kits/learn-app/data.js":"81995960fc1a"},"inlinedExternals":[],"unexposedExports":[{"name":"toGeez","sourcePath":"components/ornament/GeezNumeral.jsx"}]} */

(() => {

const __ds_ns = (window.AbugidaDesignSystem_019e1e = window.AbugidaDesignSystem_019e1e || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const AVATAR_CSS = `
.abg-avatar{
  display: inline-flex; align-items: center; justify-content: center; flex: none;
  border-radius: var(--radius-pill); overflow: hidden; background: var(--indigo-100);
  color: var(--indigo-600); font-family: var(--font-body); font-weight: var(--fw-bold);
  border: var(--border-width-strong) solid var(--surface-raised); box-shadow: var(--shadow-xs);
  position: relative; user-select: none;
}
.abg-avatar img{ width: 100%; height: 100%; object-fit: cover; }
.abg-avatar--xs{ width: 26px; height: 26px; font-size: 10px; }
.abg-avatar--sm{ width: 34px; height: 34px; font-size: 13px; }
.abg-avatar--md{ width: 44px; height: 44px; font-size: 16px; }
.abg-avatar--lg{ width: 60px; height: 60px; font-size: 22px; }
.abg-avatar--t1{ background: var(--vermilion-100); color: var(--vermilion-600); }
.abg-avatar--t2{ background: var(--saffron-100); color: var(--saffron-700); }
.abg-avatar--t3{ background: var(--highland-100); color: var(--highland-500); }
.abg-avatar--t4{ background: var(--indigo-100); color: var(--indigo-600); }
`;
let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'avatar');
  el.textContent = AVATAR_CSS;
  document.head.appendChild(el);
  _injected = true;
}
function initials(name = '') {
  const parts = name.trim().split(/\s+/).slice(0, 2);
  return parts.map(p => p[0] || '').join('').toUpperCase();
}

/** Round user avatar — image when `src` is given, else colored initials. */
function Avatar({
  name = '',
  src,
  size = 'md',
  tint,
  className = '',
  ...rest
}) {
  ensureStyles();
  // Deterministic tint from the name when not specified.
  const palette = ['t1', 't2', 't3', 't4'];
  const auto = palette[(name.charCodeAt(0) || 0) % palette.length];
  const cls = ['abg-avatar', `abg-avatar--${size}`, `abg-avatar--${tint || auto}`, className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls,
    role: "img",
    "aria-label": name
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name
  }) : initials(name));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const BADGE_CSS = `
.abg-badge{
  font-family: var(--font-body); font-weight: var(--fw-semibold); font-size: var(--text-xs);
  line-height: 1; display: inline-flex; align-items: center; gap: 5px;
  padding: 4px 9px; border-radius: var(--radius-pill); white-space: nowrap;
  border: var(--border-width) solid transparent;
}
.abg-badge svg{ width: 1em; height: 1em; }
.abg-badge--neutral{ background: var(--clay-100); color: var(--clay-700); border-color: var(--clay-200); }
.abg-badge--brand{ background: var(--brand-soft); color: var(--brand-on-soft); border-color: var(--vermilion-100); }
.abg-badge--success{ background: var(--success-soft); color: var(--highland-500); border-color: var(--highland-200); }
.abg-badge--warning{ background: var(--warning-soft); color: var(--saffron-700); border-color: var(--saffron-200); }
.abg-badge--danger{ background: var(--danger-soft); color: var(--vermilion-700); border-color: var(--vermilion-200); }
.abg-badge--info{ background: var(--info-soft); color: var(--indigo-600); border-color: var(--indigo-200); }
.abg-badge--solid{ background: var(--brand); color: var(--text-on-brand); border-color: transparent; }
.abg-badge--dot::before{ content:""; width:6px; height:6px; border-radius:var(--radius-pill); background: currentColor; opacity:.8; }
`;
let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'badge');
  el.textContent = BADGE_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/** Small status / metadata pill. */
function Badge({
  tone = 'neutral',
  dot = false,
  className = '',
  children,
  ...rest
}) {
  ensureStyles();
  const cls = ['abg-badge', `abg-badge--${tone}`, dot ? 'abg-badge--dot' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const BUTTON_CSS = `
.abg-btn{
  --_bg: var(--brand); --_fg: var(--text-on-brand); --_bd: transparent; --_bgh: var(--brand-hover); --_bgp: var(--brand-press);
  font-family: var(--font-body); font-weight: var(--fw-semibold);
  display: inline-flex; align-items: center; justify-content: center; gap: var(--gap-inline);
  border: var(--border-width-strong) solid var(--_bd); border-radius: var(--radius-md);
  background: var(--_bg); color: var(--_fg); cursor: pointer; text-decoration: none;
  white-space: nowrap; user-select: none; transition: var(--transition-control);
  box-shadow: var(--shadow-xs);
}
.abg-btn:hover{ background: var(--_bgh); }
.abg-btn:active{ background: var(--_bgp); transform: translateY(1px); box-shadow: none; }
.abg-btn:focus-visible{ outline: none; box-shadow: var(--focus-ring); }
.abg-btn[disabled], .abg-btn[aria-disabled="true"]{ opacity: .5; cursor: not-allowed; transform: none; box-shadow: none; }

.abg-btn--secondary{ --_bg: var(--surface-raised); --_fg: var(--text-strong); --_bd: var(--border-strong); --_bgh: var(--clay-100); --_bgp: var(--clay-200); }
.abg-btn--tinted{ --_bg: var(--brand-soft); --_fg: var(--brand-on-soft); --_bd: transparent; --_bgh: var(--vermilion-100); --_bgp: var(--vermilion-200); box-shadow: none; }
.abg-btn--ghost{ --_bg: transparent; --_fg: var(--text-body); --_bd: transparent; --_bgh: var(--clay-100); --_bgp: var(--clay-200); box-shadow: none; }
.abg-btn--gold{ --_bg: var(--saffron-400); --_fg: var(--clay-900); --_bd: transparent; --_bgh: var(--saffron-500); --_bgp: var(--saffron-600); }

.abg-btn--sm{ font-size: var(--text-sm); padding: 6px 12px; min-height: 34px; }
.abg-btn--md{ font-size: var(--text-md); padding: 9px 18px; min-height: 42px; }
.abg-btn--lg{ font-size: var(--text-lg); padding: 13px 24px; min-height: 52px; border-radius: var(--radius-lg); }
.abg-btn--full{ width: 100%; }
.abg-btn svg{ width: 1.1em; height: 1.1em; flex: none; }
`;
let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'button');
  el.textContent = BUTTON_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/**
 * Abugida primary button. Renders as <button> or, when `href` is set, <a>.
 */
function Button({
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  leadingIcon = null,
  trailingIcon = null,
  href,
  disabled = false,
  className = '',
  children,
  ...rest
}) {
  ensureStyles();
  const cls = ['abg-btn', `abg-btn--${variant}`, `abg-btn--${size}`, fullWidth ? 'abg-btn--full' : '', className].filter(Boolean).join(' ');
  const content = /*#__PURE__*/React.createElement(React.Fragment, null, leadingIcon, children != null && /*#__PURE__*/React.createElement("span", null, children), trailingIcon);
  if (href && !disabled) {
    return /*#__PURE__*/React.createElement("a", _extends({
      className: cls,
      href: href
    }, rest), content);
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    className: cls,
    disabled: disabled
  }, rest), content);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CARD_CSS = `
.abg-card{
  background: var(--surface-raised); border: var(--border-width) solid var(--border-subtle);
  border-radius: var(--radius-lg); box-shadow: var(--shadow-sm);
  transition: var(--transition-control); overflow: clip;
}
.abg-card--flat{ box-shadow: none; }
.abg-card--raised{ box-shadow: var(--shadow-md); border-color: transparent; }
.abg-card--interactive{ cursor: pointer; }
.abg-card--interactive:hover{ box-shadow: var(--shadow-lg); transform: translateY(-2px); border-color: var(--border-default); }
.abg-card--interactive:active{ transform: translateY(0); box-shadow: var(--shadow-sm); }
.abg-card--pad-none{ padding: 0; }
.abg-card--pad-sm{ padding: var(--space-4); }
.abg-card--pad-md{ padding: var(--space-5); }
.abg-card--pad-lg{ padding: var(--space-6); }
.abg-card__accent{ height: 4px; margin: calc(-1 * var(--_p, 0)) calc(-1 * var(--_p, 0)) 0; background: var(--brand); }
`;
let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'card');
  el.textContent = CARD_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/** Surface container with warm elevation. */
function Card({
  elevation = 'default',
  padding = 'md',
  interactive = false,
  accent = false,
  className = '',
  children,
  ...rest
}) {
  ensureStyles();
  const cls = ['abg-card', `abg-card--${elevation}`, `abg-card--pad-${padding}`, interactive ? 'abg-card--interactive' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, rest), accent && /*#__PURE__*/React.createElement("div", {
    className: "abg-card__accent",
    style: {
      background: accent === true ? 'var(--brand)' : accent
    }
  }), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const ICONBTN_CSS = `
.abg-iconbtn{
  --_bg: transparent; --_fg: var(--text-muted); --_bgh: var(--clay-100); --_fgh: var(--text-strong);
  display: inline-flex; align-items: center; justify-content: center;
  border: none; border-radius: var(--radius-md); background: var(--_bg); color: var(--_fg);
  cursor: pointer; transition: var(--transition-control);
}
.abg-iconbtn:hover{ background: var(--_bgh); color: var(--_fgh); }
.abg-iconbtn:active{ transform: translateY(1px); }
.abg-iconbtn:focus-visible{ outline: none; box-shadow: var(--focus-ring); }
.abg-iconbtn[disabled]{ opacity: .45; cursor: not-allowed; }
.abg-iconbtn--solid{ --_bg: var(--brand); --_fg: var(--text-on-brand); --_bgh: var(--brand-hover); --_fgh: var(--text-on-brand); box-shadow: var(--shadow-xs); }
.abg-iconbtn--outline{ --_bg: var(--surface-raised); --_fg: var(--text-body); --_bgh: var(--clay-100); --_fgh: var(--text-strong); box-shadow: var(--shadow-xs); border: var(--border-width) solid var(--border-default); }
.abg-iconbtn--sm{ width: 34px; height: 34px; }
.abg-iconbtn--md{ width: 42px; height: 42px; }
.abg-iconbtn--lg{ width: 50px; height: 50px; }
.abg-iconbtn svg{ width: 1.25em; height: 1.25em; }
.abg-iconbtn--sm svg{ font-size: 16px; } .abg-iconbtn--md svg{ font-size: 19px; } .abg-iconbtn--lg svg{ font-size: 22px; }
`;
let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'iconbutton');
  el.textContent = ICONBTN_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/** Square, label-less button wrapping a single icon. Always pass `aria-label`. */
function IconButton({
  variant = 'ghost',
  size = 'md',
  className = '',
  children,
  ...rest
}) {
  ensureStyles();
  const cls = ['abg-iconbtn', `abg-iconbtn--${variant}`, `abg-iconbtn--${size}`, className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("button", _extends({
    className: cls
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/ProgressBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const PROGRESS_CSS = `
.abg-progress{ display: block; width: 100%; }
.abg-progress__track{
  height: var(--_h, 10px); background: var(--clay-200); border-radius: var(--radius-pill);
  overflow: hidden; box-shadow: var(--shadow-inset);
}
.abg-progress__fill{
  height: 100%; border-radius: var(--radius-pill); background: var(--brand);
  transition: width var(--dur-slow) var(--ease-out);
}
.abg-progress--gold .abg-progress__fill{ background: var(--saffron-400); }
.abg-progress--green .abg-progress__fill{ background: var(--highland-400); }
.abg-progress__meta{
  display: flex; justify-content: space-between; align-items: baseline;
  margin-bottom: 7px; font-family: var(--font-body);
}
.abg-progress__label{ font-size: var(--text-sm); font-weight: var(--fw-medium); color: var(--text-body); }
.abg-progress__value{ font-size: var(--text-xs); font-weight: var(--fw-semibold); color: var(--text-muted); font-variant-numeric: tabular-nums; }
`;
let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'progress');
  el.textContent = PROGRESS_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/** Linear progress bar with optional label/value row. */
function ProgressBar({
  value = 0,
  max = 100,
  color = 'brand',
  height = 10,
  label,
  showValue = false,
  className = '',
  ...rest
}) {
  ensureStyles();
  const pct = Math.max(0, Math.min(100, value / max * 100));
  const cls = ['abg-progress', `abg-progress--${color}`, className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, rest), (label || showValue) && /*#__PURE__*/React.createElement("div", {
    className: "abg-progress__meta"
  }, label && /*#__PURE__*/React.createElement("span", {
    className: "abg-progress__label"
  }, label), showValue && /*#__PURE__*/React.createElement("span", {
    className: "abg-progress__value"
  }, Math.round(pct), "%")), /*#__PURE__*/React.createElement("div", {
    className: "abg-progress__track",
    style: {
      '--_h': `${height}px`
    },
    role: "progressbar",
    "aria-valuenow": value,
    "aria-valuemax": max
  }, /*#__PURE__*/React.createElement("div", {
    className: "abg-progress__fill",
    style: {
      width: `${pct}%`
    }
  })));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const INPUT_CSS = `
.abg-field{ display: flex; flex-direction: column; gap: 6px; font-family: var(--font-body); }
.abg-field__label{ font-size: var(--text-sm); font-weight: var(--fw-semibold); color: var(--text-strong); }
.abg-field__label .req{ color: var(--brand); margin-left: 2px; }
.abg-field__hint{ font-size: var(--text-xs); color: var(--text-muted); }
.abg-field__error{ font-size: var(--text-xs); color: var(--danger); font-weight: var(--fw-medium); }
.abg-input-wrap{ position: relative; display: flex; align-items: center; }
.abg-input{
  width: 100%; font-family: var(--font-body); font-size: var(--text-md); color: var(--text-strong);
  background: var(--surface-raised); border: var(--border-width-strong) solid var(--border-default);
  border-radius: var(--radius-md); padding: 10px 14px; transition: var(--transition-control);
  box-shadow: var(--shadow-inset);
}
.abg-input::placeholder{ color: var(--text-faint); }
.abg-input:hover{ border-color: var(--border-strong); }
.abg-input:focus{ outline: none; border-color: var(--brand); box-shadow: var(--focus-ring); }
.abg-input[disabled]{ background: var(--clay-100); color: var(--text-faint); cursor: not-allowed; box-shadow: none; }
.abg-input--has-adorn{ padding-left: 42px; }
.abg-field--error .abg-input{ border-color: var(--danger); }
.abg-field--error .abg-input:focus{ box-shadow: 0 0 0 3px rgba(193,59,36,.25); }
.abg-input__adorn{ position: absolute; left: 14px; display: inline-flex; color: var(--text-faint); pointer-events: none; }
.abg-input__adorn svg{ width: 18px; height: 18px; }
`;
let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'input');
  el.textContent = INPUT_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/** Labelled text input with hint, error, and leading adornment support. */
function Input({
  label,
  hint,
  error,
  required = false,
  adornment = null,
  id,
  className = '',
  ...rest
}) {
  ensureStyles();
  const fid = id || `abg-input-${Math.random().toString(36).slice(2, 8)}`;
  const wrapCls = ['abg-field', error ? 'abg-field--error' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", {
    className: wrapCls
  }, label && /*#__PURE__*/React.createElement("label", {
    className: "abg-field__label",
    htmlFor: fid
  }, label, required && /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("div", {
    className: "abg-input-wrap"
  }, adornment && /*#__PURE__*/React.createElement("span", {
    className: "abg-input__adorn"
  }, adornment), /*#__PURE__*/React.createElement("input", _extends({
    id: fid,
    className: `abg-input${adornment ? ' abg-input--has-adorn' : ''}`,
    "aria-invalid": !!error
  }, rest))), error ? /*#__PURE__*/React.createElement("span", {
    className: "abg-field__error"
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    className: "abg-field__hint"
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/learn/FidelTile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const FIDEL_CSS = `
.abg-fidel{
  --_bg: var(--surface-raised); --_bd: var(--border-default); --_fg: var(--text-strong);
  appearance: none; cursor: pointer; font-family: var(--font-body);
  display: inline-flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 4px; background: var(--_bg); color: var(--_fg);
  border: var(--border-width-strong) solid var(--_bd); border-radius: var(--radius-lg);
  box-shadow: var(--shadow-xs); transition: var(--transition-control); position: relative;
  aspect-ratio: 1; width: 100%;
}
.abg-fidel:hover{ border-color: var(--brand); box-shadow: var(--shadow-md); transform: translateY(-2px); }
.abg-fidel:active{ transform: translateY(0); box-shadow: var(--shadow-xs); }
.abg-fidel:focus-visible{ outline: none; box-shadow: var(--focus-ring); }
.abg-fidel__char{ font-family: var(--font-fidel); font-weight: 500; line-height: 1; }
.abg-fidel__rom{ font-size: var(--text-sm); color: var(--text-muted); font-weight: var(--fw-semibold); letter-spacing: .01em; }
.abg-fidel--sm .abg-fidel__char{ font-size: 28px; } .abg-fidel--sm{ border-radius: var(--radius-md); }
.abg-fidel--md .abg-fidel__char{ font-size: 40px; }
.abg-fidel--lg .abg-fidel__char{ font-size: 60px; }

.abg-fidel--selected{ --_bg: var(--brand-soft); --_bd: var(--brand); --_fg: var(--vermilion-700); box-shadow: var(--focus-ring); }
.abg-fidel--selected .abg-fidel__rom{ color: var(--brand-on-soft); }
.abg-fidel--correct{ --_bg: var(--success-soft); --_bd: var(--highland-400); --_fg: var(--highland-600); }
.abg-fidel--correct .abg-fidel__rom{ color: var(--highland-500); }
.abg-fidel--wrong{ --_bg: var(--danger-soft); --_bd: var(--vermilion-500); --_fg: var(--vermilion-700); }
.abg-fidel--ghost{ --_bg: transparent; --_bd: var(--border-subtle); box-shadow: none; }
.abg-fidel__badge{ position: absolute; top: 8px; right: 8px; width: 18px; height: 18px; border-radius: var(--radius-pill); display: none; align-items: center; justify-content: center; color: #fff; }
.abg-fidel__badge svg{ width: 12px; height: 12px; }
.abg-fidel--correct .abg-fidel__badge{ display: inline-flex; background: var(--highland-400); }
.abg-fidel--wrong .abg-fidel__badge{ display: inline-flex; background: var(--vermilion-500); }
`;
let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'fidel');
  el.textContent = FIDEL_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/**
 * The signature Abugida control: a tappable Geʼez character tile showing the
 * fidel glyph above its romanization. Used throughout lessons and quizzes.
 */
function FidelTile({
  char,
  romanization,
  size = 'md',
  state = 'default',
  showRomanization = true,
  className = '',
  ...rest
}) {
  ensureStyles();
  const cls = ['abg-fidel', `abg-fidel--${size}`, state !== 'default' ? `abg-fidel--${state}` : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("button", _extends({
    className: cls
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "abg-fidel__char"
  }, char), showRomanization && romanization && /*#__PURE__*/React.createElement("span", {
    className: "abg-fidel__rom"
  }, romanization), /*#__PURE__*/React.createElement("span", {
    className: "abg-fidel__badge",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": state === 'wrong' ? 'x' : 'check'
  })));
}
Object.assign(__ds_scope, { FidelTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/learn/FidelTile.jsx", error: String((e && e.message) || e) }); }

// components/learn/LessonCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const LESSON_CSS = `
.abg-lesson{
  display: flex; align-items: center; gap: var(--space-4); width: 100%; text-align: left;
  background: var(--surface-raised); border: var(--border-width) solid var(--border-subtle);
  border-radius: var(--radius-lg); padding: var(--space-4); cursor: pointer;
  transition: var(--transition-control); box-shadow: var(--shadow-sm); font-family: var(--font-body);
  appearance: none;
}
.abg-lesson:hover{ box-shadow: var(--shadow-md); transform: translateY(-2px); border-color: var(--border-default); }
.abg-lesson:active{ transform: translateY(0); }
.abg-lesson:focus-visible{ outline: none; box-shadow: var(--focus-ring); }
.abg-lesson__glyph{
  flex: none; width: 60px; height: 60px; border-radius: var(--radius-md);
  display: flex; align-items: center; justify-content: center;
  font-family: var(--font-fidel); font-size: 34px; font-weight: 500; line-height: 1;
  background: var(--brand-soft); color: var(--vermilion-600);
}
.abg-lesson__body{ flex: 1; min-width: 0; }
.abg-lesson__title{ font-size: var(--text-md); font-weight: var(--fw-bold); color: var(--text-strong); margin: 0; }
.abg-lesson__sub{ font-size: var(--text-sm); color: var(--text-muted); margin: 2px 0 10px; }
.abg-lesson__track{ height: 7px; background: var(--clay-200); border-radius: var(--radius-pill); overflow: hidden; }
.abg-lesson__fill{ height: 100%; background: var(--saffron-400); border-radius: var(--radius-pill); transition: width var(--dur-slow) var(--ease-out); }
.abg-lesson__chev{ flex: none; color: var(--text-faint); display: inline-flex; }
.abg-lesson__chev svg{ width: 20px; height: 20px; }

.abg-lesson--done .abg-lesson__glyph{ background: var(--success-soft); color: var(--highland-500); }
.abg-lesson--done .abg-lesson__fill{ background: var(--highland-400); }
.abg-lesson--locked{ opacity: .55; cursor: not-allowed; box-shadow: none; }
.abg-lesson--locked:hover{ transform: none; box-shadow: none; border-color: var(--border-subtle); }
.abg-lesson--locked .abg-lesson__glyph{ background: var(--clay-100); color: var(--text-faint); }
`;
let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'lessoncard');
  el.textContent = LESSON_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/** A lesson row: fidel glyph, title, subtitle, and progress toward mastery. */
function LessonCard({
  glyph = 'ሀ',
  title,
  subtitle,
  progress = 0,
  status = 'active',
  className = '',
  ...rest
}) {
  ensureStyles();
  const locked = status === 'locked';
  const cls = ['abg-lesson', `abg-lesson--${status}`, className].filter(Boolean).join(' ');
  const pct = status === 'done' ? 100 : Math.max(0, Math.min(100, progress));
  return /*#__PURE__*/React.createElement("button", _extends({
    className: cls,
    disabled: locked
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "abg-lesson__glyph"
  }, locked ? /*#__PURE__*/React.createElement("i", {
    "data-lucide": "lock"
  }) : glyph), /*#__PURE__*/React.createElement("span", {
    className: "abg-lesson__body"
  }, /*#__PURE__*/React.createElement("span", {
    className: "abg-lesson__title"
  }, title), subtitle && /*#__PURE__*/React.createElement("span", {
    className: "abg-lesson__sub"
  }, subtitle), /*#__PURE__*/React.createElement("span", {
    className: "abg-lesson__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "abg-lesson__fill",
    style: {
      width: `${pct}%`
    }
  }))), /*#__PURE__*/React.createElement("span", {
    className: "abg-lesson__chev",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": status === 'done' ? 'check-circle-2' : 'chevron-right'
  })));
}
Object.assign(__ds_scope, { LessonCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/learn/LessonCard.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TABS_CSS = `
.abg-tabs{ display: flex; gap: 4px; font-family: var(--font-body); }
.abg-tabs--underline{ gap: 22px; border-bottom: var(--border-width) solid var(--border-subtle); }
.abg-tabs--pill{ background: var(--clay-100); padding: 4px; border-radius: var(--radius-pill); gap: 2px; }
.abg-tab{
  appearance: none; border: none; background: transparent; cursor: pointer;
  font-family: var(--font-body); font-weight: var(--fw-semibold); font-size: var(--text-sm);
  color: var(--text-muted); transition: var(--transition-control); white-space: nowrap;
  display: inline-flex; align-items: center; gap: 7px;
}
.abg-tab:hover{ color: var(--text-strong); }
.abg-tab:focus-visible{ outline: none; box-shadow: var(--focus-ring); border-radius: var(--radius-sm); }
.abg-tab svg{ width: 1.05em; height: 1.05em; }

.abg-tabs--underline .abg-tab{ padding: 12px 0 14px; position: relative; }
.abg-tabs--underline .abg-tab[aria-selected="true"]{ color: var(--text-strong); }
.abg-tabs--underline .abg-tab[aria-selected="true"]::after{
  content:""; position: absolute; left: 0; right: 0; bottom: -1px; height: 2.5px;
  background: var(--brand); border-radius: var(--radius-pill);
}
.abg-tabs--pill .abg-tab{ padding: 8px 16px; border-radius: var(--radius-pill); }
.abg-tabs--pill .abg-tab[aria-selected="true"]{ background: var(--surface-raised); color: var(--text-strong); box-shadow: var(--shadow-xs); }
.abg-tab__count{ font-size: var(--text-2xs); font-weight: var(--fw-bold); background: var(--clay-200); color: var(--text-muted); padding: 1px 6px; border-radius: var(--radius-pill); }
.abg-tab[aria-selected="true"] .abg-tab__count{ background: var(--brand-soft); color: var(--brand-on-soft); }
`;
let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'tabs');
  el.textContent = TABS_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/** Horizontal tab switcher. Controlled via `value` + `onChange`. */
function Tabs({
  items = [],
  value,
  onChange,
  variant = 'underline',
  className = '',
  ...rest
}) {
  ensureStyles();
  const cls = ['abg-tabs', `abg-tabs--${variant}`, className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls,
    role: "tablist"
  }, rest), items.map(it => {
    const key = it.value ?? it.label;
    const selected = key === value;
    return /*#__PURE__*/React.createElement("button", {
      key: key,
      className: "abg-tab",
      role: "tab",
      "aria-selected": selected,
      onClick: () => onChange && onChange(key)
    }, it.icon, it.label, it.count != null && /*#__PURE__*/React.createElement("span", {
      className: "abg-tab__count"
    }, it.count));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/ornament/CrossLattice.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* ------------------------------------------------------------------
   The Ethiopian cross as a ground texture.

   Not a Latin or Greek cross: the Ethiopian form is latticed and
   interwoven, with flared arms and openwork between them — the shape
   you see cut into Lalibela, hammered into Axum hand crosses, and
   painted into manuscript headpieces. Drawn on a cell grid so it stays
   rectilinear and never reads as clip art.
   ------------------------------------------------------------------ */

let latId = 0;
const nextLatId = () => `lat-${(++latId).toString(36)}-${Math.random().toString(36).slice(2, 7)}`;

/* Counted draft, 11×11. Each arm WIDENS toward its tip — the flare is
   what separates an Ethiopian cross from a Latin or Greek one — and the
   notches where the arms meet leave the openwork the form is known for. */
const DRAFT = ['..#######..', '..#######..', '##.#####.##', '###.###.###', '###########', '###########', '###########', '###.###.###', '##.#####.##', '..#######..', '..#######..'];
function CrossLattice({
  cell = 5,
  color = 'var(--pigment-tiqur)',
  opacity = 0.09,
  gutter = 3,
  className = '',
  style,
  ...rest
}) {
  const idRef = React.useRef(null);
  if (!idRef.current) idRef.current = nextLatId();
  const id = idRef.current;
  const n = DRAFT.length;
  const px = Number(cell) || 5;
  const gut = Number(gutter) || 0;
  const op = Number(opacity);
  const span = (n + gut) * px;
  const rects = [];
  for (let r = 0; r < n; r++) {
    for (let c = 0; c < n; c++) {
      if (DRAFT[r][c] !== '#') continue;
      rects.push(/*#__PURE__*/React.createElement("rect", {
        key: `${r}-${c}`,
        x: c * px,
        y: r * px,
        width: px + 0.3,
        height: px + 0.3,
        shapeRendering: "crispEdges"
      }));
    }
  }
  return /*#__PURE__*/React.createElement("svg", _extends({
    width: "100%",
    height: "100%",
    role: "presentation",
    className: className,
    style: {
      display: 'block',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("pattern", {
    id: id,
    patternUnits: "userSpaceOnUse",
    width: span,
    height: span
  }, /*#__PURE__*/React.createElement("g", {
    fill: color,
    opacity: Number.isFinite(op) ? op : 0.09,
    transform: `translate(${gut * px / 2} ${gut * px / 2})`
  }, rects))), /*#__PURE__*/React.createElement("rect", {
    width: "100%",
    height: "100%",
    fill: `url(#${id})`
  }));
}
Object.assign(__ds_scope, { CrossLattice });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/ornament/CrossLattice.jsx", error: String((e && e.message) || e) }); }

// components/ornament/FidelField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* ------------------------------------------------------------------
   FIDEL AS TEXTURE

   The Geʼez script is one of the few indigenous African writing systems
   still in daily use, and its rounded, blocky rhythm is recognisable
   long before it is readable. Used large and faint it works the way
   kanji does in Japanese design: confident, specific, and unmistakably
   from one place.

   This is decoration made of language, so it is hidden from the
   accessibility tree and never selectable.
   ------------------------------------------------------------------ */

/* The base order (ግዕዝ) of every family — the script's own index. */
const BASE_ORDER = 'ሀለሐመሠረሰቀበተኀነአከወዐዘየደገጠጰጸፀፈፐ';

/** Deterministic per-index pick, so the field never reshuffles on re-render. */
function pick(source, i, seed) {
  const h = i * 2654435761 + seed * 40503 >>> 0;
  return source[h % source.length];
}
function FidelField({
  mode = 'field',
  chars = BASE_ORDER,
  size = 96,
  gap = 0.35,
  opacity = 0.05,
  color = 'currentColor',
  seed = 7,
  rotate = 0,
  text,
  className = '',
  style,
  ...rest
}) {
  /* Coerce so templates and HTML attributes may pass strings. */
  const fs = Number(size) || 96;
  const gp = Number(gap);
  const g = Number.isFinite(gp) ? gp : 0.35;
  const op = Number(opacity);
  const rot = Number(rotate) || 0;
  const base = {
    position: 'absolute',
    inset: 0,
    overflow: 'hidden',
    pointerEvents: 'none',
    userSelect: 'none',
    fontFamily: 'var(--font-fidel)',
    color,
    opacity: Number.isFinite(op) ? op : 0.05,
    ...style
  };

  /* One enormous character, bled off the edge. */
  if (mode === 'watermark') {
    return /*#__PURE__*/React.createElement("div", _extends({
      "aria-hidden": "true",
      className: className,
      style: base
    }, rest), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        insetInlineEnd: '-0.16em',
        bottom: '-0.34em',
        fontSize: fs,
        lineHeight: 0.78,
        whiteSpace: 'nowrap',
        transform: rot ? `rotate(${rot}deg)` : undefined
      }
    }, text || chars[0]));
  }

  /* A vertical running column, as down the margin of a codex. */
  if (mode === 'column') {
    const n = Math.max(1, Math.round(1200 / (fs * (1 + g))));
    return /*#__PURE__*/React.createElement("div", _extends({
      "aria-hidden": "true",
      className: className,
      style: base
    }, rest), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        fontSize: fs,
        lineHeight: 1 + g
      }
    }, Array.from({
      length: n
    }, (_, i) => /*#__PURE__*/React.createElement("span", {
      key: i
    }, text ? text[i % text.length] : pick(chars, i, seed)))));
  }

  /* A repeating field — the default. Rows are offset by half a cell so
     the grid reads as woven cloth rather than a spreadsheet. */
  const step = fs * (1 + g);
  const rows = Math.ceil(1100 / step) + 1;
  const cols = Math.ceil(1800 / step) + 1;
  return /*#__PURE__*/React.createElement("div", _extends({
    "aria-hidden": "true",
    className: className,
    style: base
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      transform: rot ? `rotate(${rot}deg) scale(1.5)` : undefined
    }
  }, Array.from({
    length: rows
  }, (_, r) => /*#__PURE__*/React.createElement("div", {
    key: r,
    style: {
      display: 'flex',
      gap: fs * g,
      fontSize: fs,
      lineHeight: 1 + g,
      marginInlineStart: r % 2 ? step / 2 : 0,
      whiteSpace: 'nowrap'
    }
  }, Array.from({
    length: cols
  }, (_, c) => /*#__PURE__*/React.createElement("span", {
    key: c
  }, text ? text[(r * cols + c) % text.length] : pick(chars, r * cols + c, seed)))))));
}
FidelField.baseOrder = BASE_ORDER;
Object.assign(__ds_scope, { FidelField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/ornament/FidelField.jsx", error: String((e && e.message) || e) }); }

// components/ornament/GeezNumeral.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* ------------------------------------------------------------------
   Geʼez numerals — ፩ ፪ ፫ …
   Ethiopia counts with its own figures, derived from Greek letters and
   marked with over- and under-bars. A learning product that renders
   "Lesson 3" in Latin digits has already conceded the point; this
   renders ትምህርት ፫.
   ------------------------------------------------------------------ */

const ONES = ['', '፩', '፪', '፫', '፬', '፭', '፮', '፯', '፰', '፱'];
const TENS = ['', '፲', '፳', '፴', '፵', '፶', '፷', '፸', '፹', '፺'];
const HUNDRED = '፻';
const MYRIAD = '፼';

/** 1–99 → Geʼez. */
function pair(n) {
  if (n <= 0) return '';
  return TENS[Math.floor(n / 10)] + ONES[n % 10];
}

/**
 * Convert a positive integer to Geʼez figures.
 * Handles 1–99,999,999, which covers every counter a product will show.
 * Zero has no Geʼez figure — the system is additive — so it returns ''.
 */
function toGeez(value) {
  let n = Math.floor(Math.abs(Number(value) || 0));
  if (n < 1) return '';
  if (n < 100) return pair(n);
  const myriads = Math.floor(n / 10000);
  const rest = n % 10000;
  let out = '';
  if (myriads) {
    // ፼ alone carries a leading one, exactly as ፻ does.
    out += (myriads === 1 ? '' : toGeez(myriads)) + MYRIAD;
  }
  const hundreds = Math.floor(rest / 100);
  const units = rest % 100;
  if (hundreds) out += (hundreds === 1 ? '' : pair(hundreds)) + HUNDRED;
  if (units) out += pair(units);
  return out;
}

/**
 * Renders a number in Geʼez figures, with the Latin value kept in the
 * accessibility tree so screen readers and copy-paste still work.
 */
function GeezNumeral({
  value,
  showLatin = false,
  tone = 'inherit',
  className = '',
  style,
  ...rest
}) {
  const geez = toGeez(value);
  const color = {
    inherit: undefined,
    rubric: 'var(--pigment-kin)',
    gold: 'var(--pigment-werq)',
    muted: 'var(--text-muted)'
  }[tone];
  return /*#__PURE__*/React.createElement("span", _extends({
    className: className,
    style: {
      fontFamily: 'var(--font-fidel)',
      color,
      fontFeatureSettings: '"liga" 0',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, geez || '—'), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      width: 1,
      height: 1,
      overflow: 'hidden',
      clip: 'rect(0 0 0 0)',
      whiteSpace: 'nowrap'
    }
  }, value), showLatin && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.7em',
      color: 'var(--text-faint)',
      marginInlineStart: '0.4em'
    },
    "aria-hidden": "true"
  }, value));
}
Object.assign(__ds_scope, { toGeez, GeezNumeral });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/ornament/GeezNumeral.jsx", error: String((e && e.message) || e) }); }

// components/ornament/SectionMark.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* ------------------------------------------------------------------
   Geʼez punctuation as UI furniture.
   ፠ opens a titled section · ፨ separates movements of a text ·
   ። ends a statement · ፣ ፤ ፥ divide series, lists, quotations.
   These are the marks the script actually uses. Reaching for a bullet
   or an em-dash instead is the generic choice.
   ------------------------------------------------------------------ */

const MARKS = {
  section: '፠',
  paragraph: '፨',
  stop: '።',
  comma: '፣',
  colon: '፤',
  preface: '፥'
};

/**
 * A divider built from Geʼez punctuation. With `rules` it becomes a
 * full-width section break; without, an inline separator.
 */
function SectionMark({
  mark = 'paragraph',
  rules = true,
  tone = 'rubric',
  size = 'md',
  label,
  className = '',
  style,
  ...rest
}) {
  const glyph = MARKS[mark] || MARKS.paragraph;
  const color = {
    rubric: 'var(--pigment-kin)',
    gold: 'var(--pigment-werq)',
    indigo: 'var(--pigment-semayawi)',
    muted: 'var(--text-faint)'
  }[tone] || tone;
  const fs = {
    sm: 14,
    md: 20,
    lg: 30
  }[size] || 20;
  const rule = key => /*#__PURE__*/React.createElement("span", {
    key: key,
    "aria-hidden": "true",
    style: {
      flex: 1,
      height: 1,
      background: 'currentColor',
      opacity: 0.28,
      minWidth: 16
    }
  });
  if (!rules) {
    return /*#__PURE__*/React.createElement("span", _extends({
      "aria-hidden": "true",
      className: className,
      style: {
        color,
        fontFamily: 'var(--font-fidel)',
        fontSize: fs,
        lineHeight: 1,
        ...style
      }
    }, rest), glyph);
  }
  return /*#__PURE__*/React.createElement("div", _extends({
    className: className,
    role: "separator",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4, 16px)',
      color,
      ...style
    }
  }, rest), rule('l'), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-xs)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: 'var(--tracking-caps)',
      textTransform: 'uppercase',
      whiteSpace: 'nowrap'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: fs,
      lineHeight: 1
    }
  }, glyph), rule('r'));
}
Object.assign(__ds_scope, { SectionMark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/ornament/SectionMark.jsx", error: String((e && e.message) || e) }); }

// components/ornament/Tibeb.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* ------------------------------------------------------------------
   ጥብብ TIBEB — the woven band.

   Everything here is built on a discrete cell grid, because tibeb IS a
   grid: warp and weft. A loom cannot make a curve, so neither does this
   component. Each motif is written as a COUNTED DRAFT — the same way a
   weaver reads a pattern off squared paper — which keeps the geometry
   honest to the craft and makes it trivial to tune.

   THE NETELA RULE
   The field stays cream; the colour lives in the band. A netela is a
   white shawl with one blazing border, and that contrast is the entire
   effect. Saturated colour anywhere else and the band stops being
   special. Use these to EDGE a surface — never to fill one.
   ------------------------------------------------------------------ */

/* Letters index the palette; '.' is ground (left transparent).
   Drafts are read top row first, exactly like a weaving pattern. */
const DRAFTS = {
  /* The signature netela lozenge — concentric diamonds around a core. */
  diamond: ['....A....', '...AAA...', '..AABAA..', '.AABCBAA.', 'AABCDCBAA', '.AABCBAA.', '..AABAA..', '...AAA...', '....A....'],
  /* Two parallel zigzag courses — the running chevron. */
  chevron: ['AA....AA', '.AA..AA.', '..AAAA..', 'BB....BB', '.BB..BB.', '..BBBB..'],
  /* Stepped pyramid — the Aksumite stele and rock-hewn terrace profile. */
  terrace: ['....BB....', '...BAAB...', '..BAAAAB..', '.BAAAAAAB.', 'BAAAAAAAAB', 'BBBBBBBBBB'],
  /* Ethiopian cross — arms that flare toward their ends, contrasting
     core. Nothing like a Latin or Greek cross, which do not flare. */
  cross: ['....AAA....', '....AAA....', '..AAAAAAA..', '..AABBBAA..', '.AAABBBAAA.', '..AABBBAA..', '..AAAAAAA..', '....AAA....', '....AAA....'],
  /* Nested squares — the boxed motif scattered across a netela field. */
  box: ['AAAAA', 'A...A', 'A.B.A', 'A...A', 'AAAAA'],
  /* The checkered selvedge that frames every band in the real cloth. */
  ladder: ['ABAB', 'BABA'],
  /* The quiet band — a counted dash for dense UI. */
  dash: ['AABB']
};

/* Named thread sets. Saturated colour is confined to these. */
const PALETTES = {
  /* Coffee ceremony — ochre, rust, deep brown, cream. The default. */
  buna: ['#A8412A', '#C98A2B', '#4A2E1E', '#F7EFE1'],
  /* Classic netela border: lampblack ground, gold, red, green. */
  netela: ['#241A14', '#C98A2B', '#B4341F', '#1F6F52'],
  /* The full saturated cloth, for one hero band only. */
  bright: ['#C4321C', '#E8B02A', '#1F6F52', '#1D4A7A'],
  /* Ink and gold — the manuscript register. */
  scribe: ['#241A14', '#C98A2B', '#A8412A', '#F7EFE1']
};
let tibId = 0;
const nextTibId = () => `tibeb-${(++tibId).toString(36)}-${Math.random().toString(36).slice(2, 7)}`;

/** Expand a draft into cells, optionally wrapped in a checkered selvedge. */
function buildGrid(motif, frame) {
  const draft = DRAFTS[motif] || DRAFTS.diamond;
  if (!frame || motif === 'ladder' || motif === 'dash') return draft;
  const w = draft[0].length;
  const checker = o => Array.from({
    length: w
  }, (_, i) => (i + o) % 2 ? 'F' : 'E').join('');
  const blank = '.'.repeat(w);
  return [checker(0), blank, ...draft, blank, checker(0)];
}

/**
 * Tibeb — a woven band. Tiles seamlessly to any width via an SVG pattern
 * in user-space units, so it never stretches, blurs, or resamples.
 */
function Tibeb({
  motif = 'diamond',
  cell = 3,
  palette = 'buna',
  frame = true,
  frameColors,
  ground,
  flip = false,
  className = '',
  style,
  ...rest
}) {
  const idRef = React.useRef(null);
  if (!idRef.current) idRef.current = nextTibId();
  const id = idRef.current;
  const threads = Array.isArray(palette) ? palette : PALETTES[palette] || PALETTES.buna;
  const fc = frameColors || [threads[2] || '#241A14', threads[1] || '#C98A2B'];
  const ink = {
    A: threads[0],
    B: threads[1],
    C: threads[2],
    D: threads[3],
    E: fc[0],
    F: fc[1]
  };

  /* Coerce so templates and HTML attributes may pass strings. */
  const px = Number(cell) || 3;
  const grid = buildGrid(motif, frame !== false && frame !== 'false');
  const rows = grid.length;
  const cols = grid[0].length;
  const H = rows * px;
  const W = cols * px;
  const rects = [];
  for (let r = 0; r < rows; r++) {
    const line = grid[r];
    for (let c = 0; c < cols; c++) {
      const ch = line[c];
      if (!ch || ch === '.') continue;
      const fill = ink[ch];
      if (!fill) continue;
      /* Cells are drawn a hair oversized so neighbours butt cleanly and
         no seam shows between them at fractional device pixels. */
      rects.push(/*#__PURE__*/React.createElement("rect", {
        key: `${r}-${c}`,
        x: c * px,
        y: r * px,
        width: px + 0.35,
        height: px + 0.35,
        fill: fill,
        shapeRendering: "crispEdges"
      }));
    }
  }
  return /*#__PURE__*/React.createElement("svg", _extends({
    width: "100%",
    height: H,
    role: "presentation",
    className: className,
    style: {
      display: 'block',
      transform: flip ? 'scaleY(-1)' : undefined,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("pattern", {
    id: id,
    patternUnits: "userSpaceOnUse",
    width: W,
    height: H
  }, ground && /*#__PURE__*/React.createElement("rect", {
    width: W,
    height: H,
    fill: ground
  }), rects)), /*#__PURE__*/React.createElement("rect", {
    width: "100%",
    height: H,
    fill: `url(#${id})`
  }));
}
Tibeb.motifs = Object.keys(DRAFTS);
Tibeb.palettes = PALETTES;
Object.assign(__ds_scope, { Tibeb });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/ornament/Tibeb.jsx", error: String((e && e.message) || e) }); }

// components/ornament/ManuscriptFrame.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* ------------------------------------------------------------------
   The page of a Geʼez codex, as a layout primitive: a woven crown, a
   rubricated title, the text block, and an outer margin reserved for
   the scribe's gloss. Sections are numbered in Geʼez figures.
   ------------------------------------------------------------------ */

const FRAME_CSS = `
.abg-ms{ position: relative; background: var(--surface-raised); border: var(--border-width) solid var(--border-subtle); border-radius: var(--radius-sm); overflow: clip; }
.abg-ms__body{ display: grid; gap: var(--space-6, 32px); padding: var(--space-6, 32px); }
.abg-ms--gloss .abg-ms__body{ grid-template-columns: 1fr minmax(0, 14ch); }
.abg-ms__head{ display: flex; align-items: baseline; gap: var(--space-3, 12px); margin-bottom: var(--space-4, 16px); }
.abg-ms__num{ font-size: var(--text-xl); }
.abg-ms__title{ font-family: var(--font-display); font-size: var(--text-2xl); color: var(--pigment-kin); font-weight: var(--fw-medium); line-height: var(--leading-snug); }
.abg-ms__gloss{ font-family: var(--font-fidel); font-size: var(--text-xs); line-height: var(--leading-snug); color: var(--pigment-kin); border-inline-start: 1px solid var(--border-subtle); padding-inline-start: var(--space-4, 16px); }
@media (max-width: 720px){ .abg-ms--gloss .abg-ms__body{ grid-template-columns: 1fr; } .abg-ms__gloss{ border-inline-start: 0; padding-inline-start: 0; } }
`;
let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'manuscript-frame');
  el.textContent = FRAME_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/** A manuscript page: woven crown, rubricated title, text block, margin gloss. */
function ManuscriptFrame({
  title,
  number,
  gloss,
  motif = 'diamond',
  crown = true,
  foot = true,
  className = '',
  children,
  ...rest
}) {
  ensureStyles();
  const cls = ['abg-ms', gloss ? 'abg-ms--gloss' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, rest), crown && /*#__PURE__*/React.createElement(__ds_scope.Tibeb, {
    motif: motif,
    cell: 3,
    palette: "scribe",
    ground: "var(--surface-raised)"
  }), /*#__PURE__*/React.createElement("div", {
    className: "abg-ms__body"
  }, /*#__PURE__*/React.createElement("div", null, (title || number != null) && /*#__PURE__*/React.createElement("div", {
    className: "abg-ms__head"
  }, number != null && /*#__PURE__*/React.createElement(__ds_scope.GeezNumeral, {
    className: "abg-ms__num",
    value: number,
    tone: "gold"
  }), title && /*#__PURE__*/React.createElement("div", {
    className: "abg-ms__title"
  }, title)), children), gloss && /*#__PURE__*/React.createElement("aside", {
    className: "abg-ms__gloss"
  }, gloss)), foot && /*#__PURE__*/React.createElement(__ds_scope.Tibeb, {
    motif: "dash",
    cell: 3,
    palette: "scribe",
    ground: "var(--surface-raised)",
    flip: true
  }));
}
Object.assign(__ds_scope, { ManuscriptFrame });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/ornament/ManuscriptFrame.jsx", error: String((e && e.message) || e) }); }

// ui_kits/learn-app/AppShell.jsx
try { (() => {
/* App shell with left sidebar — wraps Dashboard & Archive. */

function AppShell({
  active,
  onNavigate,
  onExit,
  children
}) {
  const {
    Avatar,
    Badge,
    Tibeb,
    GeezNumeral
  } = window.AbugidaDesignSystem_019e1e;
  const D = window.ABG_DATA;
  useLucide();
  const items = [{
    id: 'dashboard',
    label: 'Learn',
    icon: 'book-open'
  }, {
    id: 'review',
    label: 'Review',
    icon: 'repeat',
    count: 12
  }, {
    id: 'archive',
    label: 'Archive',
    icon: 'landmark'
  }];
  const NavItem = ({
    it
  }) => {
    const on = active === it.id;
    return /*#__PURE__*/React.createElement("button", {
      onClick: () => onNavigate(it.id),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        width: '100%',
        textAlign: 'left',
        padding: '11px 14px',
        borderRadius: 'var(--radius-md)',
        border: 'none',
        cursor: 'pointer',
        background: on ? 'var(--brand-soft)' : 'transparent',
        color: on ? 'var(--vermilion-700)' : 'var(--text-body)',
        fontFamily: 'var(--font-body)',
        fontWeight: on ? 700 : 600,
        fontSize: 15,
        transition: 'var(--transition-control)'
      }
    }, /*#__PURE__*/React.createElement(Ico, {
      n: it.icon,
      style: {
        width: 19
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1
      }
    }, it.label), it.count != null && /*#__PURE__*/React.createElement(Badge, {
      tone: on ? 'brand' : 'neutral'
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-fidel)'
      }
    }, /*#__PURE__*/React.createElement(GeezNumeral, {
      value: it.count
    }))));
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      minHeight: '100%',
      background: 'var(--surface-page)'
    },
    className: "bg-parchment"
  }, /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 244,
      flex: 'none',
      borderRight: '1px solid var(--border-subtle)',
      background: 'var(--surface-raised)',
      display: 'flex',
      flexDirection: 'column',
      padding: 18,
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '6px 8px 14px',
      cursor: 'pointer'
    },
    onClick: onExit
  }, /*#__PURE__*/React.createElement(Logo, {
    size: 22
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      margin: '0 -18px 14px'
    }
  }, /*#__PURE__*/React.createElement(Tibeb, {
    motif: "diamond",
    cell: 3,
    palette: "netela",
    ground: "var(--surface-raised)"
  })), items.map(it => /*#__PURE__*/React.createElement(NavItem, {
    key: it.id,
    it: it
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      borderTop: '1px solid var(--border-subtle)',
      paddingTop: 14,
      display: 'flex',
      alignItems: 'center',
      gap: 11
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: D.learner.name + ' Tesfaye',
    tint: "t1"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: 'var(--text-strong)'
    }
  }, D.learner.name, " Tesfaye"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)'
    }
  }, "A1 \xB7 Beginner")))), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      minWidth: 0,
      overflow: 'auto',
      maxHeight: '100%'
    }
  }, children));
}
Object.assign(window, {
  AppShell
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/learn-app/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/learn-app/Archive.jsx
try { (() => {
/* Cultural archive — the "coming soon" teaser surface. */

function Archive() {
  const {
    Card,
    Badge,
    Button,
    Input,
    Tibeb,
    FidelField,
    CrossLattice,
    GeezNumeral
  } = window.AbugidaDesignSystem_019e1e;
  const D = window.ABG_DATA;
  useLucide();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 980,
      margin: '0 auto',
      padding: '34px 40px 60px'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "lg",
    style: {
      background: 'var(--clay-900)',
      border: 'none',
      marginBottom: 28,
      overflow: 'hidden',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0
    }
  }, /*#__PURE__*/React.createElement(CrossLattice, {
    cell: 5,
    color: "#F7EFE1",
    opacity: 0.05
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 560
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "warning"
  }, "Coming soon"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 40,
      color: 'var(--clay-100)',
      margin: '16px 0 12px',
      lineHeight: 1.1
    }
  }, "A living archive of ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontStyle: 'italic',
      color: 'var(--saffron-300)'
    }
  }, "Ethiopian heritage"), "."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 17,
      color: 'var(--clay-300)',
      lineHeight: 1.55,
      maxWidth: 460
    }
  }, "Manuscripts, music, the coffee ceremony, proverbs and textiles \u2014 collected, explained, and kept for the next generation. Language first; the rest is on its way.")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: -10,
      top: -30,
      fontFamily: 'var(--font-fidel)',
      fontSize: 240,
      color: 'rgba(201,138,43,0.12)',
      lineHeight: 1,
      userSelect: 'none',
      pointerEvents: 'none'
    }
  }, "\u12A0")), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 21,
      color: 'var(--text-strong)',
      marginBottom: 10
    }
  }, "What we're gathering"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(Tibeb, {
    motif: "diamond",
    cell: 3,
    palette: "netela"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: 18,
      marginBottom: 36
    }
  }, D.archive.map((a, i) => /*#__PURE__*/React.createElement(Card, {
    key: a.title,
    padding: "none",
    interactive: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 132,
      background: 'var(--clay-100)',
      position: 'relative',
      overflow: 'hidden',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--clay-800)'
    }
  }, /*#__PURE__*/React.createElement(FidelField, {
    size: 54,
    opacity: 0.09,
    seed: i * 3 + 2
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      fontFamily: 'var(--font-fidel)',
      fontSize: 52,
      color: a.tint,
      lineHeight: 1
    }
  }, 'መሷቀበተነ'[i % 6]), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      bottom: 8,
      right: 10,
      fontSize: 10,
      fontFamily: 'var(--font-mono)',
      color: 'var(--clay-500)'
    }
  }, "image placeholder")), /*#__PURE__*/React.createElement(Tibeb, {
    motif: "dash",
    cell: 2,
    palette: "buna",
    frame: false
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 14,
      color: 'var(--saffron-500)'
    }
  }, /*#__PURE__*/React.createElement(GeezNumeral, {
    value: i + 1
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 18,
      color: 'var(--text-strong)'
    }
  }, a.title)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, a.sub))))), /*#__PURE__*/React.createElement(Card, {
    padding: "lg",
    accent: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 18,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 260
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 22,
      color: 'var(--text-strong)',
      marginBottom: 6
    }
  }, "Be the first to explore"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: 'var(--text-muted)',
      marginBottom: 14
    }
  }, "We'll email you once when the archive opens. No spam, ever."), /*#__PURE__*/React.createElement(Input, {
    label: "",
    placeholder: "you@example.com",
    adornment: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "mail"
    })
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg"
  }, "Notify me"))));
}
Object.assign(window, {
  Archive
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/learn-app/Archive.jsx", error: String((e && e.message) || e) }); }

// ui_kits/learn-app/Dashboard.jsx
try { (() => {
/* Learner home / dashboard. */

function Dashboard({
  onOpenLesson
}) {
  const {
    Card,
    Button,
    Badge,
    ProgressBar,
    LessonCard,
    FidelTile,
    Tibeb,
    GeezNumeral
  } = window.AbugidaDesignSystem_019e1e;
  const D = window.ABG_DATA;
  useLucide();

  /* Counts are written in Geʼez figures, and the day is the Ethiopian one —
     ነሐሴ, the twelfth month. A streak measured in a calendar the learner
     doesn't use is a streak measured in someone else's time. */
  const Stat = ({
    value,
    unit,
    label,
    tint
  }) => /*#__PURE__*/React.createElement(Card, {
    padding: "md",
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 34,
      lineHeight: 1,
      color: tint
    }
  }, /*#__PURE__*/React.createElement(GeezNumeral, {
    value: value
  })), unit && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      color: 'var(--text-muted)'
    }
  }, unit)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      marginTop: 8
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement(Tibeb, {
    motif: "dash",
    cell: 3,
    palette: "buna",
    ground: "var(--surface-raised)"
  })));
  const active = D.families.find(f => f.status === 'active');
  const done = D.families.filter(f => f.status === 'done' || f.status === 'active').length;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 980,
      margin: '0 auto',
      padding: '34px 40px 60px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 13,
      letterSpacing: '0.06em',
      color: 'var(--text-faint)'
    }
  }, "\u1228\u1261\u12D5 \u1361 \u1290\u1210\u1234 ", /*#__PURE__*/React.createElement(GeezNumeral, {
    value: 6
  }), " \u1240\u1295 \u1361 ", /*#__PURE__*/React.createElement(GeezNumeral, {
    value: 2018
  }), " \u12D3.\u121D"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 36,
      color: 'var(--text-strong)',
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-fidel)',
      color: 'var(--vermilion-600)'
    }
  }, D.learner.greeting), ", ", D.learner.name, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-fidel)'
    }
  }, "\u1362"))), /*#__PURE__*/React.createElement(Badge, {
    tone: "warning"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-fidel)'
    }
  }, /*#__PURE__*/React.createElement(GeezNumeral, {
    value: D.learner.streak
  })), " days unbroken")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    value: D.learner.streak,
    label: "Days unbroken",
    tint: "var(--pigment-werq)"
  }), /*#__PURE__*/React.createElement(Stat, {
    value: D.learner.mastered,
    label: "Letters mastered",
    tint: "var(--pigment-arenguade)"
  }), /*#__PURE__*/React.createElement(Stat, {
    value: D.learner.minutesToday,
    unit: "min",
    label: "Read today",
    tint: "var(--pigment-semayawi)"
  })), /*#__PURE__*/React.createElement(Card, {
    elevation: "raised",
    padding: "lg",
    accent: "var(--saffron-400)",
    style: {
      marginBottom: 30
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 78,
      height: 78,
      borderRadius: 'var(--radius-lg)',
      flex: 'none',
      background: 'var(--brand-soft)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-fidel)',
      fontSize: 46,
      color: 'var(--vermilion-600)'
    }
  }, active.glyph), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      color: 'var(--saffron-600)'
    }
  }, "Continue where you left off"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 24,
      color: 'var(--text-strong)',
      margin: '6px 0 12px'
    }
  }, active.name), /*#__PURE__*/React.createElement(ProgressBar, {
    value: active.progress,
    color: "gold",
    height: 8
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "gold",
    size: "lg",
    onClick: () => onOpenLesson(active),
    trailingIcon: /*#__PURE__*/React.createElement(Ico, {
      n: "arrow-right"
    })
  }, "Continue"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.5fr 1fr',
      gap: 30
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 21,
      color: 'var(--text-strong)'
    }
  }, "Your fidel path"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      fontWeight: 600,
      fontFamily: 'var(--font-fidel)'
    }
  }, /*#__PURE__*/React.createElement(GeezNumeral, {
    value: done
  }), " \u12A8 ", /*#__PURE__*/React.createElement(GeezNumeral, {
    value: 33
  }), " \u1264\u1270\u1230\u1265")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, D.families.map(f => /*#__PURE__*/React.createElement(LessonCard, {
    key: f.glyph,
    glyph: f.glyph,
    title: f.name,
    subtitle: f.status === 'done' ? 'Mastered · 7 letters' : f.status === 'locked' ? 'Locked' : '7 letters · 4 min',
    progress: f.progress,
    status: f.status,
    onClick: f.status === 'locked' ? undefined : () => onOpenLesson(f)
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 19,
      color: 'var(--text-strong)'
    }
  }, "Review"), /*#__PURE__*/React.createElement(Badge, {
    tone: "brand"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-fidel)'
    }
  }, /*#__PURE__*/React.createElement(GeezNumeral, {
    value: 12
  })), " due")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 8,
      marginBottom: 16
    }
  }, [{
    c: 'ሁ',
    r: 'hu'
  }, {
    c: 'ላ',
    r: 'la'
  }, {
    c: 'ሄ',
    r: 'he'
  }, {
    c: 'ም',
    r: 'mə'
  }].map(t => /*#__PURE__*/React.createElement(FidelTile, {
    key: t.c,
    char: t.c,
    romanization: t.r,
    size: "sm"
  }))), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    fullWidth: true,
    leadingIcon: /*#__PURE__*/React.createElement(Ico, {
      n: "repeat"
    })
  }, "Practice review")), /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 19,
      color: 'var(--text-strong)',
      marginBottom: 14
    }
  }, "Daily goal"), /*#__PURE__*/React.createElement(ProgressBar, {
    value: D.learner.dailyDone,
    max: D.learner.dailyGoal,
    color: "green",
    label: `${D.learner.dailyDone} / ${D.learner.dailyGoal} min`,
    showValue: true
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      marginTop: 12
    }
  }, "5 more minutes keeps your streak alive.")))));
}
Object.assign(window, {
  Dashboard
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/learn-app/Dashboard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/learn-app/Landing.jsx
try { (() => {
/* Abugida — landing.

   Three rules, applied literally:
   1. FIDEL AS TEXTURE. Oversized, faint Geʼez sits behind the hero and
      the footer. Recognisable as Ethiopian long before it is legible.
   2. TIBEB AS STRUCTURE. Every divider, cap, and section break is a
      woven band on a counted grid — not a hairline rule.
   3. THE NETELA RULE. The field stays cream; saturated colour lives
      only inside the bands. */

function Landing({
  onStart,
  onArchive
}) {
  const {
    Button,
    Tibeb,
    CrossLattice,
    FidelField,
    GeezNumeral
  } = window.AbugidaDesignSystem_019e1e;
  const D = window.ABG_DATA;
  const ha = D.families[0].orders;
  const ORDERS = ['ግዕዝ', 'ካዕብ', 'ሣልስ', 'ራብዕ', 'ኃምስ', 'ሳድስ', 'ሳብዕ'];
  const nav = {
    fontFamily: 'var(--font-body)',
    fontSize: 15,
    fontWeight: 600,
    color: 'var(--buna-bean)',
    cursor: 'pointer'
  };
  const sep = {
    fontFamily: 'var(--font-fidel)',
    color: 'var(--buna-rust)',
    fontSize: 15,
    opacity: 0.6
  };
  const shell = {
    maxWidth: 1140,
    margin: '0 auto',
    padding: '0 44px'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--buna-cream)',
      minHeight: '100%'
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      ...shell,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '22px 44px 18px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 26,
      color: 'var(--buna-rust)',
      lineHeight: 1
    }
  }, "\u12A0\u1261\u130A\u12F3"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 12,
      fontWeight: 700,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--buna-ash)'
    }
  }, "Abugida")), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: nav
  }, "Learn"), /*#__PURE__*/React.createElement("span", {
    style: sep
  }, "\u1363"), /*#__PURE__*/React.createElement("span", {
    style: nav,
    onClick: onArchive
  }, "Archive"), /*#__PURE__*/React.createElement("span", {
    style: sep
  }, "\u1363"), /*#__PURE__*/React.createElement("span", {
    style: nav
  }, "About"), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 14
    }
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    onClick: onStart
  }, "Start learning"))), /*#__PURE__*/React.createElement(Tibeb, {
    motif: "diamond",
    cell: 4,
    palette: "netela"
  }), /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(FidelField, {
    size: 128,
    opacity: 0.042,
    color: "var(--buna-bean)",
    gap: 0.3,
    seed: 11
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      ...shell,
      position: 'relative',
      paddingTop: 54,
      paddingBottom: 54
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) 15ch',
      gap: 44
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 13,
      letterSpacing: '0.06em',
      color: 'var(--buna-ash)',
      marginBottom: 18
    }
  }, "\u12AD\u134D\u120D ", /*#__PURE__*/React.createElement(GeezNumeral, {
    value: 1
  }), " \u1362 \u1218\u1300\u1218\u122A\u12EB \u1243\u120D"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 26,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 108,
      lineHeight: 0.96,
      margin: 0,
      color: 'var(--buna-jebena)',
      fontWeight: 400
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--buna-rust)'
    }
  }, "\u1230"), "\u120B\u121D"), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingBottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 15,
      color: 'var(--buna-ochre)'
    }
  }, "s\xE4l\xB7am"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: 'var(--buna-ash)',
      marginTop: 4
    }
  }, "peace \xB7 hello"))), /*#__PURE__*/React.createElement("p", {
    className: "rubric-open",
    style: {
      fontSize: 17,
      lineHeight: 1.75,
      color: 'var(--buna-bean)',
      maxWidth: '46ch',
      marginTop: 26
    }
  }, "Four characters, and you have read your first Amharic word. The fidel is not an alphabet to be memorised letter by letter \u2014 it is a table of thirty-three sounds turned through seven vowels, and learning the turning teaches you all of it at once."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'center',
      marginTop: 30
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: onStart
  }, "Begin the table"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "lg",
    onClick: onArchive
  }, "Visit the archive"))), /*#__PURE__*/React.createElement("aside", {
    style: {
      borderInlineStart: '1px solid rgba(74,46,30,0.16)',
      paddingInlineStart: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 13,
      lineHeight: 1.75,
      color: 'var(--buna-rust)'
    }
  }, "\u1230\u120B\u121D \u121B\u1208\u1275 ", /*#__PURE__*/React.createElement("br", null), "\u1230\u120B\u121D\u1273 \u1290\u12CD\u1362"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      lineHeight: 1.6,
      color: 'var(--buna-ash)',
      marginTop: 14
    }
  }, "The greeting and the word for peace are the same word. Ethiopians say it as both."), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 20,
      color: 'var(--buna-ochre)',
      marginTop: 18
    }
  }, "\u1368"))))), /*#__PURE__*/React.createElement("section", {
    style: {
      ...shell
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#FFFDF8',
      border: '1px solid rgba(74,46,30,0.14)',
      borderRadius: 'var(--radius-sm)',
      overflow: 'clip'
    }
  }, /*#__PURE__*/React.createElement(Tibeb, {
    motif: "chevron",
    cell: 4,
    palette: "buna",
    ground: "#FFFDF8"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '26px 30px 30px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: `10ch repeat(${ha.length}, 1fr)`,
      gap: 10,
      alignItems: 'end'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: 'var(--buna-ash)',
      paddingBottom: 8
    }
  }, "Order"), ha.map((o, i) => /*#__PURE__*/React.createElement("div", {
    key: `h${i}`,
    style: {
      textAlign: 'center',
      paddingBottom: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 13,
      color: 'var(--buna-rust)'
    }
  }, ORDERS[i]), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 12,
      color: 'var(--buna-ash)',
      marginTop: 2
    }
  }, /*#__PURE__*/React.createElement(GeezNumeral, {
    value: i + 1
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 30,
      color: 'var(--buna-ochre)',
      alignSelf: 'center'
    }
  }, "\u1200"), ha.map(o => /*#__PURE__*/React.createElement("div", {
    key: o.char,
    style: {
      textAlign: 'center',
      padding: '14px 0',
      background: 'var(--buna-cream)',
      borderRadius: 'var(--radius-xs)',
      border: '1px solid rgba(74,46,30,0.1)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 34,
      lineHeight: 1,
      color: 'var(--buna-jebena)'
    }
  }, o.char), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--buna-ash)',
      marginTop: 7
    }
  }, o.rom)))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--buna-ash)',
      marginTop: 18,
      maxWidth: '62ch',
      lineHeight: 1.65
    }
  }, "One consonant, seven vowel orders. Thirty-three of these rows make the whole script \u2014 and the shape of the turn is the same in every row", /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-fidel)'
    }
  }, "\u1362"))))), /*#__PURE__*/React.createElement("section", {
    style: {
      ...shell,
      marginTop: 62,
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: 40
    }
  }, [{
    t: 'The fidel, whole',
    b: 'All thirty-three families, taught as the grid they are — with audio from native speakers in Addis and the diaspora.'
  }, {
    t: 'Review that holds',
    b: 'Spaced repetition set to the Ethiopian calendar, thirteen months and all, so a streak means a real month of work.'
  }, {
    t: 'A living archive',
    b: 'Manuscripts, the coffee ceremony, Yared’s notation, proverbs — the context the language lives inside.',
    onClick: onArchive
  }].map((c, i) => /*#__PURE__*/React.createElement("div", {
    key: c.t,
    onClick: c.onClick,
    style: {
      cursor: c.onClick ? 'pointer' : 'default'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 44,
      lineHeight: 1,
      color: 'var(--buna-rust)'
    }
  }, /*#__PURE__*/React.createElement(GeezNumeral, {
    value: i + 1
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      margin: '14px 0 16px'
    }
  }, /*#__PURE__*/React.createElement(Tibeb, {
    motif: "dash",
    cell: 3,
    palette: "buna"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 22,
      color: 'var(--buna-jebena)',
      marginBottom: 8
    }
  }, c.t), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      lineHeight: 1.6,
      color: 'var(--buna-ash)'
    }
  }, c.b)))), /*#__PURE__*/React.createElement("section", {
    style: {
      marginTop: 66,
      background: 'var(--buna-bean)',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(Tibeb, {
    motif: "terrace",
    cell: 5,
    palette: "netela",
    ground: "var(--buna-bean)",
    flip: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      ...shell,
      padding: '40px 44px 48px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 40,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 330
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 13,
      color: 'var(--buna-ochre)',
      letterSpacing: '0.06em'
    }
  }, "\u1275\u121D\u1205\u122D\u1275 ", /*#__PURE__*/React.createElement(GeezNumeral, {
    value: 1
  }), " \u1232\u1328\u122D\u1235"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 29,
      color: 'var(--buna-cream)',
      marginTop: 12,
      lineHeight: 1.22
    }
  }, "You will read words you already know by heart.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 34
    }
  }, D.firstWords.map(w => /*#__PURE__*/React.createElement("div", {
    key: w.word,
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 46,
      color: 'var(--buna-cream)',
      lineHeight: 1.15
    }
  }, w.word), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--buna-ochre)',
      marginTop: 6
    }
  }, w.rom), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'rgba(247,239,225,0.62)',
      marginTop: 2
    }
  }, w.gloss))))), /*#__PURE__*/React.createElement(Tibeb, {
    motif: "terrace",
    cell: 5,
    palette: "netela",
    ground: "var(--buna-bean)"
  })), /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--buna-jebena)',
      color: 'rgba(247,239,225,0.72)',
      position: 'relative',
      overflow: 'clip'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0
    }
  }, /*#__PURE__*/React.createElement(CrossLattice, {
    cell: 5,
    color: "#F7EFE1",
    opacity: 0.05
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      ...shell,
      padding: '46px 44px',
      display: 'flex',
      justifyContent: 'space-between',
      gap: 30,
      flexWrap: 'wrap',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 24,
      color: 'var(--buna-ochre)'
    }
  }, "\u12A0\u1261\u130A\u12F3"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      marginTop: 12,
      maxWidth: 300,
      lineHeight: 1.6
    }
  }, "A non-profit keeping Amharic and its script in reach of everyone who wants it. Free, forever", /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-fidel)'
    }
  }, "\u1362"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 46,
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--buna-cream)',
      fontWeight: 700
    }
  }, "Learn"), /*#__PURE__*/React.createElement("span", null, "The fidel"), /*#__PURE__*/React.createElement("span", null, "Vocabulary"), /*#__PURE__*/React.createElement("span", null, "Review")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--buna-cream)',
      fontWeight: 700
    }
  }, "Abugida"), /*#__PURE__*/React.createElement("span", null, "About"), /*#__PURE__*/React.createElement("span", null, "Archive"), /*#__PURE__*/React.createElement("span", null, "Donate"))))));
}
Object.assign(window, {
  Landing
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/learn-app/Landing.jsx", error: String((e && e.message) || e) }); }

// ui_kits/learn-app/Lesson.jsx
try { (() => {
/* The fidel lesson — interactive teach + quiz flow. */

function Lesson({
  family,
  onExit,
  onComplete
}) {
  const {
    Button,
    IconButton,
    FidelTile,
    ProgressBar,
    Badge,
    Tibeb,
    GeezNumeral,
    FidelField
  } = window.AbugidaDesignSystem_019e1e;
  const D = window.ABG_DATA;
  const fam = family || D.families[1];
  const [phase, setPhase] = React.useState('teach'); // teach | quiz | done
  const [qi, setQi] = React.useState(0);
  const [picked, setPicked] = React.useState(null);
  const [checked, setChecked] = React.useState(false);
  useLucide();
  const quiz = D.quiz;
  const q = quiz[qi];
  const isLast = qi === quiz.length - 1;
  const tileState = opt => {
    if (!checked) return picked === opt.char ? 'selected' : 'default';
    if (opt.char === q.answer) return 'correct';
    if (opt.char === picked) return 'wrong';
    return 'ghost';
  };
  const onCheck = () => {
    if (picked) setChecked(true);
  };
  const onNext = () => {
    if (isLast) {
      setPhase('done');
      return;
    }
    setQi(qi + 1);
    setPicked(null);
    setChecked(false);
  };
  const correct = checked && picked === q.answer;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100%',
      background: 'var(--surface-page)',
      display: 'flex',
      flexDirection: 'column'
    },
    className: "bg-parchment"
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      padding: '18px 28px',
      borderBottom: '1px solid var(--border-subtle)',
      background: 'var(--surface-raised)'
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    "aria-label": "Back",
    variant: "ghost",
    onClick: onExit
  }, /*#__PURE__*/React.createElement(Ico, {
    n: "arrow-left"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 22,
      color: 'var(--vermilion-600)'
    }
  }, fam.glyph), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 19,
      color: 'var(--text-strong)'
    }
  }, fam.name), phase === 'quiz' && /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-fidel)'
    }
  }, /*#__PURE__*/React.createElement(GeezNumeral, {
    value: qi + 1
  }), " \u12A8 ", /*#__PURE__*/React.createElement(GeezNumeral, {
    value: quiz.length
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 220
    }
  }, /*#__PURE__*/React.createElement(ProgressBar, {
    color: "gold",
    height: 8,
    value: phase === 'teach' ? 8 : phase === 'done' ? 100 : (qi + (checked ? 1 : 0)) / quiz.length * 100
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '40px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 620
    }
  }, phase === 'teach' && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      textAlign: 'center'
    }
  }, "New letter family"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 28,
      margin: '22px 0 28px',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(FidelField, {
    mode: "watermark",
    text: fam.orders[0].char,
    size: 300,
    opacity: 0.045,
    color: "var(--clay-800)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      fontFamily: 'var(--font-fidel)',
      fontSize: 120,
      color: 'var(--text-strong)',
      lineHeight: 1
    }
  }, fam.orders[0].char), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 22,
      color: 'var(--vermilion-600)',
      fontWeight: 700
    }
  }, fam.orders[0].rom), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      color: 'var(--text-muted)',
      maxWidth: 200,
      marginTop: 8
    }
  }, "The base form. Each of the seven shapes below adds a vowel."), /*#__PURE__*/React.createElement(IconButton, {
    "aria-label": "Play sound",
    variant: "outline",
    style: {
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement(Ico, {
    n: "volume-2"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(Tibeb, {
    motif: "chevron",
    cell: 3,
    palette: "buna"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(7, 1fr)',
      gap: 9,
      marginBottom: 30
    }
  }, fam.orders.map(o => /*#__PURE__*/React.createElement(FidelTile, {
    key: o.char,
    char: o.char,
    romanization: o.rom,
    size: "sm"
  }))), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    onClick: () => setPhase('quiz'),
    trailingIcon: /*#__PURE__*/React.createElement(Ico, {
      n: "arrow-right"
    })
  }, "Practice these")), phase === 'quiz' && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow"
  }, "Tap the matching letter"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 30,
      color: 'var(--text-strong)',
      marginTop: 10
    }
  }, "Which one says ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      color: 'var(--vermilion-600)',
      fontWeight: 700
    }
  }, q.prompt), "?")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 14,
      marginBottom: 8
    }
  }, q.options.map(opt => /*#__PURE__*/React.createElement(FidelTile, {
    key: opt.char,
    char: opt.char,
    romanization: opt.rom,
    size: "md",
    state: tileState(opt),
    disabled: checked,
    onClick: () => !checked && setPicked(opt.char)
  })))), phase === 'done' && /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 84,
      height: 84,
      borderRadius: '50%',
      background: 'var(--success-soft)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontSize: 44,
      color: 'var(--highland-500)',
      lineHeight: 1
    }
  }, "\u1368")), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 34,
      color: 'var(--text-strong)'
    }
  }, "\u12A5\u1295\u12B3\u1295 \u12F0\u1235 \u12A0\u1208\u1205!"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 17,
      color: 'var(--text-body)',
      margin: '12px auto 28px',
      maxWidth: 380
    }
  }, "Nicely done \u2014 that's the ", fam.name.replace('The ', '').replace(' family', ''), " family. Your streak is safe today."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: onComplete,
    leadingIcon: /*#__PURE__*/React.createElement(Ico, {
      n: "check"
    })
  }, "Back to learning"), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 260,
      margin: '28px auto 0'
    }
  }, /*#__PURE__*/React.createElement(Tibeb, {
    motif: "diamond",
    cell: 4,
    palette: "netela"
  }))))), phase === 'quiz' && /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: `1px solid ${checked ? correct ? 'var(--highland-200)' : 'var(--vermilion-200)' : 'var(--border-subtle)'}`,
      background: checked ? correct ? 'var(--success-soft)' : 'var(--danger-soft)' : 'var(--surface-raised)',
      padding: '18px 28px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      transition: 'var(--transition-control)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, checked && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 38,
      height: 38,
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: correct ? 'var(--highland-400)' : 'var(--vermilion-500)',
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement(Ico, {
    n: correct ? 'check' : 'x',
    style: {
      width: 20
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      color: correct ? 'var(--highland-600)' : 'var(--vermilion-700)'
    }
  }, correct ? 'Correct!' : 'Not quite'), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-fidel)'
    }
  }, q.answer), " is \u201C", q.prompt, "\u201D.")))), checked ? /*#__PURE__*/React.createElement(Button, {
    variant: correct ? 'gold' : 'primary',
    size: "lg",
    onClick: onNext,
    trailingIcon: /*#__PURE__*/React.createElement(Ico, {
      n: "arrow-right"
    })
  }, isLast ? 'Finish' : 'Continue') : /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    disabled: !picked,
    onClick: onCheck
  }, "Check")));
}
Object.assign(window, {
  Lesson
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/learn-app/Lesson.jsx", error: String((e && e.message) || e) }); }

// ui_kits/learn-app/Parts.jsx
try { (() => {
/* Shared bits for the Abugida learn-app kit. */

function Ico({
  n,
  style
}) {
  return /*#__PURE__*/React.createElement("i", {
    "data-lucide": n,
    style: style
  });
}

/* The mark is the fidel character itself, sitting on a woven band —
   not a glyph inside a rounded square, which is the most generic
   lockup on the web and says nothing about where this comes from. */
function Logo({
  size = 28,
  inverted = false,
  mark = true,
  wordmark = true
}) {
  const {
    Tibeb
  } = window.AbugidaDesignSystem_019e1e;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: size * 0.44
    }
  }, mark && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      flexDirection: 'column',
      gap: size * 0.14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-fidel)',
      fontWeight: 500,
      color: inverted ? 'var(--saffron-400)' : 'var(--vermilion-500)',
      fontSize: size * 1.32,
      lineHeight: 0.92
    }
  }, "\u12A0"), /*#__PURE__*/React.createElement("span", {
    style: {
      width: size * 1.05
    }
  }, /*#__PURE__*/React.createElement(Tibeb, {
    motif: "dash",
    cell: Math.max(2, Math.round(size / 12)),
    palette: "buna",
    frame: false
  }))), wordmark && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: size,
      letterSpacing: '-0.01em',
      color: inverted ? 'var(--clay-100)' : 'var(--text-strong)'
    }
  }, "Abugida"));
}

// Refresh Lucide glyphs after any render.
function useLucide(dep) {
  React.useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  });
}
Object.assign(window, {
  Ico,
  Logo,
  useLucide
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/learn-app/Parts.jsx", error: String((e && e.message) || e) }); }

// ui_kits/learn-app/data.js
try { (() => {
// Sample content for the Abugida learn-app UI kit.
// Fidel data is real Geʼez; romanization uses a light, learner-friendly scheme.

window.ABG_DATA = {
  learner: {
    name: 'Selam',
    greeting: 'ሰላም',
    streak: 12,
    mastered: 28,
    minutesToday: 15,
    dailyGoal: 20,
    dailyDone: 15
  },
  // One consonant family = a row of the fidel grid (7 vowel orders).
  families: [{
    glyph: 'ሀ',
    name: 'The ሀ family',
    base: 'h',
    status: 'done',
    progress: 100,
    orders: [{
      char: 'ሀ',
      rom: 'hä'
    }, {
      char: 'ሁ',
      rom: 'hu'
    }, {
      char: 'ሂ',
      rom: 'hi'
    }, {
      char: 'ሃ',
      rom: 'ha'
    }, {
      char: 'ሄ',
      rom: 'he'
    }, {
      char: 'ህ',
      rom: 'hə'
    }, {
      char: 'ሆ',
      rom: 'ho'
    }]
  }, {
    glyph: 'ለ',
    name: 'The ለ family',
    base: 'l',
    status: 'active',
    progress: 60,
    orders: [{
      char: 'ለ',
      rom: 'lä'
    }, {
      char: 'ሉ',
      rom: 'lu'
    }, {
      char: 'ሊ',
      rom: 'li'
    }, {
      char: 'ላ',
      rom: 'la'
    }, {
      char: 'ሌ',
      rom: 'le'
    }, {
      char: 'ል',
      rom: 'lə'
    }, {
      char: 'ሎ',
      rom: 'lo'
    }]
  }, {
    glyph: 'መ',
    name: 'The መ family',
    base: 'm',
    status: 'locked',
    progress: 0,
    orders: [{
      char: 'መ',
      rom: 'mä'
    }, {
      char: 'ሙ',
      rom: 'mu'
    }, {
      char: 'ሚ',
      rom: 'mi'
    }, {
      char: 'ማ',
      rom: 'ma'
    }, {
      char: 'ሜ',
      rom: 'me'
    }, {
      char: 'ም',
      rom: 'mə'
    }, {
      char: 'ሞ',
      rom: 'mo'
    }]
  }, {
    glyph: 'ረ',
    name: 'The ረ family',
    base: 'r',
    status: 'locked',
    progress: 0,
    orders: [{
      char: 'ረ',
      rom: 'rä'
    }, {
      char: 'ሩ',
      rom: 'ru'
    }, {
      char: 'ሪ',
      rom: 'ri'
    }, {
      char: 'ራ',
      rom: 'ra'
    }, {
      char: 'ሬ',
      rom: 're'
    }, {
      char: 'ር',
      rom: 'rə'
    }, {
      char: 'ሮ',
      rom: 'ro'
    }]
  }, {
    glyph: 'ሰ',
    name: 'The ሰ family',
    base: 's',
    status: 'locked',
    progress: 0,
    orders: [{
      char: 'ሰ',
      rom: 'sä'
    }, {
      char: 'ሱ',
      rom: 'su'
    }, {
      char: 'ሲ',
      rom: 'si'
    }, {
      char: 'ሳ',
      rom: 'sa'
    }, {
      char: 'ሴ',
      rom: 'se'
    }, {
      char: 'ስ',
      rom: 'sə'
    }, {
      char: 'ሶ',
      rom: 'so'
    }]
  }],
  // A short quiz for the active lesson.
  quiz: [{
    prompt: 'lu',
    answer: 'ሉ',
    options: [{
      char: 'ለ',
      rom: 'lä'
    }, {
      char: 'ሉ',
      rom: 'lu'
    }, {
      char: 'ላ',
      rom: 'la'
    }, {
      char: 'ል',
      rom: 'lə'
    }]
  }, {
    prompt: 'li',
    answer: 'ሊ',
    options: [{
      char: 'ሎ',
      rom: 'lo'
    }, {
      char: 'ሌ',
      rom: 'le'
    }, {
      char: 'ሊ',
      rom: 'li'
    }, {
      char: 'ለ',
      rom: 'lä'
    }]
  }, {
    prompt: 'lo',
    answer: 'ሎ',
    options: [{
      char: 'ላ',
      rom: 'la'
    }, {
      char: 'ሎ',
      rom: 'lo'
    }, {
      char: 'ሉ',
      rom: 'lu'
    }, {
      char: 'ሊ',
      rom: 'li'
    }]
  }],
  // Words the learner can already read, for the landing "read your first word" moment.
  firstWords: [{
    word: 'ሰላም',
    rom: 'sälam',
    gloss: 'hello / peace'
  }, {
    word: 'አቡጊዳ',
    rom: 'abugida',
    gloss: 'the script'
  }, {
    word: 'ቡና',
    rom: 'buna',
    gloss: 'coffee'
  }],
  // Archive categories (the cultural archive that "follows").
  archive: [{
    title: 'Manuscripts',
    sub: 'Illuminated Geʼez codices',
    icon: 'book-marked',
    tint: 'var(--vermilion-500)'
  }, {
    title: 'Coffee',
    sub: 'The buna ceremony',
    icon: 'coffee',
    tint: 'var(--saffron-500)'
  }, {
    title: 'Music',
    sub: 'Tizita, krar & masinko',
    icon: 'music',
    tint: 'var(--indigo-500)'
  }, {
    title: 'Proverbs',
    sub: 'ምሳሌ — wisdom in lines',
    icon: 'quote',
    tint: 'var(--highland-400)'
  }, {
    title: 'Textiles',
    sub: 'Tibeb & habesha kemis',
    icon: 'shirt',
    tint: 'var(--vermilion-600)'
  }, {
    title: 'Photography',
    sub: 'Faces of the diaspora',
    icon: 'camera',
    tint: 'var(--indigo-600)'
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/learn-app/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.FidelTile = __ds_scope.FidelTile;

__ds_ns.LessonCard = __ds_scope.LessonCard;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.CrossLattice = __ds_scope.CrossLattice;

__ds_ns.FidelField = __ds_scope.FidelField;

__ds_ns.GeezNumeral = __ds_scope.GeezNumeral;

__ds_ns.ManuscriptFrame = __ds_scope.ManuscriptFrame;

__ds_ns.SectionMark = __ds_scope.SectionMark;

__ds_ns.Tibeb = __ds_scope.Tibeb;

})();
