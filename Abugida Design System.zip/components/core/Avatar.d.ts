import * as React from 'react';

/**
 * Round avatar. Shows `src` image when present, otherwise colored initials
 * derived from `name`. Tint auto-picks from the name unless `tint` is set.
 */
export interface AvatarProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Person/place name — used for initials and alt text. */
  name: string;
  /** Optional image URL. */
  src?: string;
  /** @default "md" */
  size?: 'xs' | 'sm' | 'md' | 'lg';
  /** Force a tint instead of the auto-derived one. */
  tint?: 't1' | 't2' | 't3' | 't4';
}

export function Avatar(props: AvatarProps): JSX.Element;
