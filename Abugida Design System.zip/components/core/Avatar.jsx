import React from 'react';

const AVATAR_CSS = `
.abg-avatar{
  display: inline-flex; align-items: center; justify-content: center; flex: none;
  border-radius: var(--radius-pill); overflow: hidden; background: var(--indigo-100);
  color: var(--indigo-600); font-family: var(--font-body); font-weight: var(--fw-bold);
  border: var(--border-width-strong) solid var(--surface-raised); box-shadow: var(--shadow-xs);
  position: relative; user-select: none;
}
.abg-avatar img{ width: 100%; height: 100%; object-fit: cover; }
.abg-avatar--xs{ width: 26px; height: 26px; font-size: 10px; }
.abg-avatar--sm{ width: 34px; height: 34px; font-size: 13px; }
.abg-avatar--md{ width: 44px; height: 44px; font-size: 16px; }
.abg-avatar--lg{ width: 60px; height: 60px; font-size: 22px; }
.abg-avatar--t1{ background: var(--vermilion-100); color: var(--vermilion-600); }
.abg-avatar--t2{ background: var(--saffron-100); color: var(--saffron-700); }
.abg-avatar--t3{ background: var(--highland-100); color: var(--highland-500); }
.abg-avatar--t4{ background: var(--indigo-100); color: var(--indigo-600); }
`;

let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'avatar');
  el.textContent = AVATAR_CSS;
  document.head.appendChild(el);
  _injected = true;
}

function initials(name = '') {
  const parts = name.trim().split(/\s+/).slice(0, 2);
  return parts.map(p => p[0] || '').join('').toUpperCase();
}

/** Round user avatar — image when `src` is given, else colored initials. */
export function Avatar({ name = '', src, size = 'md', tint, className = '', ...rest }) {
  ensureStyles();
  // Deterministic tint from the name when not specified.
  const palette = ['t1', 't2', 't3', 't4'];
  const auto = palette[(name.charCodeAt(0) || 0) % palette.length];
  const cls = ['abg-avatar', `abg-avatar--${size}`, `abg-avatar--${tint || auto}`, className]
    .filter(Boolean).join(' ');
  return (
    <span className={cls} role="img" aria-label={name} {...rest}>
      {src ? <img src={src} alt={name} /> : initials(name)}
    </span>
  );
}
