Round avatar with image or auto-colored initials fallback.

```jsx
<Avatar name="Selam Tesfaye" />
<Avatar name="Dawit" src="/users/dawit.jpg" size="lg" />
<Avatar name="Abel" size="sm" tint="t3" />
```

- **size**: `xs` · `sm` · `md` · `lg`.
- Tint is derived from the name across four warm palettes; override with `tint`.
