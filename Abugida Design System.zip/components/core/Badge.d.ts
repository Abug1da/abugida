import * as React from 'react';

/**
 * Small pill for status, counts, and metadata. Tones map to the semantic
 * color roles; `dot` prefixes a status dot; `solid` is the filled brand pill.
 */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** @default "neutral" */
  tone?: 'neutral' | 'brand' | 'success' | 'warning' | 'danger' | 'info' | 'solid';
  /** Prefix a small status dot. @default false */
  dot?: boolean;
  children?: React.ReactNode;
}

export function Badge(props: BadgeProps): JSX.Element;
