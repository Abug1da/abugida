import React from 'react';

const BADGE_CSS = `
.abg-badge{
  font-family: var(--font-body); font-weight: var(--fw-semibold); font-size: var(--text-xs);
  line-height: 1; display: inline-flex; align-items: center; gap: 5px;
  padding: 4px 9px; border-radius: var(--radius-pill); white-space: nowrap;
  border: var(--border-width) solid transparent;
}
.abg-badge svg{ width: 1em; height: 1em; }
.abg-badge--neutral{ background: var(--clay-100); color: var(--clay-700); border-color: var(--clay-200); }
.abg-badge--brand{ background: var(--brand-soft); color: var(--brand-on-soft); border-color: var(--vermilion-100); }
.abg-badge--success{ background: var(--success-soft); color: var(--highland-500); border-color: var(--highland-200); }
.abg-badge--warning{ background: var(--warning-soft); color: var(--saffron-700); border-color: var(--saffron-200); }
.abg-badge--danger{ background: var(--danger-soft); color: var(--vermilion-700); border-color: var(--vermilion-200); }
.abg-badge--info{ background: var(--info-soft); color: var(--indigo-600); border-color: var(--indigo-200); }
.abg-badge--solid{ background: var(--brand); color: var(--text-on-brand); border-color: transparent; }
.abg-badge--dot::before{ content:""; width:6px; height:6px; border-radius:var(--radius-pill); background: currentColor; opacity:.8; }
`;

let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'badge');
  el.textContent = BADGE_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/** Small status / metadata pill. */
export function Badge({ tone = 'neutral', dot = false, className = '', children, ...rest }) {
  ensureStyles();
  const cls = ['abg-badge', `abg-badge--${tone}`, dot ? 'abg-badge--dot' : '', className]
    .filter(Boolean).join(' ');
  return <span className={cls} {...rest}>{children}</span>;
}
