Small pill for status, counts, and metadata.

```jsx
<Badge tone="success" dot>Mastered</Badge>
<Badge tone="brand">New</Badge>
<Badge tone="warning">Review due</Badge>
<Badge tone="neutral">A1 · Beginner</Badge>
```

- **tone**: `neutral` · `brand` · `success` · `warning` · `danger` · `info` · `solid`.
- **dot**: prefixes a status dot in the current text color.
