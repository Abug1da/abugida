import * as React from 'react';

/**
 * Abugida primary button — the main call-to-action control.
 * Use `primary` for the single most important action on a view, `secondary`
 * for adjacent actions, `tinted`/`ghost` for low-emphasis, `gold` for
 * celebratory / progress moments (e.g. "Continue lesson").
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual emphasis. @default "primary" */
  variant?: 'primary' | 'secondary' | 'tinted' | 'ghost' | 'gold';
  /** Control size. @default "md" */
  size?: 'sm' | 'md' | 'lg';
  /** Stretch to fill the container width. @default false */
  fullWidth?: boolean;
  /** Icon node rendered before the label. */
  leadingIcon?: React.ReactNode;
  /** Icon node rendered after the label. */
  trailingIcon?: React.ReactNode;
  /** Render as an anchor with this href instead of a button. */
  href?: string;
  disabled?: boolean;
  children?: React.ReactNode;
}

export function Button(props: ButtonProps): JSX.Element;
