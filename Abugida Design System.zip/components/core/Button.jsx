import React from 'react';

const BUTTON_CSS = `
.abg-btn{
  --_bg: var(--brand); --_fg: var(--text-on-brand); --_bd: transparent; --_bgh: var(--brand-hover); --_bgp: var(--brand-press);
  font-family: var(--font-body); font-weight: var(--fw-semibold);
  display: inline-flex; align-items: center; justify-content: center; gap: var(--gap-inline);
  border: var(--border-width-strong) solid var(--_bd); border-radius: var(--radius-md);
  background: var(--_bg); color: var(--_fg); cursor: pointer; text-decoration: none;
  white-space: nowrap; user-select: none; transition: var(--transition-control);
  box-shadow: var(--shadow-xs);
}
.abg-btn:hover{ background: var(--_bgh); }
.abg-btn:active{ background: var(--_bgp); transform: translateY(1px); box-shadow: none; }
.abg-btn:focus-visible{ outline: none; box-shadow: var(--focus-ring); }
.abg-btn[disabled], .abg-btn[aria-disabled="true"]{ opacity: .5; cursor: not-allowed; transform: none; box-shadow: none; }

.abg-btn--secondary{ --_bg: var(--surface-raised); --_fg: var(--text-strong); --_bd: var(--border-strong); --_bgh: var(--clay-100); --_bgp: var(--clay-200); }
.abg-btn--tinted{ --_bg: var(--brand-soft); --_fg: var(--brand-on-soft); --_bd: transparent; --_bgh: var(--vermilion-100); --_bgp: var(--vermilion-200); box-shadow: none; }
.abg-btn--ghost{ --_bg: transparent; --_fg: var(--text-body); --_bd: transparent; --_bgh: var(--clay-100); --_bgp: var(--clay-200); box-shadow: none; }
.abg-btn--gold{ --_bg: var(--saffron-400); --_fg: var(--clay-900); --_bd: transparent; --_bgh: var(--saffron-500); --_bgp: var(--saffron-600); }

.abg-btn--sm{ font-size: var(--text-sm); padding: 6px 12px; min-height: 34px; }
.abg-btn--md{ font-size: var(--text-md); padding: 9px 18px; min-height: 42px; }
.abg-btn--lg{ font-size: var(--text-lg); padding: 13px 24px; min-height: 52px; border-radius: var(--radius-lg); }
.abg-btn--full{ width: 100%; }
.abg-btn svg{ width: 1.1em; height: 1.1em; flex: none; }
`;

let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'button');
  el.textContent = BUTTON_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/**
 * Abugida primary button. Renders as <button> or, when `href` is set, <a>.
 */
export function Button({
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  leadingIcon = null,
  trailingIcon = null,
  href,
  disabled = false,
  className = '',
  children,
  ...rest
}) {
  ensureStyles();
  const cls = [
    'abg-btn',
    `abg-btn--${variant}`,
    `abg-btn--${size}`,
    fullWidth ? 'abg-btn--full' : '',
    className,
  ].filter(Boolean).join(' ');

  const content = (
    <>
      {leadingIcon}
      {children != null && <span>{children}</span>}
      {trailingIcon}
    </>
  );

  if (href && !disabled) {
    return (
      <a className={cls} href={href} {...rest}>{content}</a>
    );
  }
  return (
    <button className={cls} disabled={disabled} {...rest}>{content}</button>
  );
}
