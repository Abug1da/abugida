Primary action button with five emphasis variants and three sizes; renders as a link when `href` is set.

```jsx
<Button variant="primary" size="md" onClick={start}>Start learning</Button>
<Button variant="secondary" leadingIcon={<i data-lucide="play" />}>Resume</Button>
<Button variant="gold" trailingIcon={<i data-lucide="arrow-right" />}>Continue lesson</Button>
<Button variant="ghost" size="sm">Skip</Button>
```

- **variant**: `primary` (vermilion, one per view) · `secondary` (outlined) · `tinted` (soft brand wash) · `ghost` (text-only) · `gold` (saffron, for progress/celebration).
- **size**: `sm` · `md` · `lg`. Use `lg` for hero CTAs.
- Pass icons via `leadingIcon` / `trailingIcon` (Lucide `<i data-lucide>` nodes or SVGs). Supports `fullWidth`, `disabled`, and all native button/anchor attributes.
