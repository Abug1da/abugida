import * as React from 'react';

/**
 * Warm surface container. Use `interactive` for clickable cards (lessons,
 * archive entries) and `accent` to top the card with a brand or custom color bar.
 */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** @default "default" */
  elevation?: 'flat' | 'default' | 'raised';
  /** Inner padding. @default "md" */
  padding?: 'none' | 'sm' | 'md' | 'lg';
  /** Add hover lift + pointer affordance. @default false */
  interactive?: boolean;
  /** `true` for a brand accent bar, or a CSS color string for a custom one. @default false */
  accent?: boolean | string;
  children?: React.ReactNode;
}

export function Card(props: CardProps): JSX.Element;
