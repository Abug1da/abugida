import React from 'react';

const CARD_CSS = `
.abg-card{
  background: var(--surface-raised); border: var(--border-width) solid var(--border-subtle);
  border-radius: var(--radius-lg); box-shadow: var(--shadow-sm);
  transition: var(--transition-control); overflow: clip;
}
.abg-card--flat{ box-shadow: none; }
.abg-card--raised{ box-shadow: var(--shadow-md); border-color: transparent; }
.abg-card--interactive{ cursor: pointer; }
.abg-card--interactive:hover{ box-shadow: var(--shadow-lg); transform: translateY(-2px); border-color: var(--border-default); }
.abg-card--interactive:active{ transform: translateY(0); box-shadow: var(--shadow-sm); }
.abg-card--pad-none{ padding: 0; }
.abg-card--pad-sm{ padding: var(--space-4); }
.abg-card--pad-md{ padding: var(--space-5); }
.abg-card--pad-lg{ padding: var(--space-6); }
.abg-card__accent{ height: 4px; margin: calc(-1 * var(--_p, 0)) calc(-1 * var(--_p, 0)) 0; background: var(--brand); }
`;

let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'card');
  el.textContent = CARD_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/** Surface container with warm elevation. */
export function Card({
  elevation = 'default',
  padding = 'md',
  interactive = false,
  accent = false,
  className = '',
  children,
  ...rest
}) {
  ensureStyles();
  const cls = [
    'abg-card',
    `abg-card--${elevation}`,
    `abg-card--pad-${padding}`,
    interactive ? 'abg-card--interactive' : '',
    className,
  ].filter(Boolean).join(' ');
  return (
    <div className={cls} {...rest}>
      {accent && <div className="abg-card__accent" style={{ background: accent === true ? 'var(--brand)' : accent }} />}
      {children}
    </div>
  );
}
