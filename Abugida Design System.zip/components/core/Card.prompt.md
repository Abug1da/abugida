Warm surface container for grouping content.

```jsx
<Card padding="md">…</Card>
<Card interactive accent onClick={open}>Clickable lesson card</Card>
<Card elevation="raised" accent="var(--accent-blue)">Featured</Card>
```

- **elevation**: `flat` · `default` · `raised`.
- **padding**: `none` · `sm` · `md` · `lg`.
- **interactive**: adds hover-lift for clickable cards.
- **accent**: `true` (brand bar) or any CSS color string.
