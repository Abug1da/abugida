import * as React from 'react';

/**
 * Square icon-only button. Always provide an `aria-label` for accessibility.
 * Use `ghost` in toolbars, `outline` for standalone actions, `solid` for a
 * floating primary action.
 */
export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** @default "ghost" */
  variant?: 'ghost' | 'outline' | 'solid';
  /** @default "md" */
  size?: 'sm' | 'md' | 'lg';
  /** Required for accessibility. */
  'aria-label': string;
  /** The icon node (Lucide `<i data-lucide>` or an SVG). */
  children?: React.ReactNode;
}

export function IconButton(props: IconButtonProps): JSX.Element;
