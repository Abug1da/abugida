import React from 'react';

const ICONBTN_CSS = `
.abg-iconbtn{
  --_bg: transparent; --_fg: var(--text-muted); --_bgh: var(--clay-100); --_fgh: var(--text-strong);
  display: inline-flex; align-items: center; justify-content: center;
  border: none; border-radius: var(--radius-md); background: var(--_bg); color: var(--_fg);
  cursor: pointer; transition: var(--transition-control);
}
.abg-iconbtn:hover{ background: var(--_bgh); color: var(--_fgh); }
.abg-iconbtn:active{ transform: translateY(1px); }
.abg-iconbtn:focus-visible{ outline: none; box-shadow: var(--focus-ring); }
.abg-iconbtn[disabled]{ opacity: .45; cursor: not-allowed; }
.abg-iconbtn--solid{ --_bg: var(--brand); --_fg: var(--text-on-brand); --_bgh: var(--brand-hover); --_fgh: var(--text-on-brand); box-shadow: var(--shadow-xs); }
.abg-iconbtn--outline{ --_bg: var(--surface-raised); --_fg: var(--text-body); --_bgh: var(--clay-100); --_fgh: var(--text-strong); box-shadow: var(--shadow-xs); border: var(--border-width) solid var(--border-default); }
.abg-iconbtn--sm{ width: 34px; height: 34px; }
.abg-iconbtn--md{ width: 42px; height: 42px; }
.abg-iconbtn--lg{ width: 50px; height: 50px; }
.abg-iconbtn svg{ width: 1.25em; height: 1.25em; }
.abg-iconbtn--sm svg{ font-size: 16px; } .abg-iconbtn--md svg{ font-size: 19px; } .abg-iconbtn--lg svg{ font-size: 22px; }
`;

let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'iconbutton');
  el.textContent = ICONBTN_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/** Square, label-less button wrapping a single icon. Always pass `aria-label`. */
export function IconButton({
  variant = 'ghost',
  size = 'md',
  className = '',
  children,
  ...rest
}) {
  ensureStyles();
  const cls = ['abg-iconbtn', `abg-iconbtn--${variant}`, `abg-iconbtn--${size}`, className]
    .filter(Boolean).join(' ');
  return <button className={cls} {...rest}>{children}</button>;
}
