Icon-only square button for toolbars and compact actions. Always pass `aria-label`.

```jsx
<IconButton aria-label="Play audio" variant="outline"><i data-lucide="volume-2" /></IconButton>
<IconButton aria-label="Bookmark" variant="ghost"><i data-lucide="bookmark" /></IconButton>
<IconButton aria-label="Add" variant="solid" size="lg"><i data-lucide="plus" /></IconButton>
```

- **variant**: `ghost` (toolbars) · `outline` (standalone) · `solid` (floating primary).
- **size**: `sm` 34px · `md` 42px · `lg` 50px.
