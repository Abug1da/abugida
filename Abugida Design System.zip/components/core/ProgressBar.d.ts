import * as React from 'react';

/**
 * Linear progress bar for lesson completion, streaks, and skill mastery.
 * Optional label/value row sits above the track.
 */
export interface ProgressBarProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Current value. @default 0 */
  value?: number;
  /** Maximum value. @default 100 */
  max?: number;
  /** Fill color role. @default "brand" */
  color?: 'brand' | 'gold' | 'green';
  /** Track height in px. @default 10 */
  height?: number;
  /** Optional label shown above-left. */
  label?: string;
  /** Show the percentage above-right. @default false */
  showValue?: boolean;
}

export function ProgressBar(props: ProgressBarProps): JSX.Element;
