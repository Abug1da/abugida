import React from 'react';

const PROGRESS_CSS = `
.abg-progress{ display: block; width: 100%; }
.abg-progress__track{
  height: var(--_h, 10px); background: var(--clay-200); border-radius: var(--radius-pill);
  overflow: hidden; box-shadow: var(--shadow-inset);
}
.abg-progress__fill{
  height: 100%; border-radius: var(--radius-pill); background: var(--brand);
  transition: width var(--dur-slow) var(--ease-out);
}
.abg-progress--gold .abg-progress__fill{ background: var(--saffron-400); }
.abg-progress--green .abg-progress__fill{ background: var(--highland-400); }
.abg-progress__meta{
  display: flex; justify-content: space-between; align-items: baseline;
  margin-bottom: 7px; font-family: var(--font-body);
}
.abg-progress__label{ font-size: var(--text-sm); font-weight: var(--fw-medium); color: var(--text-body); }
.abg-progress__value{ font-size: var(--text-xs); font-weight: var(--fw-semibold); color: var(--text-muted); font-variant-numeric: tabular-nums; }
`;

let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'progress');
  el.textContent = PROGRESS_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/** Linear progress bar with optional label/value row. */
export function ProgressBar({
  value = 0,
  max = 100,
  color = 'brand',
  height = 10,
  label,
  showValue = false,
  className = '',
  ...rest
}) {
  ensureStyles();
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const cls = ['abg-progress', `abg-progress--${color}`, className].filter(Boolean).join(' ');
  return (
    <div className={cls} {...rest}>
      {(label || showValue) && (
        <div className="abg-progress__meta">
          {label && <span className="abg-progress__label">{label}</span>}
          {showValue && <span className="abg-progress__value">{Math.round(pct)}%</span>}
        </div>
      )}
      <div className="abg-progress__track" style={{ '--_h': `${height}px` }} role="progressbar" aria-valuenow={value} aria-valuemax={max}>
        <div className="abg-progress__fill" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}
