Linear progress bar for lesson completion, streaks, and mastery.

```jsx
<ProgressBar value={3} max={7} label="Order 1 — የ sounds" showValue />
<ProgressBar value={68} color="gold" height={8} />
<ProgressBar value={100} color="green" />
```

- **color**: `brand` · `gold` · `green`.
- Pass `label` and/or `showValue` to render the meta row; omit both for a bare bar.
