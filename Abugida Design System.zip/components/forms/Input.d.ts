import * as React from 'react';

/**
 * Labelled text input with optional hint, error state, and a leading icon
 * adornment. Spreads native input attributes (type, value, onChange, …).
 */
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  /** Field label rendered above the control. */
  label?: string;
  /** Helper text shown below when there is no error. */
  hint?: string;
  /** Error message — switches the field to its error styling. */
  error?: string;
  /** Mark the label with a required asterisk. @default false */
  required?: boolean;
  /** Leading icon node (Lucide `<i data-lucide>` or SVG). */
  adornment?: React.ReactNode;
}

export function Input(props: InputProps): JSX.Element;
