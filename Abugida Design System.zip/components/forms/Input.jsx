import React from 'react';

const INPUT_CSS = `
.abg-field{ display: flex; flex-direction: column; gap: 6px; font-family: var(--font-body); }
.abg-field__label{ font-size: var(--text-sm); font-weight: var(--fw-semibold); color: var(--text-strong); }
.abg-field__label .req{ color: var(--brand); margin-left: 2px; }
.abg-field__hint{ font-size: var(--text-xs); color: var(--text-muted); }
.abg-field__error{ font-size: var(--text-xs); color: var(--danger); font-weight: var(--fw-medium); }
.abg-input-wrap{ position: relative; display: flex; align-items: center; }
.abg-input{
  width: 100%; font-family: var(--font-body); font-size: var(--text-md); color: var(--text-strong);
  background: var(--surface-raised); border: var(--border-width-strong) solid var(--border-default);
  border-radius: var(--radius-md); padding: 10px 14px; transition: var(--transition-control);
  box-shadow: var(--shadow-inset);
}
.abg-input::placeholder{ color: var(--text-faint); }
.abg-input:hover{ border-color: var(--border-strong); }
.abg-input:focus{ outline: none; border-color: var(--brand); box-shadow: var(--focus-ring); }
.abg-input[disabled]{ background: var(--clay-100); color: var(--text-faint); cursor: not-allowed; box-shadow: none; }
.abg-input--has-adorn{ padding-left: 42px; }
.abg-field--error .abg-input{ border-color: var(--danger); }
.abg-field--error .abg-input:focus{ box-shadow: 0 0 0 3px rgba(193,59,36,.25); }
.abg-input__adorn{ position: absolute; left: 14px; display: inline-flex; color: var(--text-faint); pointer-events: none; }
.abg-input__adorn svg{ width: 18px; height: 18px; }
`;

let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'input');
  el.textContent = INPUT_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/** Labelled text input with hint, error, and leading adornment support. */
export function Input({
  label,
  hint,
  error,
  required = false,
  adornment = null,
  id,
  className = '',
  ...rest
}) {
  ensureStyles();
  const fid = id || `abg-input-${Math.random().toString(36).slice(2, 8)}`;
  const wrapCls = ['abg-field', error ? 'abg-field--error' : '', className].filter(Boolean).join(' ');
  return (
    <div className={wrapCls}>
      {label && (
        <label className="abg-field__label" htmlFor={fid}>
          {label}{required && <span className="req">*</span>}
        </label>
      )}
      <div className="abg-input-wrap">
        {adornment && <span className="abg-input__adorn">{adornment}</span>}
        <input
          id={fid}
          className={`abg-input${adornment ? ' abg-input--has-adorn' : ''}`}
          aria-invalid={!!error}
          {...rest}
        />
      </div>
      {error ? <span className="abg-field__error">{error}</span>
             : hint ? <span className="abg-field__hint">{hint}</span> : null}
    </div>
  );
}
