Labelled text input with hint, error, and optional leading icon.

```jsx
<Input label="Email" type="email" placeholder="you@example.com" required
       adornment={<i data-lucide="mail" />} />
<Input label="Display name" hint="This is how other learners see you." />
<Input label="Password" type="password" error="Must be at least 8 characters." />
```

- Pass `error` to switch to error styling; `hint` shows only when there's no error.
- `adornment` renders a leading icon inside the field.
