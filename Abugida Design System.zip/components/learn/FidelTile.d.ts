import * as React from 'react';

/**
 * Signature Abugida control — a tappable Geʼez (fidel) character tile with its
 * romanization. The atom of every lesson, drill, and quiz. The `state` prop
 * drives selection and answer-feedback styling.
 */
export interface FidelTileProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** The Geʼez character, e.g. "ሀ". */
  char: string;
  /** Latin romanization, e.g. "hä". */
  romanization?: string;
  /** @default "md" */
  size?: 'sm' | 'md' | 'lg';
  /** Interaction / feedback state. @default "default" */
  state?: 'default' | 'selected' | 'correct' | 'wrong' | 'ghost';
  /** Show the romanization line. @default true */
  showRomanization?: boolean;
}

export function FidelTile(props: FidelTileProps): JSX.Element;
