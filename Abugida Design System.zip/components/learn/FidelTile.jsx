import React from 'react';

const FIDEL_CSS = `
.abg-fidel{
  --_bg: var(--surface-raised); --_bd: var(--border-default); --_fg: var(--text-strong);
  appearance: none; cursor: pointer; font-family: var(--font-body);
  display: inline-flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 4px; background: var(--_bg); color: var(--_fg);
  border: var(--border-width-strong) solid var(--_bd); border-radius: var(--radius-lg);
  box-shadow: var(--shadow-xs); transition: var(--transition-control); position: relative;
  aspect-ratio: 1; width: 100%;
}
.abg-fidel:hover{ border-color: var(--brand); box-shadow: var(--shadow-md); transform: translateY(-2px); }
.abg-fidel:active{ transform: translateY(0); box-shadow: var(--shadow-xs); }
.abg-fidel:focus-visible{ outline: none; box-shadow: var(--focus-ring); }
.abg-fidel__char{ font-family: var(--font-fidel); font-weight: 500; line-height: 1; }
.abg-fidel__rom{ font-size: var(--text-sm); color: var(--text-muted); font-weight: var(--fw-semibold); letter-spacing: .01em; }
.abg-fidel--sm .abg-fidel__char{ font-size: 28px; } .abg-fidel--sm{ border-radius: var(--radius-md); }
.abg-fidel--md .abg-fidel__char{ font-size: 40px; }
.abg-fidel--lg .abg-fidel__char{ font-size: 60px; }

.abg-fidel--selected{ --_bg: var(--brand-soft); --_bd: var(--brand); --_fg: var(--vermilion-700); box-shadow: var(--focus-ring); }
.abg-fidel--selected .abg-fidel__rom{ color: var(--brand-on-soft); }
.abg-fidel--correct{ --_bg: var(--success-soft); --_bd: var(--highland-400); --_fg: var(--highland-600); }
.abg-fidel--correct .abg-fidel__rom{ color: var(--highland-500); }
.abg-fidel--wrong{ --_bg: var(--danger-soft); --_bd: var(--vermilion-500); --_fg: var(--vermilion-700); }
.abg-fidel--ghost{ --_bg: transparent; --_bd: var(--border-subtle); box-shadow: none; }
.abg-fidel__badge{ position: absolute; top: 8px; right: 8px; width: 18px; height: 18px; border-radius: var(--radius-pill); display: none; align-items: center; justify-content: center; color: #fff; }
.abg-fidel__badge svg{ width: 12px; height: 12px; }
.abg-fidel--correct .abg-fidel__badge{ display: inline-flex; background: var(--highland-400); }
.abg-fidel--wrong .abg-fidel__badge{ display: inline-flex; background: var(--vermilion-500); }
`;

let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'fidel');
  el.textContent = FIDEL_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/**
 * The signature Abugida control: a tappable Geʼez character tile showing the
 * fidel glyph above its romanization. Used throughout lessons and quizzes.
 */
export function FidelTile({
  char,
  romanization,
  size = 'md',
  state = 'default',
  showRomanization = true,
  className = '',
  ...rest
}) {
  ensureStyles();
  const cls = ['abg-fidel', `abg-fidel--${size}`, state !== 'default' ? `abg-fidel--${state}` : '', className]
    .filter(Boolean).join(' ');
  return (
    <button className={cls} {...rest}>
      <span className="abg-fidel__char">{char}</span>
      {showRomanization && romanization && <span className="abg-fidel__rom">{romanization}</span>}
      <span className="abg-fidel__badge" aria-hidden="true">
        <i data-lucide={state === 'wrong' ? 'x' : 'check'} />
      </span>
    </button>
  );
}
