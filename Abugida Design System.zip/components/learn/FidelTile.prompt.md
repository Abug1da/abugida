The signature Abugida control — a tappable fidel (Geʼez) character tile with romanization. The atom of every lesson and quiz.

```jsx
<FidelTile char="ሀ" romanization="hä" />
<FidelTile char="ለ" romanization="lä" state="selected" />
<FidelTile char="መ" romanization="mä" state="correct" />
<FidelTile char="ሰ" romanization="sä" state="wrong" />
<FidelTile char="ረ" size="lg" showRomanization={false} />
```

- **state**: `default` · `selected` (active choice) · `correct` / `wrong` (answer feedback, auto-shows a check/x badge) · `ghost` (de-emphasized).
- **size**: `sm` (grids) · `md` · `lg` (flashcards). Requires the Lucide icon runtime for the feedback badge.
