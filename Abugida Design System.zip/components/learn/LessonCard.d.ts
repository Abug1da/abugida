import * as React from 'react';

/**
 * A lesson row for learning paths: a fidel glyph badge, title + subtitle, and
 * a progress track. `status` controls active / done / locked treatments.
 */
export interface LessonCardProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Fidel glyph shown in the badge (ignored when locked). @default "ሀ" */
  glyph?: string;
  /** Lesson title. */
  title: string;
  /** Secondary line (e.g. "7 letters · 4 min"). */
  subtitle?: string;
  /** Progress 0–100 (forced to 100 when status is "done"). @default 0 */
  progress?: number;
  /** @default "active" */
  status?: 'active' | 'done' | 'locked';
}

export function LessonCard(props: LessonCardProps): JSX.Element;
