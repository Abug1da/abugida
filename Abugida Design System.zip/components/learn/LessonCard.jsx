import React from 'react';

const LESSON_CSS = `
.abg-lesson{
  display: flex; align-items: center; gap: var(--space-4); width: 100%; text-align: left;
  background: var(--surface-raised); border: var(--border-width) solid var(--border-subtle);
  border-radius: var(--radius-lg); padding: var(--space-4); cursor: pointer;
  transition: var(--transition-control); box-shadow: var(--shadow-sm); font-family: var(--font-body);
  appearance: none;
}
.abg-lesson:hover{ box-shadow: var(--shadow-md); transform: translateY(-2px); border-color: var(--border-default); }
.abg-lesson:active{ transform: translateY(0); }
.abg-lesson:focus-visible{ outline: none; box-shadow: var(--focus-ring); }
.abg-lesson__glyph{
  flex: none; width: 60px; height: 60px; border-radius: var(--radius-md);
  display: flex; align-items: center; justify-content: center;
  font-family: var(--font-fidel); font-size: 34px; font-weight: 500; line-height: 1;
  background: var(--brand-soft); color: var(--vermilion-600);
}
.abg-lesson__body{ flex: 1; min-width: 0; }
.abg-lesson__title{ font-size: var(--text-md); font-weight: var(--fw-bold); color: var(--text-strong); margin: 0; }
.abg-lesson__sub{ font-size: var(--text-sm); color: var(--text-muted); margin: 2px 0 10px; }
.abg-lesson__track{ height: 7px; background: var(--clay-200); border-radius: var(--radius-pill); overflow: hidden; }
.abg-lesson__fill{ height: 100%; background: var(--saffron-400); border-radius: var(--radius-pill); transition: width var(--dur-slow) var(--ease-out); }
.abg-lesson__chev{ flex: none; color: var(--text-faint); display: inline-flex; }
.abg-lesson__chev svg{ width: 20px; height: 20px; }

.abg-lesson--done .abg-lesson__glyph{ background: var(--success-soft); color: var(--highland-500); }
.abg-lesson--done .abg-lesson__fill{ background: var(--highland-400); }
.abg-lesson--locked{ opacity: .55; cursor: not-allowed; box-shadow: none; }
.abg-lesson--locked:hover{ transform: none; box-shadow: none; border-color: var(--border-subtle); }
.abg-lesson--locked .abg-lesson__glyph{ background: var(--clay-100); color: var(--text-faint); }
`;

let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'lessoncard');
  el.textContent = LESSON_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/** A lesson row: fidel glyph, title, subtitle, and progress toward mastery. */
export function LessonCard({
  glyph = 'ሀ',
  title,
  subtitle,
  progress = 0,
  status = 'active',
  className = '',
  ...rest
}) {
  ensureStyles();
  const locked = status === 'locked';
  const cls = ['abg-lesson', `abg-lesson--${status}`, className].filter(Boolean).join(' ');
  const pct = status === 'done' ? 100 : Math.max(0, Math.min(100, progress));
  return (
    <button className={cls} disabled={locked} {...rest}>
      <span className="abg-lesson__glyph">{locked ? <i data-lucide="lock" /> : glyph}</span>
      <span className="abg-lesson__body">
        <span className="abg-lesson__title">{title}</span>
        {subtitle && <span className="abg-lesson__sub">{subtitle}</span>}
        <span className="abg-lesson__track"><span className="abg-lesson__fill" style={{ width: `${pct}%` }} /></span>
      </span>
      <span className="abg-lesson__chev" aria-hidden="true">
        <i data-lucide={status === 'done' ? 'check-circle-2' : 'chevron-right'} />
      </span>
    </button>
  );
}
