Lesson row with a fidel glyph badge, title/subtitle, and a mastery progress track.

```jsx
<LessonCard glyph="ሀ" title="The ሀ family" subtitle="7 letters · 4 min" progress={60} />
<LessonCard glyph="ለ" title="The ለ family" subtitle="Mastered" status="done" />
<LessonCard title="The ሐ family" subtitle="Unlocks next" status="locked" />
```

- **status**: `active` (gold progress) · `done` (green, full, check) · `locked` (dimmed, lock glyph, disabled).
- Requires the Lucide icon runtime for the chevron/lock/check glyphs.
