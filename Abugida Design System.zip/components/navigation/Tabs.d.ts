import * as React from 'react';

export interface TabItem {
  /** Visible label. */
  label: string;
  /** Stable value; defaults to `label` when omitted. */
  value?: string;
  /** Optional leading icon node. */
  icon?: React.ReactNode;
  /** Optional count badge. */
  count?: number;
}

/**
 * Horizontal tab switcher, controlled via `value` + `onChange`.
 * `underline` for page-level section nav, `pill` for compact segmented control.
 */
export interface TabsProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'> {
  items: TabItem[];
  /** Currently selected value. */
  value: string;
  /** Called with the next value. */
  onChange?: (value: string) => void;
  /** @default "underline" */
  variant?: 'underline' | 'pill';
}

export function Tabs(props: TabsProps): JSX.Element;
