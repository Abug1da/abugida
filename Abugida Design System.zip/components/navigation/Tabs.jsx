import React from 'react';

const TABS_CSS = `
.abg-tabs{ display: flex; gap: 4px; font-family: var(--font-body); }
.abg-tabs--underline{ gap: 22px; border-bottom: var(--border-width) solid var(--border-subtle); }
.abg-tabs--pill{ background: var(--clay-100); padding: 4px; border-radius: var(--radius-pill); gap: 2px; }
.abg-tab{
  appearance: none; border: none; background: transparent; cursor: pointer;
  font-family: var(--font-body); font-weight: var(--fw-semibold); font-size: var(--text-sm);
  color: var(--text-muted); transition: var(--transition-control); white-space: nowrap;
  display: inline-flex; align-items: center; gap: 7px;
}
.abg-tab:hover{ color: var(--text-strong); }
.abg-tab:focus-visible{ outline: none; box-shadow: var(--focus-ring); border-radius: var(--radius-sm); }
.abg-tab svg{ width: 1.05em; height: 1.05em; }

.abg-tabs--underline .abg-tab{ padding: 12px 0 14px; position: relative; }
.abg-tabs--underline .abg-tab[aria-selected="true"]{ color: var(--text-strong); }
.abg-tabs--underline .abg-tab[aria-selected="true"]::after{
  content:""; position: absolute; left: 0; right: 0; bottom: -1px; height: 2.5px;
  background: var(--brand); border-radius: var(--radius-pill);
}
.abg-tabs--pill .abg-tab{ padding: 8px 16px; border-radius: var(--radius-pill); }
.abg-tabs--pill .abg-tab[aria-selected="true"]{ background: var(--surface-raised); color: var(--text-strong); box-shadow: var(--shadow-xs); }
.abg-tab__count{ font-size: var(--text-2xs); font-weight: var(--fw-bold); background: var(--clay-200); color: var(--text-muted); padding: 1px 6px; border-radius: var(--radius-pill); }
.abg-tab[aria-selected="true"] .abg-tab__count{ background: var(--brand-soft); color: var(--brand-on-soft); }
`;

let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'tabs');
  el.textContent = TABS_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/** Horizontal tab switcher. Controlled via `value` + `onChange`. */
export function Tabs({ items = [], value, onChange, variant = 'underline', className = '', ...rest }) {
  ensureStyles();
  const cls = ['abg-tabs', `abg-tabs--${variant}`, className].filter(Boolean).join(' ');
  return (
    <div className={cls} role="tablist" {...rest}>
      {items.map((it) => {
        const key = it.value ?? it.label;
        const selected = key === value;
        return (
          <button
            key={key}
            className="abg-tab"
            role="tab"
            aria-selected={selected}
            onClick={() => onChange && onChange(key)}
          >
            {it.icon}
            {it.label}
            {it.count != null && <span className="abg-tab__count">{it.count}</span>}
          </button>
        );
      })}
    </div>
  );
}
