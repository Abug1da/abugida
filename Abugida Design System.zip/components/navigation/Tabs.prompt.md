Controlled horizontal tab switcher.

```jsx
const [tab, setTab] = React.useState('learn');
<Tabs
  value={tab}
  onChange={setTab}
  items={[
    { value: 'learn', label: 'Learn', icon: <i data-lucide="book-open" /> },
    { value: 'review', label: 'Review', count: 12 },
    { value: 'archive', label: 'Archive' },
  ]}
/>
```

- **variant**: `underline` (section nav) · `pill` (segmented control).
- Each item may carry an `icon` and a `count` badge.
