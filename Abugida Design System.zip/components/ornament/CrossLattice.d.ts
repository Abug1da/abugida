import * as React from 'react';

/**
 * The Ethiopian cross — latticed, interwoven, flared arms — tiled as a
 * ground texture. Absolutely position it behind content; it fills its
 * container. Keep the opacity low: it is a ground, not a feature.
 */
export interface CrossLatticeProps extends React.SVGAttributes<SVGSVGElement> {
  /** Pixels per cell; the cross is 11 cells square. @default 5 */
  cell?: number;
  /** @default "var(--pigment-tiqur)" */
  color?: string;
  /** @default 0.09 */
  opacity?: number;
  /** Empty cells between repeats. @default 3 */
  gutter?: number;
}

export function CrossLattice(props: CrossLatticeProps): JSX.Element;
