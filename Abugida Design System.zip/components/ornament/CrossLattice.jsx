import React from 'react';

/* ------------------------------------------------------------------
   The Ethiopian cross as a ground texture.

   Not a Latin or Greek cross: the Ethiopian form is latticed and
   interwoven, with flared arms and openwork between them — the shape
   you see cut into Lalibela, hammered into Axum hand crosses, and
   painted into manuscript headpieces. Drawn on a cell grid so it stays
   rectilinear and never reads as clip art.
   ------------------------------------------------------------------ */

let latId = 0;
const nextLatId = () => `lat-${(++latId).toString(36)}-${Math.random().toString(36).slice(2, 7)}`;

/* Counted draft, 11×11. Each arm WIDENS toward its tip — the flare is
   what separates an Ethiopian cross from a Latin or Greek one — and the
   notches where the arms meet leave the openwork the form is known for. */
const DRAFT = [
  '..#######..',
  '..#######..',
  '##.#####.##',
  '###.###.###',
  '###########',
  '###########',
  '###########',
  '###.###.###',
  '##.#####.##',
  '..#######..',
  '..#######..',
];

export function CrossLattice({
  cell = 5,
  color = 'var(--pigment-tiqur)',
  opacity = 0.09,
  gutter = 3,
  className = '',
  style,
  ...rest
}) {
  const idRef = React.useRef(null);
  if (!idRef.current) idRef.current = nextLatId();
  const id = idRef.current;

  const n = DRAFT.length;
  const px = Number(cell) || 5;
  const gut = Number(gutter) || 0;
  const op = Number(opacity);
  const span = (n + gut) * px;

  const rects = [];
  for (let r = 0; r < n; r++) {
    for (let c = 0; c < n; c++) {
      if (DRAFT[r][c] !== '#') continue;
      rects.push(
        <rect key={`${r}-${c}`} x={c * px} y={r * px} width={px + 0.3} height={px + 0.3} shapeRendering="crispEdges" />
      );
    }
  }

  return (
    <svg width="100%" height="100%" role="presentation" className={className} style={{ display: 'block', ...style }} {...rest}>
      <defs>
        <pattern id={id} patternUnits="userSpaceOnUse" width={span} height={span}>
          <g fill={color} opacity={Number.isFinite(op) ? op : 0.09} transform={`translate(${(gut * px) / 2} ${(gut * px) / 2})`}>
            {rects}
          </g>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill={`url(#${id})`} />
    </svg>
  );
}
