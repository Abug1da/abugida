import * as React from 'react';

/**
 * Fidel used as texture rather than as text — large, faint Geʼez
 * characters behind a surface. Reads as specifically Ethiopian long
 * before it reads as language. Position the parent `relative`; this
 * fills it and is hidden from assistive tech.
 */
export interface FidelFieldProps extends React.HTMLAttributes<HTMLDivElement> {
  /** `field` repeats a grid, `watermark` bleeds one giant glyph off the corner, `column` runs a margin strip. @default "field" */
  mode?: 'field' | 'watermark' | 'column';
  /** Glyph source. Defaults to the base (ግዕዝ) order of every family. */
  chars?: string;
  /** Glyph size in px. Go big — 96 and up for a field, 400+ for a watermark. @default 96 */
  size?: number;
  /** Spacing as a fraction of size. @default 0.35 */
  gap?: number;
  /** Keep it very low; this is a ground. @default 0.05 */
  opacity?: number;
  /** @default "currentColor" */
  color?: string;
  /** Changes which glyphs land where, deterministically. @default 7 */
  seed?: number;
  /** Degrees of rotation. @default 0 */
  rotate?: number;
  /** Use this exact string instead of sampling `chars`. */
  text?: string;
}

export function FidelField(props: FidelFieldProps): JSX.Element;
