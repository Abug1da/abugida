import React from 'react';

/* ------------------------------------------------------------------
   FIDEL AS TEXTURE

   The Geʼez script is one of the few indigenous African writing systems
   still in daily use, and its rounded, blocky rhythm is recognisable
   long before it is readable. Used large and faint it works the way
   kanji does in Japanese design: confident, specific, and unmistakably
   from one place.

   This is decoration made of language, so it is hidden from the
   accessibility tree and never selectable.
   ------------------------------------------------------------------ */

/* The base order (ግዕዝ) of every family — the script's own index. */
const BASE_ORDER = 'ሀለሐመሠረሰቀበተኀነአከወዐዘየደገጠጰጸፀፈፐ';

/** Deterministic per-index pick, so the field never reshuffles on re-render. */
function pick(source, i, seed) {
  const h = (i * 2654435761 + seed * 40503) >>> 0;
  return source[h % source.length];
}

export function FidelField({
  mode = 'field',
  chars = BASE_ORDER,
  size = 96,
  gap = 0.35,
  opacity = 0.05,
  color = 'currentColor',
  seed = 7,
  rotate = 0,
  text,
  className = '',
  style,
  ...rest
}) {
  /* Coerce so templates and HTML attributes may pass strings. */
  const fs = Number(size) || 96;
  const gp = Number(gap);
  const g = Number.isFinite(gp) ? gp : 0.35;
  const op = Number(opacity);
  const rot = Number(rotate) || 0;

  const base = {
    position: 'absolute',
    inset: 0,
    overflow: 'hidden',
    pointerEvents: 'none',
    userSelect: 'none',
    fontFamily: 'var(--font-fidel)',
    color,
    opacity: Number.isFinite(op) ? op : 0.05,
    ...style,
  };

  /* One enormous character, bled off the edge. */
  if (mode === 'watermark') {
    return (
      <div aria-hidden="true" className={className} style={base} {...rest}>
        <div style={{
          position: 'absolute', insetInlineEnd: '-0.16em', bottom: '-0.34em',
          fontSize: fs, lineHeight: 0.78, whiteSpace: 'nowrap',
          transform: rot ? `rotate(${rot}deg)` : undefined,
        }}>
          {text || chars[0]}
        </div>
      </div>
    );
  }

  /* A vertical running column, as down the margin of a codex. */
  if (mode === 'column') {
    const n = Math.max(1, Math.round(1200 / (fs * (1 + g))));
    return (
      <div aria-hidden="true" className={className} style={base} {...rest}>
        <div style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center',
          fontSize: fs, lineHeight: 1 + g,
        }}>
          {Array.from({ length: n }, (_, i) => (
            <span key={i}>{text ? text[i % text.length] : pick(chars, i, seed)}</span>
          ))}
        </div>
      </div>
    );
  }

  /* A repeating field — the default. Rows are offset by half a cell so
     the grid reads as woven cloth rather than a spreadsheet. */
  const step = fs * (1 + g);
  const rows = Math.ceil(1100 / step) + 1;
  const cols = Math.ceil(1800 / step) + 1;

  return (
    <div aria-hidden="true" className={className} style={base} {...rest}>
      <div style={{ transform: rot ? `rotate(${rot}deg) scale(1.5)` : undefined }}>
        {Array.from({ length: rows }, (_, r) => (
          <div key={r} style={{
            display: 'flex', gap: fs * g, fontSize: fs, lineHeight: 1 + g,
            marginInlineStart: r % 2 ? step / 2 : 0, whiteSpace: 'nowrap',
          }}>
            {Array.from({ length: cols }, (_, c) => (
              <span key={c}>{text ? text[(r * cols + c) % text.length] : pick(chars, r * cols + c, seed)}</span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

FidelField.baseOrder = BASE_ORDER;
