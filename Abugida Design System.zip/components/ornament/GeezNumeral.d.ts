import * as React from 'react';

/** Convert a positive integer to Geʼez figures (፩ ፪ ፫ …). Returns '' for zero. */
export function toGeez(value: number): string;

/**
 * A number written in Geʼez figures. Use for lesson and chapter numbers,
 * step counts, ranks — anywhere the product counts something. The Latin
 * value stays in the accessibility tree.
 */
export interface GeezNumeralProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** The number to render. */
  value: number;
  /** Trail the Latin figure in mono, for teaching contexts. @default false */
  showLatin?: boolean;
  /** @default "inherit" */
  tone?: 'inherit' | 'rubric' | 'gold' | 'muted';
}

export function GeezNumeral(props: GeezNumeralProps): JSX.Element;
