import React from 'react';

/* ------------------------------------------------------------------
   Geʼez numerals — ፩ ፪ ፫ …
   Ethiopia counts with its own figures, derived from Greek letters and
   marked with over- and under-bars. A learning product that renders
   "Lesson 3" in Latin digits has already conceded the point; this
   renders ትምህርት ፫.
   ------------------------------------------------------------------ */

const ONES = ['', '፩', '፪', '፫', '፬', '፭', '፮', '፯', '፰', '፱'];
const TENS = ['', '፲', '፳', '፴', '፵', '፶', '፷', '፸', '፹', '፺'];
const HUNDRED = '፻';
const MYRIAD = '፼';

/** 1–99 → Geʼez. */
function pair(n) {
  if (n <= 0) return '';
  return TENS[Math.floor(n / 10)] + ONES[n % 10];
}

/**
 * Convert a positive integer to Geʼez figures.
 * Handles 1–99,999,999, which covers every counter a product will show.
 * Zero has no Geʼez figure — the system is additive — so it returns ''.
 */
export function toGeez(value) {
  let n = Math.floor(Math.abs(Number(value) || 0));
  if (n < 1) return '';
  if (n < 100) return pair(n);

  const myriads = Math.floor(n / 10000);
  const rest = n % 10000;
  let out = '';

  if (myriads) {
    // ፼ alone carries a leading one, exactly as ፻ does.
    out += (myriads === 1 ? '' : toGeez(myriads)) + MYRIAD;
  }
  const hundreds = Math.floor(rest / 100);
  const units = rest % 100;
  if (hundreds) out += (hundreds === 1 ? '' : pair(hundreds)) + HUNDRED;
  if (units) out += pair(units);
  return out;
}

/**
 * Renders a number in Geʼez figures, with the Latin value kept in the
 * accessibility tree so screen readers and copy-paste still work.
 */
export function GeezNumeral({
  value,
  showLatin = false,
  tone = 'inherit',
  className = '',
  style,
  ...rest
}) {
  const geez = toGeez(value);
  const color = { inherit: undefined, rubric: 'var(--pigment-kin)', gold: 'var(--pigment-werq)', muted: 'var(--text-muted)' }[tone];
  return (
    <span
      className={className}
      style={{ fontFamily: 'var(--font-fidel)', color, fontFeatureSettings: '"liga" 0', ...style }}
      {...rest}
    >
      <span aria-hidden="true">{geez || '—'}</span>
      <span style={{ position: 'absolute', width: 1, height: 1, overflow: 'hidden', clip: 'rect(0 0 0 0)', whiteSpace: 'nowrap' }}>
        {value}
      </span>
      {showLatin && (
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7em', color: 'var(--text-faint)', marginInlineStart: '0.4em' }} aria-hidden="true">
          {value}
        </span>
      )}
    </span>
  );
}
