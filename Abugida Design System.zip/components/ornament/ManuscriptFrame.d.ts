import * as React from 'react';

/**
 * A Geʼez codex page as a layout primitive — woven crown, rubricated
 * title numbered in Geʼez figures, text block, and an outer margin
 * reserved for the scribe's gloss. Use for any long-form or archival
 * surface instead of a plain Card.
 */
export interface ManuscriptFrameProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Rubricated section title. */
  title?: React.ReactNode;
  /** Section number, rendered in Geʼez figures. */
  number?: number;
  /** Marginal note, set in the outer column in red as a scribe would. */
  gloss?: React.ReactNode;
  /** Which woven band crowns the page. @default "diamond" */
  motif?: 'diamond' | 'chevron' | 'terrace' | 'cross' | 'box' | 'ladder' | 'dash';
  /** Draw the opening band. @default true */
  crown?: boolean;
  /** Draw the mirrored closing band. @default true */
  foot?: boolean;
  children?: React.ReactNode;
}

export function ManuscriptFrame(props: ManuscriptFrameProps): JSX.Element;
