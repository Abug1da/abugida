import React from 'react';
import { Tibeb } from './Tibeb.jsx';
import { GeezNumeral } from './GeezNumeral.jsx';

/* ------------------------------------------------------------------
   The page of a Geʼez codex, as a layout primitive: a woven crown, a
   rubricated title, the text block, and an outer margin reserved for
   the scribe's gloss. Sections are numbered in Geʼez figures.
   ------------------------------------------------------------------ */

const FRAME_CSS = `
.abg-ms{ position: relative; background: var(--surface-raised); border: var(--border-width) solid var(--border-subtle); border-radius: var(--radius-sm); overflow: clip; }
.abg-ms__body{ display: grid; gap: var(--space-6, 32px); padding: var(--space-6, 32px); }
.abg-ms--gloss .abg-ms__body{ grid-template-columns: 1fr minmax(0, 14ch); }
.abg-ms__head{ display: flex; align-items: baseline; gap: var(--space-3, 12px); margin-bottom: var(--space-4, 16px); }
.abg-ms__num{ font-size: var(--text-xl); }
.abg-ms__title{ font-family: var(--font-display); font-size: var(--text-2xl); color: var(--pigment-kin); font-weight: var(--fw-medium); line-height: var(--leading-snug); }
.abg-ms__gloss{ font-family: var(--font-fidel); font-size: var(--text-xs); line-height: var(--leading-snug); color: var(--pigment-kin); border-inline-start: 1px solid var(--border-subtle); padding-inline-start: var(--space-4, 16px); }
@media (max-width: 720px){ .abg-ms--gloss .abg-ms__body{ grid-template-columns: 1fr; } .abg-ms__gloss{ border-inline-start: 0; padding-inline-start: 0; } }
`;

let _injected = false;
function ensureStyles() {
  if (_injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.setAttribute('data-abg', 'manuscript-frame');
  el.textContent = FRAME_CSS;
  document.head.appendChild(el);
  _injected = true;
}

/** A manuscript page: woven crown, rubricated title, text block, margin gloss. */
export function ManuscriptFrame({
  title,
  number,
  gloss,
  motif = 'diamond',
  crown = true,
  foot = true,
  className = '',
  children,
  ...rest
}) {
  ensureStyles();
  const cls = ['abg-ms', gloss ? 'abg-ms--gloss' : '', className].filter(Boolean).join(' ');
  return (
    <div className={cls} {...rest}>
      {crown && <Tibeb motif={motif} cell={3} palette="scribe" ground="var(--surface-raised)" />}
      <div className="abg-ms__body">
        <div>
          {(title || number != null) && (
            <div className="abg-ms__head">
              {number != null && <GeezNumeral className="abg-ms__num" value={number} tone="gold" />}
              {title && <div className="abg-ms__title">{title}</div>}
            </div>
          )}
          {children}
        </div>
        {gloss && <aside className="abg-ms__gloss">{gloss}</aside>}
      </div>
      {foot && <Tibeb motif="dash" cell={3} palette="scribe" ground="var(--surface-raised)" flip />}
    </div>
  );
}
