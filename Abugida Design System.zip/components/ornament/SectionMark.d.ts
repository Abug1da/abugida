import * as React from 'react';

/**
 * A divider built from real Geʼez punctuation rather than a bullet or
 * an em-dash. `paragraph` (፨) is the default section break.
 */
export interface SectionMarkProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Which mark. @default "paragraph" */
  mark?: 'section' | 'paragraph' | 'stop' | 'comma' | 'colon' | 'preface';
  /** Draw hairlines either side, making it a full-width break. @default true */
  rules?: boolean;
  /** @default "rubric" */
  tone?: 'rubric' | 'gold' | 'indigo' | 'muted';
  /** @default "md" */
  size?: 'sm' | 'md' | 'lg';
  /** Optional overline label set between the left rule and the mark. */
  label?: string;
}

export function SectionMark(props: SectionMarkProps): JSX.Element;
