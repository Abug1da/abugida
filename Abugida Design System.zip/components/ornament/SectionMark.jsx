import React from 'react';

/* ------------------------------------------------------------------
   Geʼez punctuation as UI furniture.
   ፠ opens a titled section · ፨ separates movements of a text ·
   ። ends a statement · ፣ ፤ ፥ divide series, lists, quotations.
   These are the marks the script actually uses. Reaching for a bullet
   or an em-dash instead is the generic choice.
   ------------------------------------------------------------------ */

const MARKS = {
  section: '፠',
  paragraph: '፨',
  stop: '።',
  comma: '፣',
  colon: '፤',
  preface: '፥',
};

/**
 * A divider built from Geʼez punctuation. With `rules` it becomes a
 * full-width section break; without, an inline separator.
 */
export function SectionMark({
  mark = 'paragraph',
  rules = true,
  tone = 'rubric',
  size = 'md',
  label,
  className = '',
  style,
  ...rest
}) {
  const glyph = MARKS[mark] || MARKS.paragraph;
  const color = { rubric: 'var(--pigment-kin)', gold: 'var(--pigment-werq)', indigo: 'var(--pigment-semayawi)', muted: 'var(--text-faint)' }[tone] || tone;
  const fs = { sm: 14, md: 20, lg: 30 }[size] || 20;

  const rule = (key) => (
    <span
      key={key}
      aria-hidden="true"
      style={{ flex: 1, height: 1, background: 'currentColor', opacity: 0.28, minWidth: 16 }}
    />
  );

  if (!rules) {
    return (
      <span aria-hidden="true" className={className} style={{ color, fontFamily: 'var(--font-fidel)', fontSize: fs, lineHeight: 1, ...style }} {...rest}>
        {glyph}
      </span>
    );
  }

  return (
    <div
      className={className}
      role="separator"
      style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-4, 16px)', color, ...style }}
      {...rest}
    >
      {rule('l')}
      {label && (
        <span style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-xs)', fontWeight: 'var(--fw-bold)', letterSpacing: 'var(--tracking-caps)', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>
          {label}
        </span>
      )}
      <span aria-hidden="true" style={{ fontFamily: 'var(--font-fidel)', fontSize: fs, lineHeight: 1 }}>{glyph}</span>
      {rule('r')}
    </div>
  );
}
