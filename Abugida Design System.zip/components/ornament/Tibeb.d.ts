import * as React from 'react';

/**
 * ጥብብ Tibeb — the woven band from a netela or habesha kemis, built on a
 * discrete cell grid because a loom cannot make a curve. Use it to EDGE a
 * surface: header underline, card cap, section divider, footer rule.
 *
 * The netela rule: the field stays cream and the colour lives in the band.
 */
export interface TibebProps extends React.SVGAttributes<SVGSVGElement> {
  /** Which counted draft. @default "diamond" */
  motif?: 'diamond' | 'chevron' | 'terrace' | 'cross' | 'box' | 'ladder' | 'dash';
  /** Pixels per woven cell — this is the only size control. Band height is rows × cell. @default 3 */
  cell?: number;
  /** A named thread set, or four explicit colours. @default "buna" */
  palette?: 'buna' | 'netela' | 'bright' | 'scribe' | string[];
  /** Wrap the motif in the checkered selvedge that frames the real cloth. @default true */
  frame?: boolean;
  /** Override the two selvedge colours. */
  frameColors?: string[];
  /** Fill behind the threads. Leave unset for a transparent band. */
  ground?: string;
  /** Mirror vertically, for closing a section. @default false */
  flip?: boolean;
}

export function Tibeb(props: TibebProps): JSX.Element;
