import React from 'react';

/* ------------------------------------------------------------------
   ጥብብ TIBEB — the woven band.

   Everything here is built on a discrete cell grid, because tibeb IS a
   grid: warp and weft. A loom cannot make a curve, so neither does this
   component. Each motif is written as a COUNTED DRAFT — the same way a
   weaver reads a pattern off squared paper — which keeps the geometry
   honest to the craft and makes it trivial to tune.

   THE NETELA RULE
   The field stays cream; the colour lives in the band. A netela is a
   white shawl with one blazing border, and that contrast is the entire
   effect. Saturated colour anywhere else and the band stops being
   special. Use these to EDGE a surface — never to fill one.
   ------------------------------------------------------------------ */

/* Letters index the palette; '.' is ground (left transparent).
   Drafts are read top row first, exactly like a weaving pattern. */
const DRAFTS = {
  /* The signature netela lozenge — concentric diamonds around a core. */
  diamond: [
    '....A....',
    '...AAA...',
    '..AABAA..',
    '.AABCBAA.',
    'AABCDCBAA',
    '.AABCBAA.',
    '..AABAA..',
    '...AAA...',
    '....A....',
  ],
  /* Two parallel zigzag courses — the running chevron. */
  chevron: [
    'AA....AA',
    '.AA..AA.',
    '..AAAA..',
    'BB....BB',
    '.BB..BB.',
    '..BBBB..',
  ],
  /* Stepped pyramid — the Aksumite stele and rock-hewn terrace profile. */
  terrace: [
    '....BB....',
    '...BAAB...',
    '..BAAAAB..',
    '.BAAAAAAB.',
    'BAAAAAAAAB',
    'BBBBBBBBBB',
  ],
  /* Ethiopian cross — arms that flare toward their ends, contrasting
     core. Nothing like a Latin or Greek cross, which do not flare. */
  cross: [
    '....AAA....',
    '....AAA....',
    '..AAAAAAA..',
    '..AABBBAA..',
    '.AAABBBAAA.',
    '..AABBBAA..',
    '..AAAAAAA..',
    '....AAA....',
    '....AAA....',
  ],
  /* Nested squares — the boxed motif scattered across a netela field. */
  box: [
    'AAAAA',
    'A...A',
    'A.B.A',
    'A...A',
    'AAAAA',
  ],
  /* The checkered selvedge that frames every band in the real cloth. */
  ladder: [
    'ABAB',
    'BABA',
  ],
  /* The quiet band — a counted dash for dense UI. */
  dash: [
    'AABB',
  ],
};

/* Named thread sets. Saturated colour is confined to these. */
const PALETTES = {
  /* Coffee ceremony — ochre, rust, deep brown, cream. The default. */
  buna: ['#A8412A', '#C98A2B', '#4A2E1E', '#F7EFE1'],
  /* Classic netela border: lampblack ground, gold, red, green. */
  netela: ['#241A14', '#C98A2B', '#B4341F', '#1F6F52'],
  /* The full saturated cloth, for one hero band only. */
  bright: ['#C4321C', '#E8B02A', '#1F6F52', '#1D4A7A'],
  /* Ink and gold — the manuscript register. */
  scribe: ['#241A14', '#C98A2B', '#A8412A', '#F7EFE1'],
};

let tibId = 0;
const nextTibId = () => `tibeb-${(++tibId).toString(36)}-${Math.random().toString(36).slice(2, 7)}`;

/** Expand a draft into cells, optionally wrapped in a checkered selvedge. */
function buildGrid(motif, frame) {
  const draft = DRAFTS[motif] || DRAFTS.diamond;
  if (!frame || motif === 'ladder' || motif === 'dash') return draft;
  const w = draft[0].length;
  const checker = (o) => Array.from({ length: w }, (_, i) => ((i + o) % 2 ? 'F' : 'E')).join('');
  const blank = '.'.repeat(w);
  return [checker(0), blank, ...draft, blank, checker(0)];
}

/**
 * Tibeb — a woven band. Tiles seamlessly to any width via an SVG pattern
 * in user-space units, so it never stretches, blurs, or resamples.
 */
export function Tibeb({
  motif = 'diamond',
  cell = 3,
  palette = 'buna',
  frame = true,
  frameColors,
  ground,
  flip = false,
  className = '',
  style,
  ...rest
}) {
  const idRef = React.useRef(null);
  if (!idRef.current) idRef.current = nextTibId();
  const id = idRef.current;

  const threads = Array.isArray(palette) ? palette : (PALETTES[palette] || PALETTES.buna);
  const fc = frameColors || [threads[2] || '#241A14', threads[1] || '#C98A2B'];
  const ink = { A: threads[0], B: threads[1], C: threads[2], D: threads[3], E: fc[0], F: fc[1] };

  /* Coerce so templates and HTML attributes may pass strings. */
  const px = Number(cell) || 3;
  const grid = buildGrid(motif, frame !== false && frame !== 'false');
  const rows = grid.length;
  const cols = grid[0].length;
  const H = rows * px;
  const W = cols * px;

  const rects = [];
  for (let r = 0; r < rows; r++) {
    const line = grid[r];
    for (let c = 0; c < cols; c++) {
      const ch = line[c];
      if (!ch || ch === '.') continue;
      const fill = ink[ch];
      if (!fill) continue;
      /* Cells are drawn a hair oversized so neighbours butt cleanly and
         no seam shows between them at fractional device pixels. */
      rects.push(
        <rect key={`${r}-${c}`} x={c * px} y={r * px} width={px + 0.35} height={px + 0.35} fill={fill} shapeRendering="crispEdges" />
      );
    }
  }

  return (
    <svg
      width="100%"
      height={H}
      role="presentation"
      className={className}
      style={{ display: 'block', transform: flip ? 'scaleY(-1)' : undefined, ...style }}
      {...rest}
    >
      <defs>
        <pattern id={id} patternUnits="userSpaceOnUse" width={W} height={H}>
          {ground && <rect width={W} height={H} fill={ground} />}
          {rects}
        </pattern>
      </defs>
      <rect width="100%" height={H} fill={`url(#${id})`} />
    </svg>
  );
}

Tibeb.motifs = Object.keys(DRAFTS);
Tibeb.palettes = PALETTES;
