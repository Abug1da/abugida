# Abugida — Design System

> **አቡጊዳ** · A free, web-based home for learning Amharic and preserving Ethiopian heritage for the diaspora.

Abugida is a non-profit. Its first product is a **free, web-based Amharic learning platform**; a **cultural archive** will follow. This design system is a *modern take on Ethiopian culture* — drawing on the visual language of Ethiopian Orthodox illuminated manuscripts, habesha textiles (tibeb), and the Geʼez (fidel) script, then rendering it with contemporary editorial restraint.

The name is the point: an **abugida** is the linguistic term for the Geʼez writing system itself — a script where each character is a consonant-plus-vowel unit. The product teaches the very thing it is named after.

---

## Sources

This system was created **from a written brief, with no attached codebase or Figma file.** There is no existing product to recreate; the brand, palette, typography, voice, components, and UI kit here are an original proposal built to the brief:

> *"Abugida — a non-profit preserving Ethiopian heritage for the diaspora. We're building a free, web-based home for learning Amharic, with a cultural archive to follow. I want a modern take of Ethiopian culture."*

If a real codebase, Figma library, or existing brand assets exist, share them and this system should be reconciled against them. Treat everything here as a **strong v1 direction**, not a recreation of shipped work.

---

## Content fundamentals — how Abugida writes

**Voice:** warm, plain-spoken, and quietly proud. A patient teacher and a welcoming cousin — never a hype-driven app, never an academic.

- **Person:** Speak to the learner as **"you."** Abugida is **"we"** sparingly, mostly disappearing behind the learner's progress.
- **Tone:** Encouraging and concrete. Lead with what the learner can *do today*, not features. *"Start with seven sounds. You'll read your first word today."*
- **Casing:** Sentence case everywhere — headings, buttons, labels. Title Case is avoided. ALL-CAPS only for tiny eyebrow/overline labels (tracked out).
- **Jargon:** None. No "SRS engine," "gamified," "leverage," "optimize retention." Say *review*, *practice*, *streak*, *remember*.
- **Heritage, handled with care:** Cultural terms appear in Amharic with a light gloss the first time — *buna* (coffee), *tibeb* (woven border), *fidel* (the script). Geʼez text is first-class, not decoration; always pair new fidel with romanization and, where useful, audio.
- **Emoji:** Not used in product UI or marketing. The fidel characters themselves carry the visual warmth.
- **Numbers & metrics:** Used only when they help the learner (streak days, letters mastered, minutes). Never vanity stats or dashboards-for-their-own-sake.

**Example copy**

- Hero: *"Learn the language of home."*
- Sub: *"A free, modern home for Amharic — start with the fidel and read your first word today."*
- Button: *"Start learning"* · *"Continue lesson"* · *"Practice review"*
- Empty state: *"Nothing to review yet. Finish a lesson and it'll show up here."*
- Encouragement: *"Three in a row. The ሰ family is starting to stick."*

---

## Visual foundations

The system's first draft was a **"modern manuscript"** aesthetic — parchment, a serif, some fidel — and it read like every heritage brand on the internet. Culture was being used as *texture*. The system now treats it as **structure**: the motifs below are load-bearing furniture, not decoration laid on top.

### The cultural vocabulary

**ጥብብ Tibeb — the woven band.** The coloured selvedge of the netela and habesha kemis, and the system's primary structural element. Every divider, card cap, section break, and header underline is a `Tibeb` — not a hairline rule.

Critically, it is built on a **discrete cell grid**, because tibeb *is* a grid: warp and weft. A loom cannot make a curve, so neither does the component. Each motif is written as a **counted draft** — the same way a weaver reads a pattern off squared paper:

```
diamond: '....A....'
         '...AAA...'
         '..AABAA..'
         '.AABCBAA.'
         'AABCDCBAA'
```

Seven motifs: `diamond` (the signature netela lozenge), `chevron` (the running zigzag course), `terrace` (the Aksumite stepped profile), `cross` (flared arms, openwork), `box` (the scattered netela square), `ladder` (the checkered selvedge), `dash` (the quiet divider). Size is set in **cells**, not pixels — one cell is one thread crossing, and band height is always rows × cell.

> An earlier version of this system drew these bands as sine waves and interlocking circles. That was wrong: smooth interlace reads as generic Celtic knotwork, not Ethiopian. Rectilinear counted geometry is the whole difference.

**Geʼez punctuation as UI furniture.** The script has its own marks and they have jobs: `፠` opens a titled section, `፨` separates movements of a text, `።` ends a statement, `፣ ፤ ፥` divide series, lists, and quotations. Nav separators, dividers, and section breaks use these. Reaching for a bullet or an em-dash instead is the generic choice.

**Geʼez numerals.** The product counts in `፩ ፪ ፫`. Lesson numbers, chapter numbers, steps, ranks — all Ethiopian figures, with the Latin value kept in the accessibility tree. A learning product that renders "Lesson 3" in Latin digits has already conceded the point.

**Fidel as texture.** The Geʼez script is one of the few indigenous African writing systems still in daily use, and its rounded, blocky rhythm is recognisable long before it is readable. `FidelField` sets it large and faint behind a surface — the way Japanese design uses kanji. Three modes: `field` (a repeating grid), `watermark` (one enormous glyph bled off a corner), `column` (a running margin strip). It is decoration made of language, so it is hidden from assistive tech and never selectable.

**The Ethiopian cross.** Not a Latin or Greek cross: the Ethiopian form is latticed and interwoven, and its arms **widen toward their tips**. That flare is the whole tell. `CrossLattice` tiles it as a very low-contrast ground behind dark surfaces.

**Rubrication as a semantic.** Red ink in a manuscript is not an accent — it marks the thing being *named*. Names, months, script terms, section openings, and marginal glosses take kin vermilion; everything else is lampblack. Red is deliberately **not** the colour of a call to action, which would turn a sacred convention into a sales device.

**The margin gloss.** Geʼez codices set a narrow text column against a wide outer margin carrying the scribe's annotations in red. `ManuscriptFrame` and the landing hero both reserve that column — it is where context, etymology, and cultural notes belong.

**The coffee ceremony palette — deliberately not the flag colours.** Green/yellow/red is the most over-fished palette in "African-themed" design; it reads generic pan-African rather than specifically Ethiopian. The buna ceremony gives a rarer, warmer set: **ቡና rust** `#A8412A` (roasted bean, the primary) · **ወርቅ ochre** `#C98A2B` (coffee cherry, turmeric, straw) · **ጥቁር bean** `#4A2E1E` (deep roast) · **ጀበና jebena** `#241A14` (the clay pot, fired near-black) · **አመድ ash** `#8C7A67` (wood ash) · **ጥጥ cream** `#F7EFE1` (unbleached cotton, the field). No pure white and no pure black anywhere.

**The netela rule.** A netela is a white shawl with one blazing woven border, and that contrast is the entire effect. So: the field stays cream, and saturated colour is confined to the tibeb bands. Indigo `#1D4A7A` and green `#1F6F52` exist in this system *only* as threads inside a weave — never as a surface, a button, or a block of background.

### The rest of the foundation

**Typography.**
- **Newsreader** (serif) for display & headlines — editorial, optical-sized, with italics used for warm emphasis (*"the language of home"*).
- **Hanken Grotesk** (humanist sans) for all UI and body — friendly, highly legible.
- **Noto Serif Ethiopic** for fidel — the real Geʼez script, treated as a hero element at large sizes and always set with generous line-height.
- **Space Mono** for romanization keys, token labels, and small technical captions.
- Type is large and confident; long-form reading is measured (~66ch, 1.7 line-height).

**Backgrounds.** Flat cream by default — the netela field. Texture comes from `FidelField` (oversized faint Geʼez) or `CrossLattice`, never from a gradient. An optional barely-there grain (`.bg-parchment`) adds cloth depth. Full-bleed photography (coffee ceremonies, highlands, manuscripts, markets) is warm-toned, slightly desaturated, with a gentle golden cast; dark scrims use warm ink, not black.

**The fidel table** is the signature structural motif — and it is presented as a *table*, with its seven vowel orders named as Ethiopians name them (ግዕዝ ካዕብ ሣልስ ራብዕ ኃምስ ሳድስ ሳብዕ), not numbered 1–7. The syllabary *is* a grid, so grids of character tiles recur throughout.

**Shape & elevation.**
- **Corners are soft** — controls `10px`, cards `16px`, feature panels `24px`, pills fully round. Manuscripts have no hard edges.
- **Shadows are warm and low**, tinted with clay (`rgba(58,48,39,…)`), never pure black — a soft, paper-on-paper lift. Five steps, xs→xl. Sunken wells use a subtle inset shadow.
- **Borders** are warm clay hairlines (`1–1.5px`); the focus ring is a soft **saffron** halo.

**Motion.** Restrained and soft. `ease-out` (`cubic-bezier(.22,1,.36,1)`) for most transitions, 120–360ms. Hovers **lift** cards (−2px) and deepen shadow; **presses** settle them back down (translateY to 0) — a tactile, physical feel rather than flashy animation. No bounces, no infinite loops, no parallax. Honors `prefers-reduced-motion`.

**Hover / press states.**
- Buttons: darken the fill on hover, darken further + nudge down `1px` on press.
- Cards & tiles: lift + shadow on hover, settle on press; brand-color border on hover for interactive tiles.
- Icon/ghost controls: warm clay wash (`clay-100/200`) on hover.

**Transparency & blur:** used sparingly — only for the modal scrim (warm-ink at 55%) and the occasional sticky header. Not a glassmorphism system.

---

## Iconography

- **Primary set: [Lucide](https://lucide.dev)** — clean, consistent `1.5–2px` stroke icons, used **only inside the app UI** (toolbars, controls, list affordances). **This is a substitution flag:** with no brand icon set provided, Lucide was chosen as the closest modern, open, stroke-based match. If Abugida adopts a bespoke icon set, swap it here.
- **Marketing surfaces use no icons at all.** An icon in a rounded square is the single most generic element on the web. Where a feature list would normally take icons, the landing uses Geʼez chapter numerals and a harag rule instead — the number *is* the icon.
- **Stroke, not fill.** Icons are outline-style, sized in `em` so they scale with text (≈`1.1em` inline, `18–22px` in icon buttons).
- **The fidel is not an icon.** Geʼez characters are typographic content (Noto Serif Ethiopic), never redrawn as SVG or treated as decoration.
- **No emoji** anywhere in the system.
- **Logo / mark:** a typographic lockup — the fidel character **አ** (the "a" of Abugida) in a vermilion rounded tile, beside the **Abugida** wordmark in Newsreader. It is built from real type (see `guidelines/brand-logo.card.html`), so it inherits the Ethiopic webfont rather than being a flattened image. No standalone illustrated logo asset is shipped; reproduce the lockup with the documented markup or the kit's `Logo` usage.

> **Note on assets:** because this system was built from a brief with no source files, it ships **no photography or illustration binaries.** Full-bleed imagery referenced in kits uses neutral placeholders. Provide real, rights-cleared photography (coffee ceremonies, highlands, manuscripts, learners) and it should be added under `assets/` and wired in.

---

## What's in here — index & manifest

**Root**
- `styles.css` — the single entry point consumers link. `@import`s everything below. *(Rules live in `tokens/`, never here.)*
- `readme.md` — this file.
- `SKILL.md` — makes this system usable as a downloadable Claude Agent Skill.

**Tokens** (`tokens/`, all `@import`ed by `styles.css`)
- `fonts.css` — `@import`s the webfonts (Google Fonts CDN — see caveat below).
- `colors.css` — clay/vermilion/saffron/indigo/highland scales + semantic aliases.
- `ornament.css` — **the cultural vocabulary layer**: named pigments, harag/tibeb/lattice geometry, Geʼez punctuation tokens, manuscript measure, and the `.rubric` / `.rubric-open` / `.gloss` rules.
- `typography.css` — families, scale, weights, line-heights, type roles.
- `spacing.css` — 8px grid + semantic spacing + container widths.
- `effects.css` — radii, warm shadows, borders, motion (easing/durations).
- `base.css` — element resets and a few text-role utilities (`.eyebrow`, `.fidel`, `.bg-parchment`).

**Components** (`components/`) — reusable React primitives, namespace `window.AbugidaDesignSystem_019e1e`
- `core/` — `Button`, `IconButton`, `Badge`, `Avatar`, `Card`, `ProgressBar`
- `forms/` — `Input`
- `navigation/` — `Tabs`
- `learn/` — `FidelTile` (the signature control), `LessonCard`
- `ornament/` — the cultural vocabulary as components: `Tibeb`, `FidelField`, `CrossLattice`, `GeezNumeral`, `SectionMark`, `ManuscriptFrame`

**Foundation cards** (`guidelines/`) — the specimens rendered on the Design System tab (Colors, Type, Spacing, Brand).

**UI kit** (`ui_kits/learn-app/`) — high-fidelity, click-through recreation of the Amharic learning web app: landing, fidel lesson, learner dashboard, and the archive teaser.

---

## Caveats / open questions

- **Fonts load from Google Fonts CDN**, not self-hosted binaries — so the compiler reports zero local `@font-face`. For offline/self-hosted use, download Newsreader, Hanken Grotesk, Noto Serif/Sans Ethiopic, and Space Mono and replace `tokens/fonts.css` with local `@font-face` rules.
- **No real photography/illustration** is bundled (no source assets were provided). Kits use placeholders.
- **Lucide is a substitution** for a brand icon set that doesn't exist yet.
- This is a **proposed brand**, not a recreation. Reconcile against any real Abugida assets before production use.
