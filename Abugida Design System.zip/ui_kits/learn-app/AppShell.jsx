/* App shell with left sidebar — wraps Dashboard & Archive. */

function AppShell({ active, onNavigate, onExit, children }) {
  const { Avatar, Badge, Tibeb, GeezNumeral } = window.AbugidaDesignSystem_019e1e;
  const D = window.ABG_DATA;
  useLucide();

  const items = [
    { id: 'dashboard', label: 'Learn', icon: 'book-open' },
    { id: 'review', label: 'Review', icon: 'repeat', count: 12 },
    { id: 'archive', label: 'Archive', icon: 'landmark' },
  ];

  const NavItem = ({ it }) => {
    const on = active === it.id;
    return (
      <button onClick={() => onNavigate(it.id)} style={{
        display: 'flex', alignItems: 'center', gap: 12, width: '100%', textAlign: 'left',
        padding: '11px 14px', borderRadius: 'var(--radius-md)', border: 'none', cursor: 'pointer',
        background: on ? 'var(--brand-soft)' : 'transparent',
        color: on ? 'var(--vermilion-700)' : 'var(--text-body)',
        fontFamily: 'var(--font-body)', fontWeight: on ? 700 : 600, fontSize: 15,
        transition: 'var(--transition-control)',
      }}>
        <Ico n={it.icon} style={{ width: 19 }} />
        <span style={{ flex: 1 }}>{it.label}</span>
        {it.count != null && <Badge tone={on ? 'brand' : 'neutral'}><span style={{ fontFamily: 'var(--font-fidel)' }}><GeezNumeral value={it.count} /></span></Badge>}
      </button>
    );
  };

  return (
    <div style={{ display: 'flex', minHeight: '100%', background: 'var(--surface-page)' }} className="bg-parchment">
      {/* Sidebar */}
      <aside style={{ width: 244, flex: 'none', borderRight: '1px solid var(--border-subtle)',
        background: 'var(--surface-raised)', display: 'flex', flexDirection: 'column', padding: 18, gap: 6 }}>
        <div style={{ padding: '6px 8px 14px', cursor: 'pointer' }} onClick={onExit}><Logo size={22} /></div>
        <div style={{ margin: '0 -18px 14px' }}><Tibeb motif="diamond" cell={3} palette="netela" ground="var(--surface-raised)" /></div>
        {items.map((it) => <NavItem key={it.id} it={it} />)}
        <div style={{ marginTop: 'auto', borderTop: '1px solid var(--border-subtle)', paddingTop: 14,
          display: 'flex', alignItems: 'center', gap: 11 }}>
          <Avatar name={D.learner.name + ' Tesfaye'} tint="t1" />
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-strong)' }}>{D.learner.name} Tesfaye</div>
            <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>A1 · Beginner</div>
          </div>
        </div>
      </aside>

      {/* Content */}
      <main style={{ flex: 1, minWidth: 0, overflow: 'auto', maxHeight: '100%' }}>{children}</main>
    </div>
  );
}

Object.assign(window, { AppShell });
