/* Cultural archive — the "coming soon" teaser surface. */

function Archive() {
  const { Card, Badge, Button, Input, Tibeb, FidelField, CrossLattice, GeezNumeral } = window.AbugidaDesignSystem_019e1e;
  const D = window.ABG_DATA;
  useLucide();

  return (
    <div style={{ maxWidth: 980, margin: '0 auto', padding: '34px 40px 60px' }}>
      {/* Hero */}
      <Card padding="lg" style={{ background: 'var(--clay-900)', border: 'none', marginBottom: 28, overflow: 'hidden', position: 'relative' }}>
        <div style={{ position: 'absolute', inset: 0 }}>
          <CrossLattice cell={5} color="#F7EFE1" opacity={0.05} />
        </div>
        <div style={{ position: 'relative', maxWidth: 560 }}>
          <Badge tone="warning">Coming soon</Badge>
          <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 500, fontSize: 40, color: 'var(--clay-100)', margin: '16px 0 12px', lineHeight: 1.1 }}>
            A living archive of <span style={{ fontStyle: 'italic', color: 'var(--saffron-300)' }}>Ethiopian heritage</span>.
          </h1>
          <p style={{ fontSize: 17, color: 'var(--clay-300)', lineHeight: 1.55, maxWidth: 460 }}>
            Manuscripts, music, the coffee ceremony, proverbs and textiles — collected, explained,
            and kept for the next generation. Language first; the rest is on its way.
          </p>
        </div>
        <div style={{ position: 'absolute', right: -10, top: -30, fontFamily: 'var(--font-fidel)',
          fontSize: 240, color: 'rgba(201,138,43,0.12)', lineHeight: 1, userSelect: 'none', pointerEvents: 'none' }}>አ</div>
      </Card>

      {/* Category grid */}
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 21, color: 'var(--text-strong)', marginBottom: 10 }}>What we're gathering</h2>
      <div style={{ marginBottom: 18 }}><Tibeb motif="diamond" cell={3} palette="netela" /></div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18, marginBottom: 36 }}>
        {D.archive.map((a, i) => (
          <Card key={a.title} padding="none" interactive>
            {/* Placeholder panel — replace with real, rights-cleared photography.
                Until then it carries fidel texture rather than a gradient and an icon. */}
            <div style={{ height: 132, background: 'var(--clay-100)', position: 'relative', overflow: 'hidden',
              display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--clay-800)' }}>
              <FidelField size={54} opacity={0.09} seed={i * 3 + 2} />
              <span style={{ position: 'relative', fontFamily: 'var(--font-fidel)', fontSize: 52, color: a.tint, lineHeight: 1 }}>
                {'መሷቀበተነ'[i % 6]}
              </span>
              <span style={{ position: 'absolute', bottom: 8, right: 10, fontSize: 10, fontFamily: 'var(--font-mono)',
                color: 'var(--clay-500)' }}>image placeholder</span>
            </div>
            <Tibeb motif="dash" cell={2} palette="buna" frame={false} />
            <div style={{ padding: 16 }}>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                <span style={{ fontFamily: 'var(--font-fidel)', fontSize: 14, color: 'var(--saffron-500)' }}><GeezNumeral value={i + 1} /></span>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, color: 'var(--text-strong)' }}>{a.title}</div>
              </div>
              <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 2 }}>{a.sub}</div>
            </div>
          </Card>
        ))}
      </div>

      {/* Signup */}
      <Card padding="lg" accent>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 18, flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: 260 }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 22, color: 'var(--text-strong)', marginBottom: 6 }}>Be the first to explore</h3>
            <p style={{ fontSize: 14, color: 'var(--text-muted)', marginBottom: 14 }}>We'll email you once when the archive opens. No spam, ever.</p>
            <Input label="" placeholder="you@example.com" adornment={<i data-lucide="mail" />} />
          </div>
          <Button variant="primary" size="lg">Notify me</Button>
        </div>
      </Card>
    </div>
  );
}

Object.assign(window, { Archive });
