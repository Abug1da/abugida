/* Learner home / dashboard. */

function Dashboard({ onOpenLesson }) {
  const { Card, Button, Badge, ProgressBar, LessonCard, FidelTile, Tibeb, GeezNumeral } = window.AbugidaDesignSystem_019e1e;
  const D = window.ABG_DATA;
  useLucide();

  /* Counts are written in Geʼez figures, and the day is the Ethiopian one —
     ነሐሴ, the twelfth month. A streak measured in a calendar the learner
     doesn't use is a streak measured in someone else's time. */
  const Stat = ({ value, unit, label, tint }) => (
    <Card padding="md" style={{ flex: 1 }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
        <div style={{ fontFamily: 'var(--font-fidel)', fontSize: 34, lineHeight: 1, color: tint }}>
          <GeezNumeral value={value} />
        </div>
        {unit && <span style={{ fontFamily: 'var(--font-body)', fontSize: 14, color: 'var(--text-muted)' }}>{unit}</span>}
      </div>
      <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 8 }}>{label}</div>
      <div style={{ marginTop: 10 }}><Tibeb motif="dash" cell={3} palette="buna" ground="var(--surface-raised)" /></div>
    </Card>
  );

  const active = D.families.find(f => f.status === 'active');
  const done = D.families.filter(f => f.status === 'done' || f.status === 'active').length;

  return (
    <div style={{ maxWidth: 980, margin: '0 auto', padding: '34px 40px 60px' }}>
      {/* Greeting */}
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 24 }}>
        <div>
          <div style={{ fontFamily: 'var(--font-fidel)', fontSize: 13, letterSpacing: '0.06em', color: 'var(--text-faint)' }}>
            ረቡዕ ፡ ነሐሴ <GeezNumeral value={6} /> ቀን ፡ <GeezNumeral value={2018} /> ዓ.ም
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 500, fontSize: 36, color: 'var(--text-strong)', marginTop: 8 }}>
            <span style={{ fontFamily: 'var(--font-fidel)', color: 'var(--vermilion-600)' }}>{D.learner.greeting}</span>, {D.learner.name}<span style={{ fontFamily: 'var(--font-fidel)' }}>።</span>
          </h1>
        </div>
        <Badge tone="warning"><span style={{ fontFamily: 'var(--font-fidel)' }}><GeezNumeral value={D.learner.streak} /></span> days unbroken</Badge>
      </div>

      {/* Stats */}
      <div style={{ display: 'flex', gap: 16, marginBottom: 22 }}>
        <Stat value={D.learner.streak} label="Days unbroken" tint="var(--pigment-werq)" />
        <Stat value={D.learner.mastered} label="Letters mastered" tint="var(--pigment-arenguade)" />
        <Stat value={D.learner.minutesToday} unit="min" label="Read today" tint="var(--pigment-semayawi)" />
      </div>

      {/* Continue */}
      <Card elevation="raised" padding="lg" accent="var(--saffron-400)" style={{ marginBottom: 30 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
          <div style={{ width: 78, height: 78, borderRadius: 'var(--radius-lg)', flex: 'none',
            background: 'var(--brand-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: 'var(--font-fidel)', fontSize: 46, color: 'var(--vermilion-600)' }}>{active.glyph}</div>
          <div style={{ flex: 1 }}>
            <div className="eyebrow" style={{ color: 'var(--saffron-600)' }}>Continue where you left off</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 24, color: 'var(--text-strong)', margin: '6px 0 12px' }}>{active.name}</div>
            <ProgressBar value={active.progress} color="gold" height={8} />
          </div>
          <Button variant="gold" size="lg" onClick={() => onOpenLesson(active)} trailingIcon={<Ico n="arrow-right" />}>Continue</Button>
        </div>
      </Card>

      <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 30 }}>
        {/* Learning path */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 14 }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 21, color: 'var(--text-strong)' }}>Your fidel path</h2>
            <span style={{ fontSize: 13, color: 'var(--text-muted)', fontWeight: 600, fontFamily: 'var(--font-fidel)' }}>
              <GeezNumeral value={done} /> ከ <GeezNumeral value={33} /> ቤተሰብ
            </span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {D.families.map((f) => (
              <LessonCard key={f.glyph} glyph={f.glyph} title={f.name}
                subtitle={f.status === 'done' ? 'Mastered · 7 letters' : f.status === 'locked' ? 'Locked' : '7 letters · 4 min'}
                progress={f.progress} status={f.status}
                onClick={f.status === 'locked' ? undefined : () => onOpenLesson(f)} />
            ))}
          </div>
        </div>

        {/* Review rail */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          <Card padding="lg">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 19, color: 'var(--text-strong)' }}>Review</h3>
              <Badge tone="brand"><span style={{ fontFamily: 'var(--font-fidel)' }}><GeezNumeral value={12} /></span> due</Badge>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8, marginBottom: 16 }}>
              {[{c:'ሁ',r:'hu'},{c:'ላ',r:'la'},{c:'ሄ',r:'he'},{c:'ም',r:'mə'}].map(t => (
                <FidelTile key={t.c} char={t.c} romanization={t.r} size="sm" />
              ))}
            </div>
            <Button variant="primary" fullWidth leadingIcon={<Ico n="repeat" />}>Practice review</Button>
          </Card>

          <Card padding="lg">
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 19, color: 'var(--text-strong)', marginBottom: 14 }}>Daily goal</h3>
            <ProgressBar value={D.learner.dailyDone} max={D.learner.dailyGoal} color="green"
              label={`${D.learner.dailyDone} / ${D.learner.dailyGoal} min`} showValue />
            <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 12 }}>
              5 more minutes keeps your streak alive.
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Dashboard });
