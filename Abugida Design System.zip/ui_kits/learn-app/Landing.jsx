/* Abugida — landing.

   Three rules, applied literally:
   1. FIDEL AS TEXTURE. Oversized, faint Geʼez sits behind the hero and
      the footer. Recognisable as Ethiopian long before it is legible.
   2. TIBEB AS STRUCTURE. Every divider, cap, and section break is a
      woven band on a counted grid — not a hairline rule.
   3. THE NETELA RULE. The field stays cream; saturated colour lives
      only inside the bands. */

function Landing({ onStart, onArchive }) {
  const { Button, Tibeb, CrossLattice, FidelField, GeezNumeral } = window.AbugidaDesignSystem_019e1e;
  const D = window.ABG_DATA;

  const ha = D.families[0].orders;
  const ORDERS = ['ግዕዝ', 'ካዕብ', 'ሣልስ', 'ራብዕ', 'ኃምስ', 'ሳድስ', 'ሳብዕ'];

  const nav = { fontFamily: 'var(--font-body)', fontSize: 15, fontWeight: 600, color: 'var(--buna-bean)', cursor: 'pointer' };
  const sep = { fontFamily: 'var(--font-fidel)', color: 'var(--buna-rust)', fontSize: 15, opacity: 0.6 };
  const shell = { maxWidth: 1140, margin: '0 auto', padding: '0 44px' };

  return (
    <div style={{ background: 'var(--buna-cream)', minHeight: '100%' }}>

      {/* ── Header, capped by the woven band ───────────────────── */}
      <header style={{ ...shell, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '22px 44px 18px' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
          <span style={{ fontFamily: 'var(--font-fidel)', fontSize: 26, color: 'var(--buna-rust)', lineHeight: 1 }}>አቡጊዳ</span>
          <span style={{ fontFamily: 'var(--font-body)', fontSize: 12, fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--buna-ash)' }}>Abugida</span>
        </div>
        <nav style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <span style={nav}>Learn</span>
          <span style={sep}>፣</span>
          <span style={nav} onClick={onArchive}>Archive</span>
          <span style={sep}>፣</span>
          <span style={nav}>About</span>
          <span style={{ width: 14 }} />
          <Button variant="primary" size="sm" onClick={onStart}>Start learning</Button>
        </nav>
      </header>
      <Tibeb motif="diamond" cell={4} palette="netela" />

      {/* ── Hero, on a field of fidel ──────────────────────────── */}
      <section style={{ position: 'relative', overflow: 'hidden' }}>
        <FidelField size={128} opacity={0.042} color="var(--buna-bean)" gap={0.3} seed={11} />
        <div style={{ ...shell, position: 'relative', paddingTop: 54, paddingBottom: 54 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1fr) 15ch', gap: 44 }}>
            <div>
              <div style={{ fontFamily: 'var(--font-fidel)', fontSize: 13, letterSpacing: '0.06em', color: 'var(--buna-ash)', marginBottom: 18 }}>
                ክፍል <GeezNumeral value={1} /> ። መጀመሪያ ቃል
              </div>

              <div style={{ display: 'flex', alignItems: 'flex-end', gap: 26, flexWrap: 'wrap' }}>
                <h1 style={{ fontFamily: 'var(--font-fidel)', fontSize: 108, lineHeight: 0.96, margin: 0, color: 'var(--buna-jebena)', fontWeight: 400 }}>
                  <span style={{ color: 'var(--buna-rust)' }}>ሰ</span>ላም
                </h1>
                <div style={{ paddingBottom: 16 }}>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 15, color: 'var(--buna-ochre)' }}>säl·am</div>
                  <div style={{ fontSize: 14, color: 'var(--buna-ash)', marginTop: 4 }}>peace · hello</div>
                </div>
              </div>

              <p className="rubric-open" style={{ fontSize: 17, lineHeight: 1.75, color: 'var(--buna-bean)', maxWidth: '46ch', marginTop: 26 }}>
                Four characters, and you have read your first Amharic word. The fidel is not an
                alphabet to be memorised letter by letter — it is a table of thirty-three sounds
                turned through seven vowels, and learning the turning teaches you all of it at once.
              </p>

              <div style={{ display: 'flex', gap: 14, alignItems: 'center', marginTop: 30 }}>
                <Button variant="primary" size="lg" onClick={onStart}>Begin the table</Button>
                <Button variant="ghost" size="lg" onClick={onArchive}>Visit the archive</Button>
              </div>
            </div>

            {/* Scribe's margin — rubricated gloss, as in the codex */}
            <aside style={{ borderInlineStart: '1px solid rgba(74,46,30,0.16)', paddingInlineStart: 20 }}>
              <div style={{ fontFamily: 'var(--font-fidel)', fontSize: 13, lineHeight: 1.75, color: 'var(--buna-rust)' }}>
                ሰላም ማለት <br />ሰላምታ ነው።
              </div>
              <div style={{ fontSize: 12, lineHeight: 1.6, color: 'var(--buna-ash)', marginTop: 14 }}>
                The greeting and the word for peace are the same word. Ethiopians say it as both.
              </div>
              <div style={{ fontFamily: 'var(--font-fidel)', fontSize: 20, color: 'var(--buna-ochre)', marginTop: 18 }}>፨</div>
            </aside>
          </div>
        </div>
      </section>

      {/* ── The fidel table — the hero object ──────────────────── */}
      <section style={{ ...shell }}>
        <div style={{ background: '#FFFDF8', border: '1px solid rgba(74,46,30,0.14)', borderRadius: 'var(--radius-sm)', overflow: 'clip' }}>
          <Tibeb motif="chevron" cell={4} palette="buna" ground="#FFFDF8" />
          <div style={{ padding: '26px 30px 30px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: `10ch repeat(${ha.length}, 1fr)`, gap: 10, alignItems: 'end' }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--buna-ash)', paddingBottom: 8 }}>Order</div>
              {ha.map((o, i) => (
                <div key={`h${i}`} style={{ textAlign: 'center', paddingBottom: 8 }}>
                  <div style={{ fontFamily: 'var(--font-fidel)', fontSize: 13, color: 'var(--buna-rust)' }}>{ORDERS[i]}</div>
                  <div style={{ fontFamily: 'var(--font-fidel)', fontSize: 12, color: 'var(--buna-ash)', marginTop: 2 }}><GeezNumeral value={i + 1} /></div>
                </div>
              ))}

              <div style={{ fontFamily: 'var(--font-fidel)', fontSize: 30, color: 'var(--buna-ochre)', alignSelf: 'center' }}>ሀ</div>
              {ha.map((o) => (
                <div key={o.char} style={{ textAlign: 'center', padding: '14px 0', background: 'var(--buna-cream)', borderRadius: 'var(--radius-xs)', border: '1px solid rgba(74,46,30,0.1)' }}>
                  <div style={{ fontFamily: 'var(--font-fidel)', fontSize: 34, lineHeight: 1, color: 'var(--buna-jebena)' }}>{o.char}</div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--buna-ash)', marginTop: 7 }}>{o.rom}</div>
                </div>
              ))}
            </div>
            <div style={{ fontSize: 13, color: 'var(--buna-ash)', marginTop: 18, maxWidth: '62ch', lineHeight: 1.65 }}>
              One consonant, seven vowel orders. Thirty-three of these rows make the whole script —
              and the shape of the turn is the same in every row<span style={{ fontFamily: 'var(--font-fidel)' }}>።</span>
            </div>
          </div>
        </div>
      </section>

      {/* ── Three offerings, numbered as chapters ──────────────── */}
      <section style={{ ...shell, marginTop: 62, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 40 }}>
        {[
          { t: 'The fidel, whole', b: 'All thirty-three families, taught as the grid they are — with audio from native speakers in Addis and the diaspora.' },
          { t: 'Review that holds', b: 'Spaced repetition set to the Ethiopian calendar, thirteen months and all, so a streak means a real month of work.' },
          { t: 'A living archive', b: 'Manuscripts, the coffee ceremony, Yared’s notation, proverbs — the context the language lives inside.', onClick: onArchive },
        ].map((c, i) => (
          <div key={c.t} onClick={c.onClick} style={{ cursor: c.onClick ? 'pointer' : 'default' }}>
            <div style={{ fontFamily: 'var(--font-fidel)', fontSize: 44, lineHeight: 1, color: 'var(--buna-rust)' }}>
              <GeezNumeral value={i + 1} />
            </div>
            <div style={{ margin: '14px 0 16px' }}><Tibeb motif="dash" cell={3} palette="buna" /></div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, color: 'var(--buna-jebena)', marginBottom: 8 }}>{c.t}</div>
            <p style={{ fontSize: 15, lineHeight: 1.6, color: 'var(--buna-ash)' }}>{c.b}</p>
          </div>
        ))}
      </section>

      {/* ── First words, on the deep roast ─────────────────────── */}
      <section style={{ marginTop: 66, background: 'var(--buna-bean)', position: 'relative' }}>
        <Tibeb motif="terrace" cell={5} palette="netela" ground="var(--buna-bean)" flip />
        <div style={{ ...shell, padding: '40px 44px 48px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 40, flexWrap: 'wrap' }}>
          <div style={{ maxWidth: 330 }}>
            <div style={{ fontFamily: 'var(--font-fidel)', fontSize: 13, color: 'var(--buna-ochre)', letterSpacing: '0.06em' }}>
              ትምህርት <GeezNumeral value={1} /> ሲጨርስ
            </div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 29, color: 'var(--buna-cream)', marginTop: 12, lineHeight: 1.22 }}>
              You will read words you already know by heart.
            </div>
          </div>
          <div style={{ display: 'flex', gap: 34 }}>
            {D.firstWords.map((w) => (
              <div key={w.word} style={{ textAlign: 'center' }}>
                <div style={{ fontFamily: 'var(--font-fidel)', fontSize: 46, color: 'var(--buna-cream)', lineHeight: 1.15 }}>{w.word}</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--buna-ochre)', marginTop: 6 }}>{w.rom}</div>
                <div style={{ fontSize: 12, color: 'rgba(247,239,225,0.62)', marginTop: 2 }}>{w.gloss}</div>
              </div>
            ))}
          </div>
        </div>
        <Tibeb motif="terrace" cell={5} palette="netela" ground="var(--buna-bean)" />
      </section>

      {/* ── Footer, on a ground of Ethiopian crosses ───────────── */}
      <footer style={{ background: 'var(--buna-jebena)', color: 'rgba(247,239,225,0.72)', position: 'relative', overflow: 'clip' }}>
        <div style={{ position: 'absolute', inset: 0 }}>
          <CrossLattice cell={5} color="#F7EFE1" opacity={0.05} />
        </div>
        <div style={{ ...shell, padding: '46px 44px', display: 'flex', justifyContent: 'space-between', gap: 30, flexWrap: 'wrap', position: 'relative' }}>
          <div>
            <div style={{ fontFamily: 'var(--font-fidel)', fontSize: 24, color: 'var(--buna-ochre)' }}>አቡጊዳ</div>
            <p style={{ fontSize: 14, marginTop: 12, maxWidth: 300, lineHeight: 1.6 }}>
              A non-profit keeping Amharic and its script in reach of everyone who wants it. Free, forever<span style={{ fontFamily: 'var(--font-fidel)' }}>።</span>
            </p>
          </div>
          <div style={{ display: 'flex', gap: 46, fontSize: 14 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <span style={{ color: 'var(--buna-cream)', fontWeight: 700 }}>Learn</span>
              <span>The fidel</span><span>Vocabulary</span><span>Review</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <span style={{ color: 'var(--buna-cream)', fontWeight: 700 }}>Abugida</span>
              <span>About</span><span>Archive</span><span>Donate</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

Object.assign(window, { Landing });
