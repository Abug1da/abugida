/* The fidel lesson — interactive teach + quiz flow. */

function Lesson({ family, onExit, onComplete }) {
  const { Button, IconButton, FidelTile, ProgressBar, Badge, Tibeb, GeezNumeral, FidelField } = window.AbugidaDesignSystem_019e1e;
  const D = window.ABG_DATA;
  const fam = family || D.families[1];

  const [phase, setPhase] = React.useState('teach'); // teach | quiz | done
  const [qi, setQi] = React.useState(0);
  const [picked, setPicked] = React.useState(null);
  const [checked, setChecked] = React.useState(false);
  useLucide();

  const quiz = D.quiz;
  const q = quiz[qi];
  const isLast = qi === quiz.length - 1;

  const tileState = (opt) => {
    if (!checked) return picked === opt.char ? 'selected' : 'default';
    if (opt.char === q.answer) return 'correct';
    if (opt.char === picked) return 'wrong';
    return 'ghost';
  };

  const onCheck = () => { if (picked) setChecked(true); };
  const onNext = () => {
    if (isLast) { setPhase('done'); return; }
    setQi(qi + 1); setPicked(null); setChecked(false);
  };

  const correct = checked && picked === q.answer;

  return (
    <div style={{ minHeight: '100%', background: 'var(--surface-page)', display: 'flex', flexDirection: 'column' }} className="bg-parchment">
      {/* Header */}
      <header style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '18px 28px',
        borderBottom: '1px solid var(--border-subtle)', background: 'var(--surface-raised)' }}>
        <IconButton aria-label="Back" variant="ghost" onClick={onExit}><Ico n="arrow-left" /></IconButton>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontFamily: 'var(--font-fidel)', fontSize: 22, color: 'var(--vermilion-600)' }}>{fam.glyph}</span>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 19, color: 'var(--text-strong)' }}>{fam.name}</span>
            {phase === 'quiz' && <Badge tone="neutral"><span style={{ fontFamily: 'var(--font-fidel)' }}><GeezNumeral value={qi + 1} /> ከ <GeezNumeral value={quiz.length} /></span></Badge>}
          </div>
        </div>
        <div style={{ width: 220 }}>
          <ProgressBar color="gold" height={8}
            value={phase === 'teach' ? 8 : phase === 'done' ? 100 : ((qi + (checked ? 1 : 0)) / quiz.length) * 100} />
        </div>
      </header>

      {/* Body */}
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px 24px' }}>
        <div style={{ width: '100%', maxWidth: 620 }}>

          {phase === 'teach' && (
            <div style={{ position: 'relative' }}>
              <div className="eyebrow" style={{ textAlign: 'center' }}>New letter family</div>
              <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 28, margin: '22px 0 28px', overflow: 'hidden' }}>
                <FidelField mode="watermark" text={fam.orders[0].char} size={300} opacity={0.045} color="var(--clay-800)" />
                <div style={{ position: 'relative', fontFamily: 'var(--font-fidel)', fontSize: 120, color: 'var(--text-strong)', lineHeight: 1 }}>{fam.orders[0].char}</div>
                <div style={{ position: 'relative' }}>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 22, color: 'var(--vermilion-600)', fontWeight: 700 }}>{fam.orders[0].rom}</div>
                  <div style={{ fontSize: 15, color: 'var(--text-muted)', maxWidth: 200, marginTop: 8 }}>
                    The base form. Each of the seven shapes below adds a vowel.
                  </div>
                  <IconButton aria-label="Play sound" variant="outline" style={{ marginTop: 14 }}><Ico n="volume-2" /></IconButton>
                </div>
              </div>
              <div style={{ marginBottom: 18 }}><Tibeb motif="chevron" cell={3} palette="buna" /></div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 9, marginBottom: 30 }}>
                {fam.orders.map((o) => <FidelTile key={o.char} char={o.char} romanization={o.rom} size="sm" />)}
              </div>
              <Button variant="primary" size="lg" fullWidth onClick={() => setPhase('quiz')} trailingIcon={<Ico n="arrow-right" />}>
                Practice these
              </Button>
            </div>
          )}

          {phase === 'quiz' && (
            <div>
              <div style={{ textAlign: 'center', marginBottom: 28 }}>
                <div className="eyebrow">Tap the matching letter</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 30, color: 'var(--text-strong)', marginTop: 10 }}>
                  Which one says <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--vermilion-600)', fontWeight: 700 }}>{q.prompt}</span>?
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 8 }}>
                {q.options.map((opt) => (
                  <FidelTile key={opt.char} char={opt.char} romanization={opt.rom} size="md"
                    state={tileState(opt)}
                    disabled={checked}
                    onClick={() => !checked && setPicked(opt.char)} />
                ))}
              </div>
            </div>
          )}

          {phase === 'done' && (
            <div style={{ textAlign: 'center' }}>
              <div style={{ width: 84, height: 84, borderRadius: '50%', background: 'var(--success-soft)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center', marginBottom: 20 }}>
                <span style={{ fontFamily: 'var(--font-fidel)', fontSize: 44, color: 'var(--highland-500)', lineHeight: 1 }}>፨</span>
              </div>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 34, color: 'var(--text-strong)' }}>እንኳን ደስ አለህ!</h2>
              <p style={{ fontSize: 17, color: 'var(--text-body)', margin: '12px auto 28px', maxWidth: 380 }}>
                Nicely done — that's the {fam.name.replace('The ', '').replace(' family', '')} family. Your streak is safe today.
              </p>
              <Button variant="primary" size="lg" onClick={onComplete} leadingIcon={<Ico n="check" />}>Back to learning</Button>
              <div style={{ maxWidth: 260, margin: '28px auto 0' }}><Tibeb motif="diamond" cell={4} palette="netela" /></div>
            </div>
          )}
        </div>
      </div>

      {/* Footer action bar (quiz) */}
      {phase === 'quiz' && (
        <footer style={{ borderTop: `1px solid ${checked ? (correct ? 'var(--highland-200)' : 'var(--vermilion-200)') : 'var(--border-subtle)'}`,
          background: checked ? (correct ? 'var(--success-soft)' : 'var(--danger-soft)') : 'var(--surface-raised)',
          padding: '18px 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', transition: 'var(--transition-control)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            {checked && (
              <>
                <div style={{ width: 38, height: 38, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: correct ? 'var(--highland-400)' : 'var(--vermilion-500)', color: '#fff' }}>
                  <Ico n={correct ? 'check' : 'x'} style={{ width: 20 }} />
                </div>
                <div>
                  <div style={{ fontWeight: 700, color: correct ? 'var(--highland-600)' : 'var(--vermilion-700)' }}>{correct ? 'Correct!' : 'Not quite'}</div>
                  <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                    <span style={{ fontFamily: 'var(--font-fidel)' }}>{q.answer}</span> is “{q.prompt}”.
                  </div>
                </div>
              </>
            )}
          </div>
          {checked
            ? <Button variant={correct ? 'gold' : 'primary'} size="lg" onClick={onNext} trailingIcon={<Ico n="arrow-right" />}>{isLast ? 'Finish' : 'Continue'}</Button>
            : <Button variant="primary" size="lg" disabled={!picked} onClick={onCheck}>Check</Button>}
        </footer>
      )}
    </div>
  );
}

Object.assign(window, { Lesson });
