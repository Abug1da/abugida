/* Shared bits for the Abugida learn-app kit. */

function Ico({ n, style }) {
  return <i data-lucide={n} style={style} />;
}

/* The mark is the fidel character itself, sitting on a woven band —
   not a glyph inside a rounded square, which is the most generic
   lockup on the web and says nothing about where this comes from. */
function Logo({ size = 28, inverted = false, mark = true, wordmark = true }) {
  const { Tibeb } = window.AbugidaDesignSystem_019e1e;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: size * 0.44 }}>
      {mark && (
        <span style={{ display: 'inline-flex', flexDirection: 'column', gap: size * 0.14 }}>
          <span style={{
            fontFamily: 'var(--font-fidel)', fontWeight: 500,
            color: inverted ? 'var(--saffron-400)' : 'var(--vermilion-500)',
            fontSize: size * 1.32, lineHeight: 0.92,
          }}>አ</span>
          <span style={{ width: size * 1.05 }}>
            <Tibeb motif="dash" cell={Math.max(2, Math.round(size / 12))} palette="buna" frame={false} />
          </span>
        </span>
      )}
      {wordmark && (
        <span style={{
          fontFamily: 'var(--font-display)', fontWeight: 500, fontSize: size,
          letterSpacing: '-0.01em', color: inverted ? 'var(--clay-100)' : 'var(--text-strong)',
        }}>Abugida</span>
      )}
    </span>
  );
}

// Refresh Lucide glyphs after any render.
function useLucide(dep) {
  React.useEffect(() => { if (window.lucide) window.lucide.createIcons(); });
}

Object.assign(window, { Ico, Logo, useLucide });
