# UI Kit — Abugida learn-app

A high-fidelity, click-through recreation of Abugida's **free Amharic learning web app**. It composes the system's component primitives (`Button`, `Card`, `FidelTile`, `LessonCard`, `ProgressBar`, `Tabs`, `Badge`, `Avatar`, `Input`, `IconButton`) — it does not re-implement them.

> Built from the brand brief — there is no shipped product to mirror. Treat this as a proposed v1 of the experience.

## Run it
Open `index.html`. The bundle (`../../_ds_bundle.js`) and `styles.css` are loaded relative to the project root, so it must be served from within the project (it is, on the Design System tab and in preview).

## Flow (interactive)
1. **Landing** — marketing page. *Start learning* → dashboard; *Archive* → archive.
2. **Dashboard** (`AppShell` + `Dashboard`) — greeting, streak/mastery stats, a *Continue* card, the fidel learning path (`LessonCard` list), and a review rail. Click any unlocked lesson → lesson.
3. **Lesson** — the core loop: a **teach** step (big fidel + the seven vowel orders) then an interactive **quiz** (tap a `FidelTile`, *Check*, see correct/wrong feedback, *Continue*) ending in a celebration screen.
4. **Archive** — the "coming soon" cultural archive teaser with category cards and an email capture.

## Files
- `index.html` — entry + screen router (`@dsCard` for the Design System tab).
- `data.js` — sample fidel families, quiz, words, archive categories (`window.ABG_DATA`).
- `Parts.jsx` — shared `Logo` + icon helper (exported to `window`).
- `AppShell.jsx` — sidebar layout for the in-app screens.
- `Landing.jsx` · `Dashboard.jsx` · `Lesson.jsx` · `Archive.jsx` — the four surfaces.

## Notes
- Icons are **Lucide** via CDN (`<i data-lucide>` + `lucide.createIcons()`).
- Image areas in the Archive are **placeholders** — no real photography ships with this system. Swap in rights-cleared imagery (coffee ceremony, manuscripts, highlands, learners) when available.
- All Geʼez text is real, set in Noto Serif Ethiopic; romanization is learner-friendly, not strict IPA.
