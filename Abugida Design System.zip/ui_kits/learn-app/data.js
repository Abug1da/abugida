// Sample content for the Abugida learn-app UI kit.
// Fidel data is real Geʼez; romanization uses a light, learner-friendly scheme.

window.ABG_DATA = {
  learner: { name: 'Selam', greeting: 'ሰላም', streak: 12, mastered: 28, minutesToday: 15, dailyGoal: 20, dailyDone: 15 },

  // One consonant family = a row of the fidel grid (7 vowel orders).
  families: [
    { glyph: 'ሀ', name: 'The ሀ family', base: 'h', status: 'done', progress: 100,
      orders: [
        { char: 'ሀ', rom: 'hä' }, { char: 'ሁ', rom: 'hu' }, { char: 'ሂ', rom: 'hi' },
        { char: 'ሃ', rom: 'ha' }, { char: 'ሄ', rom: 'he' }, { char: 'ህ', rom: 'hə' }, { char: 'ሆ', rom: 'ho' },
      ] },
    { glyph: 'ለ', name: 'The ለ family', base: 'l', status: 'active', progress: 60,
      orders: [
        { char: 'ለ', rom: 'lä' }, { char: 'ሉ', rom: 'lu' }, { char: 'ሊ', rom: 'li' },
        { char: 'ላ', rom: 'la' }, { char: 'ሌ', rom: 'le' }, { char: 'ል', rom: 'lə' }, { char: 'ሎ', rom: 'lo' },
      ] },
    { glyph: 'መ', name: 'The መ family', base: 'm', status: 'locked', progress: 0,
      orders: [
        { char: 'መ', rom: 'mä' }, { char: 'ሙ', rom: 'mu' }, { char: 'ሚ', rom: 'mi' },
        { char: 'ማ', rom: 'ma' }, { char: 'ሜ', rom: 'me' }, { char: 'ም', rom: 'mə' }, { char: 'ሞ', rom: 'mo' },
      ] },
    { glyph: 'ረ', name: 'The ረ family', base: 'r', status: 'locked', progress: 0,
      orders: [
        { char: 'ረ', rom: 'rä' }, { char: 'ሩ', rom: 'ru' }, { char: 'ሪ', rom: 'ri' },
        { char: 'ራ', rom: 'ra' }, { char: 'ሬ', rom: 're' }, { char: 'ር', rom: 'rə' }, { char: 'ሮ', rom: 'ro' },
      ] },
    { glyph: 'ሰ', name: 'The ሰ family', base: 's', status: 'locked', progress: 0,
      orders: [
        { char: 'ሰ', rom: 'sä' }, { char: 'ሱ', rom: 'su' }, { char: 'ሲ', rom: 'si' },
        { char: 'ሳ', rom: 'sa' }, { char: 'ሴ', rom: 'se' }, { char: 'ስ', rom: 'sə' }, { char: 'ሶ', rom: 'so' },
      ] },
  ],

  // A short quiz for the active lesson.
  quiz: [
    { prompt: 'lu', answer: 'ሉ', options: [
        { char: 'ለ', rom: 'lä' }, { char: 'ሉ', rom: 'lu' }, { char: 'ላ', rom: 'la' }, { char: 'ል', rom: 'lə' } ] },
    { prompt: 'li', answer: 'ሊ', options: [
        { char: 'ሎ', rom: 'lo' }, { char: 'ሌ', rom: 'le' }, { char: 'ሊ', rom: 'li' }, { char: 'ለ', rom: 'lä' } ] },
    { prompt: 'lo', answer: 'ሎ', options: [
        { char: 'ላ', rom: 'la' }, { char: 'ሎ', rom: 'lo' }, { char: 'ሉ', rom: 'lu' }, { char: 'ሊ', rom: 'li' } ] },
  ],

  // Words the learner can already read, for the landing "read your first word" moment.
  firstWords: [
    { word: 'ሰላም', rom: 'sälam', gloss: 'hello / peace' },
    { word: 'አቡጊዳ', rom: 'abugida', gloss: 'the script' },
    { word: 'ቡና', rom: 'buna', gloss: 'coffee' },
  ],

  // Archive categories (the cultural archive that "follows").
  archive: [
    { title: 'Manuscripts', sub: 'Illuminated Geʼez codices', icon: 'book-marked', tint: 'var(--vermilion-500)' },
    { title: 'Coffee', sub: 'The buna ceremony', icon: 'coffee', tint: 'var(--saffron-500)' },
    { title: 'Music', sub: 'Tizita, krar & masinko', icon: 'music', tint: 'var(--indigo-500)' },
    { title: 'Proverbs', sub: 'ምሳሌ — wisdom in lines', icon: 'quote', tint: 'var(--highland-400)' },
    { title: 'Textiles', sub: 'Tibeb & habesha kemis', icon: 'shirt', tint: 'var(--vermilion-600)' },
    { title: 'Photography', sub: 'Faces of the diaspora', icon: 'camera', tint: 'var(--indigo-600)' },
  ],
};
